/* Thin Supabase bootstrap. App data access stays in app.js; privileged work stays server-side. */
(() => {
  'use strict';
  const config = window.INFRAIQ_SUPABASE_CONFIG || {};
  const url = String(config.url || '').trim();
  const key = String(config.publishableKey || '').trim();
  const sdk = window.supabase;
  const configured = Boolean(sdk?.createClient && /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url) && key);
  let client = null;
  let authListener = null;
  if (configured) {
    client = sdk.createClient(url, key, {
      auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true }
    });
  }
  window.InfraIQCloud = {
    configured,
    client,
    functionName: String(config.copilotFunction || 'campus-copilot'),
    onAuthStateChange(callback) {
      if (!client) return null;
      const { data } = client.auth.onAuthStateChange((event, session) => callback(event, session));
      authListener = data?.subscription || null;
      return authListener;
    },
    disposeAuthListener() { authListener?.unsubscribe(); authListener = null; }
  };
})();
