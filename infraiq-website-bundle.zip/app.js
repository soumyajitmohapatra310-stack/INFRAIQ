(() => {
  'use strict';

  const ROOT = document.getElementById('app');
  const SHOWCASE_MODE_KEY = 'infraiq-showcase-demo-v1';
  const SHOWCASE_MODE = localStorage.getItem(SHOWCASE_MODE_KEY) === 'true';
  const PROFILE_KEY = SHOWCASE_MODE ? 'infraiq-showcase-profile-v1' : 'infraiq-profile-v3';
  const DATA_KEY = SHOWCASE_MODE ? 'infraiq-showcase-data-v1' : 'infraiq-institution-data-v3';
  const roles = {
    admin: { label: 'Administrator', group: 'Leadership' },
    environmental: { label: 'Environmental engineer', group: 'Campus operations' },
    dean: { label: 'Dean / Director', group: 'Leadership' },
    warden: { label: 'Hostel dean / Warden', group: 'Residential services' },
    security: { label: 'Security staff', group: 'Campus response' },
    worker: { label: 'Campus worker', group: 'Campus response' },
    kitchen: { label: 'Kitchen staff', group: 'Food services' }
  };
  const nav = [
    ['command', 'Overview', '⌂'],
    ['maintenance', 'Maintenance', '⚙'],
    ['health', 'Campus health report', '◉'],
    ['staff', 'My shift & reports', '◷'],
    ['incidents', 'Incident desk', '⚑'],
    ['crew', 'Crew & recognition', '♙'],
    ['kitchen', 'Kitchen & food', '◒'],
    ['equipment', 'Equipment register', '▦'],
    ['campus', 'Campus profile', '⌖'],
    ['history', 'Six-month data', '▤'],
    ['intelligence', 'Resource intelligence', '✦'],
    ['audit', 'Audit log', '◷'],
    ['copilot', 'INFRAIQ assistant', '✳'],
    ['environment', 'Environment & news', '◌']
  ];
  const categories = [
    ['electricity', 'Electricity use'],
    ['water', 'Water use'],
    ['lab_condition', 'Lab conditions'],
    ['equipment_import', 'Equipment imports'],
    ['equipment_export', 'Equipment exports'],
    ['chemical_import', 'Chemical imports'],
    ['chemical_export', 'Chemical exports'],
    ['traffic', 'Traffic volumes'],
    ['entry_exit', 'Entry / exit times'],
    ['occasion', 'Occasions / events'],
    ['holiday', 'Holidays / closures']
  ];
  const rolePages = {
    admin: ['command','maintenance','health','staff','incidents','crew','kitchen','equipment','campus','history','intelligence','audit','copilot','environment'],
    environmental: ['command','maintenance','health','staff','incidents','equipment','campus','history','intelligence','copilot','environment'],
    dean: ['command','maintenance','health','staff','incidents','crew','kitchen','equipment','campus','history','intelligence','audit','copilot','environment'],
    warden: ['command','maintenance','health','staff','incidents','crew','kitchen','equipment','campus','intelligence','copilot','environment'],
    security: ['command','maintenance','health','staff','incidents','intelligence','copilot','environment'],
    worker: ['command','maintenance','health','staff','incidents','intelligence','copilot','environment'],
    kitchen: ['command','maintenance','health','staff','incidents','kitchen','intelligence','copilot','environment']
  };
  const oldProfile = read('infraiq-profile', {}) || {};
  const savedProfile = read(PROFILE_KEY, null);
  const oldRole = {maintenance:'worker',sustainability:'environmental',executive:'dean'}[oldProfile.role] || oldProfile.role;
  const profile = savedProfile || (SHOWCASE_MODE ? {
    personName:'Demo Campus Lead',email:'demo@infraiq.local',collegeName:'INFRAIQ Demo Campus',city:'Showcase City',region:'Sample Region',address:'Fictional campus · showcase only',latitude:'',longitude:'',role:'admin',completed:true,signedIn:true,campusSize:'64000',blockCount:'5',opening:'07:00',closing:'21:00',mapsKey:'',institutionId:'',authUserId:'',electricityTariff:'',alertThresholdPct:'25'
  } : {
    personName: oldProfile.personName || '',
    email: oldProfile.email || '',
    collegeName: oldProfile.collegeName || '',
    city: oldProfile.city || '',
    region: oldProfile.region || '',
    address: oldProfile.address || '',
    latitude: oldProfile.latitude || '',
    longitude: oldProfile.longitude || '',
    role: roles[oldRole] ? oldRole : 'admin',
    completed: !!oldProfile.completed,
    signedIn: false,
    campusSize: '',
    blockCount: '',
    opening: oldProfile.hours?.weekdayOpen || '08:00',
    closing: oldProfile.hours?.weekdayClose || '18:00',
    mapsKey: '',
    institutionId: '',
    authUserId: '',
    electricityTariff: '',
    alertThresholdPct: '25'
  });
  profile.institutionId = profile.institutionId || '';
  profile.authUserId = profile.authUserId || '';
  const stored = read(DATA_KEY, {});
  const data = Object.assign({
    blocks: [], equipment: [], crew: [], incidents: [], shifts: [], activeShift: null, activeShifts: [],
    kitchen: [], history: [], maintenance: [], manual: [], messages: [], assistantFeedback: [], simulationRuns: [], resourceSources: [], resourceObservations: []
  }, stored && typeof stored === 'object' ? stored : {});
  data.activeShifts = Array.isArray(data.activeShifts) ? data.activeShifts : [];
  if(data.activeShift && !data.activeShifts.some(x=>x.id===data.activeShift.id)) data.activeShifts.push(data.activeShift);
  data.maintenance = Array.isArray(data.maintenance) ? data.maintenance : [];
  data.simulationRuns = Array.isArray(data.simulationRuns) ? data.simulationRuns : [];
  data.resourceSources = Array.isArray(data.resourceSources) ? data.resourceSources : [];
  data.resourceObservations = Array.isArray(data.resourceObservations) ? data.resourceObservations : [];
  function seedShowcaseData() {
    if(!SHOWCASE_MODE||data.history.length||data.blocks.length||data.incidents.length)return;
    data.blocks=['Block 1','Block 2','Block 3','Hostel A','Hostel B'].map((name,i)=>({id:id('block'),name,area:String(8200+i*900),students:String(430+i*75),faculty:String(38+i*6),workers:String(24+i*4),labs:String(4+i%3),instruments:String(72+i*11),opening:'07:00',closing:'21:00'}));
    data.crew=[
      {id:'demo_admin',userId:'demo_admin',name:'Demo Campus Lead',email:'demo@infraiq.local',role:'admin',block:'',xp:30,joinedAt:new Date().toISOString()},
      {id:'demo_worker_1',userId:'demo_worker_1',name:'Aarav Sen',email:'aarav@infraiq.local',role:'worker',block:'Block 5',xp:50,joinedAt:new Date().toISOString()},
      {id:'demo_engineer',userId:'demo_engineer',name:'Mira Das',email:'mira@infraiq.local',role:'environmental',block:'Block 2',xp:20,joinedAt:new Date().toISOString()},
      {id:'demo_warden',userId:'demo_warden',name:'Rohan Iyer',email:'rohan@infraiq.local',role:'warden',block:'Hostel A',xp:10,joinedAt:new Date().toISOString()},
      {id:'demo_kitchen',userId:'demo_kitchen',name:'Neha Roy',email:'neha@infraiq.local',role:'kitchen',block:'Kitchen',xp:0,joinedAt:new Date().toISOString()}
    ];
    data.equipment=[
      {id:'demo_asset_1',name:'Main transformer T-1',type:'Electrical',serial:'DEMO-T1',block:'Block 5',condition:'Needs inspection',quantity:1,createdAt:new Date().toISOString(),maintenanceDue:'2026-11-12'},
      {id:'demo_asset_2',name:'Water pump P-2',type:'Pump',serial:'DEMO-P2',block:'Block 2',condition:'Operational',quantity:1,createdAt:new Date().toISOString(),maintenanceDue:'2026-11-28'},
      {id:'demo_asset_3',name:'Lab ventilation unit',type:'HVAC',serial:'DEMO-LV1',block:'Block 1',condition:'Operational',quantity:2,createdAt:new Date().toISOString(),maintenanceDue:'2026-12-10'}
    ];
    data.history=[];
    const monthly=[
      {electricity:12480,water:398,traffic:735},{electricity:13120,water:420,traffic:790},
      {electricity:13750,water:447,traffic:810},{electricity:14420,water:468,traffic:855},
      {electricity:13980,water:452,traffic:830},{electricity:13360,water:431,traffic:802}
    ];
    const entries=[
      ['electricity',i=>'Campus electricity invoice · fictional sample', (m)=>m.electricity,'kWh'],
      ['water',i=>'Campus water meter · fictional sample',(m)=>m.water,'kL'],
      ['lab_condition',i=>'Monthly lab inspection recorded for demo; no open finding',()=>null,''],
      ['equipment_import',i=>'No imports; fictional sample register reviewed',()=>0,'items'],
      ['equipment_export',i=>'No exports; fictional sample register reviewed',()=>0,'items'],
      ['chemical_import',i=>'Fictional monthly chemical stock receipt',(m,i)=>12+i,'L'],
      ['chemical_export',i=>'Fictional authorized waste collection',(m,i)=>2+i%3,'L'],
      ['traffic',i=>'Main gate daily average · fictional sample',(m)=>m.traffic,'vehicles/day'],
      ['entry_exit',i=>'Daily access register average · fictional sample',(m)=>2780+i*70,'people/day'],
      ['occasion',i=>'Fictional campus calendar entry; demo only',()=>null,''],
      ['holiday',i=>'Fictional closure calendar review; demo only',()=>null,'']
    ];
    const now=new Date();
    for(let i=6;i>=1;i--){
      const d=new Date(now.getFullYear(),now.getMonth()-i,15),date=dateInput(d),m=monthly[6-i];
      entries.forEach(([category,detail,value,unit],j)=>data.history.push({id:'demo_history_'+date+'_'+category,date,category,block:category==='lab_condition'?'Block 1':'Campus',metric:category==='electricity'?'monthly total':category==='water'?'monthly total':category==='traffic'?'daily average':category==='entry_exit'?'daily average':'review',value:value(m,i-1),unit,details:detail(m,i-1),reference:'DEMO-SAMPLE-'+date+'-'+j,createdBy:'demo@infraiq.local',showcaseFictional:true}));
    }
    data.kitchen=[];
    for(let i=6;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i),date=dateInput(d);const prepared=185+(i%3)*12,waste=14+(i%4)*2;data.kitchen.push({id:'demo_kitchen_'+date,date,weekday:new Intl.DateTimeFormat('en-IN',{weekday:'long'}).format(d),menu:['Rice, dal, vegetables','Roti, paneer, salad','Idli, sambar, fruit'][i%3],preparedKg:prepared,wasteKg:waste,meals:430+i*3,note:'FICTIONAL DEMO RECORD',createdBy:'neha@infraiq.local',showcaseFictional:true});}
    const createdAt=new Date(Date.now()-18*60000).toISOString();
    data.incidents=[
      {id:'demo_incident_1',title:'Transformer vibration above usual level',category:'electrical',categoryLabel:'Electrical / transformer',block:'Block 5',severity:'Urgent',description:'FICTIONAL DEMO ONLY · Worker reports a new vibration and unusual humming at the transformer enclosure. No one has opened the equipment.',actionTaken:'Area kept clear; security supervisor notified.',observedAt:createdAt,startedAt:'',createdAt,reporterEmail:'aarav@infraiq.local',status:'Submitted',verified:false,expectedMinutes:15,triage:null},
      {id:'demo_incident_2',title:'Water use increased near Hostel A',category:'water',categoryLabel:'Water / plumbing',block:'Hostel A',severity:'High',description:'FICTIONAL DEMO ONLY · Meter reading is higher than the previous entered review.',actionTaken:'Facilities team asked to inspect safely.',observedAt:new Date(Date.now()-2*3600000).toISOString(),startedAt:'',createdAt:new Date(Date.now()-2*3600000).toISOString(),reporterEmail:'rohan@infraiq.local',status:'Acknowledged',acknowledgedAt:new Date(Date.now()-90*60000).toISOString(),acknowledgedBy:'mira@infraiq.local',verified:false,expectedMinutes:60,triage:null}
    ];
    data.maintenance=[{id:'demo_ticket_1',title:'Inspect transformer T-1 vibration report',assetId:'demo_asset_1',assetName:'Main transformer T-1',block:'Block 5',priority:'Urgent',status:'Open',dueDate:dateInput(new Date()),assignedTo:'mira@infraiq.local',description:'Fictional showcase ticket. Keep people clear; authorized engineer inspection only.',createdAt,showcaseFictional:true}];
    data.shifts=[];data.activeShifts=[];data.activeShift=null;
    try{localStorage.setItem(PROFILE_KEY,JSON.stringify(profile));localStorage.setItem(DATA_KEY,JSON.stringify(data));}catch{}
  }
  seedShowcaseData();
  const ui = { page: 'command', signupStep: 'identity', authMode:'signup', error: '', toast: '', rotation: 0, timer: null, sessionId:id('tab'), lastTick:Date.now(), inviteResult:null, inviteCode:'', cloudState:'offline', confirmationPending:false, selectedBlock:'', explainOpen:'', assistantFeedback:{},healthReport:null,healthReportLoading:false,healthReportDraft:'',pendingDocument:null,voiceRecognition:null,maintenanceDraft:null,focusAssetId:'',simulationView:'overview',localAiLast:null,environmentAlerts:[],environmentStatus:'Waiting for a secure campus connection',environmentLastSync:'',environmentError:'',environmentChannel:null,environmentPollTimer:null };
  ui.healthReport=[...data.messages].reverse().find(m=>m.context==='campus_report'&&m.from==='assistant')||null;
  const blockShortcut=new URLSearchParams(location.search).get('block');
  if(blockShortcut){ui.reportBlock=blockShortcut;if(profile.signedIn)ui.page='staff';}
  const categoriesById = Object.fromEntries(categories.map(x => [x[0], x[1]]));
  const numericCategories = new Set(['electricity','water','traffic','equipment_import','equipment_export','chemical_import','chemical_export','entry_exit']);
  let channel;
  const cloud = window.InfraIQCloud || {configured:false,client:null};
  const cloudConfigured = !!cloud.configured;
  const cloudClient = cloud.client;
  const CLOUD_DRAFT_KEY = 'infraiq-cloud-signup-draft-v1';
  let cloudSession = null, cloudMembership = null, cloudCache = new Map(), cloudChannel = null, cloudSyncPromise = null, cloudSyncAgain = false;
  if(cloudConfigured&&!SHOWCASE_MODE)profile.signedIn=false;

  function read(key, fallback) {
    try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
    catch { return fallback; }
  }
  function esc(v) {
    return String(v == null ? '' : v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#39;');
  }
  function persistLocal() {
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
      localStorage.setItem(DATA_KEY, JSON.stringify(data));
      if (channel) channel.postMessage({ type: 'workspace-update', at: Date.now() });
      return true;
    } catch (e) {
      toast('Could not save: this browser may be out of storage. Export your records before continuing.');
      return false;
    }
  }
  function save() { const ok=persistLocal(); if(cloudSession&&profile.institutionId)queueCloudSync(); return ok; }
  function id(prefix) { return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function currentRole() { return roles[profile.role] || roles.admin; }
  function isLeader() { return ['admin','dean'].includes(profile.role); }
  function canManage() { return ['admin','dean','environmental','warden'].includes(profile.role); }
  function personKey() { return String(profile.email || '').trim().toLowerCase(); }
  function stewardshipQuote() {
    const quotes=[
      'A campus gets stronger every time someone notices a problem and shares it early.',
      'Care for a place is built from small, measured actions repeated every day.',
      'The best campus decisions begin with people who pay attention.'
    ];
    return quotes[Math.floor(Date.now()/86400000)%quotes.length];
  }
  function stewardshipQuoteMarkup() {
    return '<blockquote class="stewardship-quote">“'+esc(stewardshipQuote())+'”</blockquote><small class="quote-credit">A daily note from INFRAIQ</small>';
  }
  function environmentSeenKey() { return 'infraiq-environment-seen-v1:'+personKey(); }
  function seenEnvironmentAlertIds() { return read(environmentSeenKey(), []); }
  function unreadEnvironmentAlertCount() {
    const seen=new Set(seenEnvironmentAlertIds());
    return ui.environmentAlerts.filter(item=>!seen.has(item.id)).length;
  }
  function addSignInStewardshipQuote() {
    const art=ROOT.querySelector('.signup-art');if(!art||art.querySelector('.stewardship-quote'))return;
    const mark=art.querySelector('.signup-mark'),quote=document.createElement('blockquote'),credit=document.createElement('small');
    quote.className='stewardship-quote';quote.textContent='“'+stewardshipQuote()+'”';credit.className='quote-credit';credit.textContent='A daily note from INFRAIQ';
    art.insertBefore(quote,mark||null);art.insertBefore(credit,mark||null);
  }
  function updateEnvironmentAlertBadge() {
    const count=unreadEnvironmentAlertCount();
    let pill=ROOT.querySelector('[data-environment-alert-pill]');
    if(count&&!pill) {
      pill=document.createElement('button');pill.type='button';pill.className='environment-alert-pill';pill.dataset.environmentAlertPill='true';pill.dataset.action='go';pill.dataset.page='environment';
      ROOT.querySelector('.topbar .top-spacer')?.before(pill);
    }
    if(pill) {
      if(count){pill.textContent='◌ '+count+' environment update'+(count===1?'':'s');pill.hidden=false;}
      else pill.remove();
    }
    const nav=ROOT.querySelector('.nav-link[data-page="environment"]');
    let badge=nav?.querySelector('[data-environment-count]');
    if(count&&nav&&!badge){badge=document.createElement('i');badge.dataset.environmentCount='true';nav.append(badge);}
    if(badge){if(count)badge.textContent=String(count);else badge.remove();}
  }
  function markEnvironmentAlertsRead() {
    const ids=new Set(seenEnvironmentAlertIds());
    ui.environmentAlerts.forEach(item=>ids.add(item.id));
    try { localStorage.setItem(environmentSeenKey(),JSON.stringify([...ids].slice(-150))); } catch {}
    updateEnvironmentAlertBadge();
  }
  function dateInput(date) {
    const d = date || new Date();
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  }
  function localDateTimeInput(date) {
    const d = date || new Date();
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }
  function validDateOnly(value) {
    const parts=String(value||'').split('-').map(Number);
    if(parts.length!==3||parts.some(x=>!Number.isInteger(x)))return false;
    const [year,month,day]=parts,check=new Date(Date.UTC(year,month-1,day));
    return check.getUTCFullYear()===year&&check.getUTCMonth()===month-1&&check.getUTCDate()===day;
  }
  function fmtDate(value, withTime) {
    if (!value) return 'Not recorded';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return esc(value);
    return new Intl.DateTimeFormat('en-IN', withTime ? {dateStyle:'medium',timeStyle:'short'} : {dateStyle:'medium'}).format(d);
  }
  function fmtNumber(value, digits) {
    if (!Number.isFinite(Number(value))) return '—';
    return new Intl.NumberFormat('en-IN', {maximumFractionDigits:digits == null ? 1 : digits}).format(Number(value));
  }
  function notify(text) {
    ui.toast = text;
    const el = document.getElementById('toast');
    if (el) { el.textContent = text; el.classList.add('show'); }
    window.clearTimeout(ui.timer);
    ui.timer = window.setTimeout(() => document.getElementById('toast')?.classList.remove('show'), 3400);
  }
  const toast = notify;
  function cloudOwnerFor(item) {
    const email=String(item.reporterEmail||item.createdBy||item.email||personKey()).toLowerCase();
    return data.crew.find(m=>String(m.email||'').toLowerCase()===email)?.userId || (email===personKey()?cloudSession?.user?.id:null) || cloudSession?.user?.id;
  }
  function desiredCloudRecords() {
    const all=[];
    const add=(kind,rows)=>rows.forEach(item=>{if(item&&item.id!=null)all.push({institution_id:profile.institutionId,id:String(item.id),kind,owner_id:cloudOwnerFor(item),payload:item});});
    add('block',data.blocks);add('equipment',data.equipment);add('incident',data.incidents);add('maintenance_ticket',data.maintenance);add('completed_shift',data.shifts);add('kitchen',data.kitchen);add('institution_history',data.history);add('simulation_run',data.simulationRuns);add('resource_source',data.resourceSources);add('resource_observation',data.resourceObservations);
    const active=data.activeShifts.slice();
    if(data.activeShift&&!active.some(x=>x.id===data.activeShift.id))active.push(data.activeShift);
    add('active_shift',active);
    return all;
  }
  async function syncCloudRecords() {
    if(!cloudSession||!profile.institutionId||!cloudClient)return true;
    const desired=desiredCloudRecords(),next=new Map(desired.map(row=>[row.id,row]));
    try {
      ui.cloudState='syncing';
      for(const [key,row] of next) {
        const old=cloudCache.get(key);
        const same=old&&old.kind===row.kind&&old.owner_id===row.owner_id&&JSON.stringify(old.payload)===JSON.stringify(row.payload);
        if(same)continue;
        const saved={...row,owner_id:old?.owner_id||row.owner_id};
        let error,serverRow=null;
        if(old?.kind==='active_shift'&&row.kind==='completed_shift') {
          const result=await cloudClient.from('workspace_records').update({kind:row.kind,payload:row.payload})
            .eq('institution_id',profile.institutionId).eq('id',row.id)
            .select('institution_id,id,kind,owner_id,payload,created_at,updated_at').single();
          error=result.error;
          if(!error){serverRow=result.data;cloudCache.set(key,{...result.data});}
        } else {
          const result=await cloudClient.from('workspace_records').upsert(saved,{onConflict:'institution_id,id'})
            .select('institution_id,id,kind,owner_id,payload,created_at,updated_at').single();
          error=result.error;
          if(!error){serverRow=result.data;cloudCache.set(key,{...result.data});}
        }
        if(error)throw error;
        if(row.kind==='active_shift'&&serverRow?.payload?.startedAt) {
          const active=data.activeShifts.find(x=>x.id===row.id);
          if(active)active.startedAt=serverRow.payload.startedAt;
          if(data.activeShift?.id===row.id)data.activeShift.startedAt=serverRow.payload.startedAt;
          persistLocal();
        }
      }
      for(const [key,old] of [...cloudCache]) {
        if(next.has(key))continue;
        const {error}=await cloudClient.from('workspace_records').delete().eq('institution_id',profile.institutionId).eq('id',old.id);
        if(error)throw error;
        cloudCache.delete(key);
      }
      ui.cloudState='connected';ui.lastCloudSync=new Date().toISOString();return true;
    } catch(error) {
      console.error('INFRAIQ cloud sync failed',error);
      const wasError=ui.cloudState==='error';ui.cloudState='error';
      if(!wasError)toast('Saved in this browser, but Supabase rejected the change. Check role access and connection.');
      return false;
    }
  }
  function queueCloudSync() {
    if(!cloudSession||!profile.institutionId)return Promise.resolve(true);
    if(cloudSyncPromise){cloudSyncAgain=true;return cloudSyncPromise;}
    cloudSyncPromise=(async()=>{let result=true;do{cloudSyncAgain=false;result=await syncCloudRecords();}while(cloudSyncAgain&&result);return result;})()
      .finally(()=>{cloudSyncPromise=null;if(ui.cloudState==='connected')render();});
    return cloudSyncPromise;
  }
  function recordPayload(row) { return {...(row.payload||{}),id:row.id}; }
  async function loadCloudWorkspace(quiet=false) {
    if(!cloudSession||!profile.institutionId)return false;
    try {
      ui.cloudState='loading';if(!quiet)render();
      const instId=profile.institutionId;
      const [campusRes,membersRes,recordsRes]=await Promise.all([
        cloudClient.from('institutions').select('*').eq('id',instId).single(),
        cloudClient.from('institution_members').select('user_id,role,block,info_xp,joined_at,profiles!institution_members_user_id_fkey(full_name,work_email)').eq('institution_id',instId).eq('is_active',true),
        cloudClient.from('workspace_records').select('id,kind,owner_id,payload,created_at,updated_at').eq('institution_id',instId)
      ]);
      if(campusRes.error)throw campusRes.error;if(membersRes.error)throw membersRes.error;if(recordsRes.error)throw recordsRes.error;
      const campus=campusRes.data;
      cloudMembership=(membersRes.data||[]).find(x=>x.user_id===cloudSession.user.id)||null;
      if(!cloudMembership)throw new Error('Your account is not an active member of this campus.');
      data.crew=(membersRes.data||[]).map(m=>{const p=Array.isArray(m.profiles)?m.profiles[0]:m.profiles||{};return {id:m.user_id,userId:m.user_id,name:p.full_name||p.work_email||'Campus team member',email:p.work_email||'',role:m.role,block:m.block||'',xp:m.info_xp||0,joinedAt:m.joined_at};});
      profile.institutionId=campus.id;profile.authUserId=cloudSession.user.id;profile.collegeName=campus.name;profile.city=campus.city;profile.region=campus.region;profile.address=campus.address||'';
      profile.latitude=campus.latitude==null?'':String(campus.latitude);profile.longitude=campus.longitude==null?'':String(campus.longitude);
      profile.campusSize=campus.campus_size==null?'':String(campus.campus_size);profile.blockCount=campus.block_count==null?'':String(campus.block_count);
      profile.electricityTariff=campus.electricity_tariff==null?'':String(campus.electricity_tariff);
      profile.alertThresholdPct=String(campus.usage_alert_threshold_pct||25);
      profile.opening=String(campus.opening||'08:00').slice(0,5);profile.closing=String(campus.closing||'18:00').slice(0,5);
      profile.role=cloudMembership.role;profile.personName=data.crew.find(x=>x.userId===cloudSession.user.id)?.name||cloudSession.user.user_metadata?.full_name||profile.personName;
      profile.email=String(cloudSession.user.email||'').toLowerCase();profile.completed=true;profile.signedIn=true;
      const rows=recordsRes.data||[];cloudCache=new Map(rows.map(r=>[r.id,{...r}]));
      const group=kind=>rows.filter(r=>r.kind===kind).map(recordPayload);
      data.blocks=group('block');data.equipment=group('equipment');data.incidents=group('incident').map(x=>{const row=rows.find(r=>r.kind==='incident'&&r.id===x.id);const reporter=data.crew.find(m=>m.userId===row?.owner_id);x.reporterEmail=reporter?.email||x.reporterEmail||'';x.triage=x.triage||incidentTriage(x);return x;});data.maintenance=group('maintenance_ticket');
      if(blockShortcut&&data.blocks.some(x=>x.name===blockShortcut)){ui.reportBlock=blockShortcut;ui.page='staff';}
      data.shifts=group('completed_shift').map(x=>{const row=rows.find(r=>r.kind==='completed_shift'&&r.id===x.id),member=data.crew.find(m=>m.userId===row?.owner_id);if(member){x.email=member.email;x.name=member.name;}return x;});
      data.activeShifts=group('active_shift').map(x=>{const row=rows.find(r=>r.kind==='active_shift'&&r.id===x.id),member=data.crew.find(m=>m.userId===row?.owner_id);if(member){x.email=member.email;x.name=member.name;}return x;});
      data.activeShift=data.activeShifts.find(x=>x.email===personKey())||null;
      data.kitchen=group('kitchen').map(x=>{const row=rows.find(r=>r.kind==='kitchen'&&r.id===x.id),member=data.crew.find(m=>m.userId===row?.owner_id);if(member)x.createdBy=member.email;return x;});
      data.history=group('institution_history');data.simulationRuns=group('simulation_run').map(x=>{const row=rows.find(r=>r.kind==='simulation_run'&&r.id===x.id),owner=data.crew.find(m=>m.userId===row?.owner_id);x.createdBy=owner?.email||'';return x;});data.resourceSources=group('resource_source').map(x=>{const row=rows.find(r=>r.kind==='resource_source'&&r.id===x.id),owner=data.crew.find(m=>m.userId===row?.owner_id);x.createdBy=owner?.email||'';return x;});data.resourceObservations=group('resource_observation').map(x=>{const row=rows.find(r=>r.kind==='resource_observation'&&r.id===x.id),owner=data.crew.find(m=>m.userId===row?.owner_id);x.createdBy=owner?.email||'';return x;});
      if(isLeader()) {
        const {data:invites,error}=await cloudClient.from('workspace_invites').select('id,invited_email,invited_name,invited_role,block,created_at,expires_at,claimed_at').eq('institution_id',instId).is('claimed_at',null).order('created_at',{ascending:false}).limit(30);
        if(!error)ui.invites=invites||[];
        const {data:audit,error:auditError}=await cloudClient.from('workspace_audit_log').select('id,record_id,record_kind,action,actor_id,changed_fields,occurred_at').eq('institution_id',instId).order('occurred_at',{ascending:false}).limit(100);
        if(auditError)throw auditError;
        ui.audit=audit||[];
      }
      ui.cloudState='connected';ui.lastCloudSync=new Date().toISOString();profile.signedIn=true;persistLocal();
      subscribeCloud();if(!quiet)render();return true;
    } catch(error) {
      console.error('INFRAIQ cloud load failed',error);ui.cloudState='error';ui.error=error.message||'Could not load the shared campus workspace.';if(!quiet)render();return false;
    }
  }
  async function loadEnvironmentAlerts(quiet=true) {
    if(!cloudSession||!cloudClient)return false;
    try {
      const since=new Date(Date.now()-60*86400000).toISOString();
      const {data:rows,error}=await cloudClient.from('environment_alerts')
        .select('id,source_name,title,summary,url,topic,headline_flag,published_at,detected_at')
        .gte('detected_at',since).order('published_at',{ascending:false,nullsFirst:false}).limit(30);
      if(error)throw error;
      ui.environmentAlerts=rows||[];ui.environmentLastSync=new Date().toISOString();ui.environmentError='';
      ui.environmentStatus='Shared official-source feed · connected';
      updateEnvironmentAlertBadge();
      if(ui.page==='environment')render();
      return true;
    } catch(error) {
      ui.environmentError=error.message||'The shared environment feed could not be loaded.';
      ui.environmentStatus='Environment feed setup needed';
      if(!quiet&&ui.page==='environment')render();
      return false;
    }
  }
  function subscribeEnvironmentAlerts() {
    if(!cloudSession||!cloudClient)return;
    loadEnvironmentAlerts(true);
    if(!ui.environmentChannel) {
      ui.environmentChannel=cloudClient.channel('infraiq-public-environment-alerts')
        .on('postgres_changes',{event:'INSERT',schema:'public',table:'environment_alerts'},event=>{
          const item=event.new;if(!item?.id)return;
          ui.environmentAlerts=[item,...ui.environmentAlerts.filter(x=>x.id!==item.id)].slice(0,30);
          ui.environmentLastSync=new Date().toISOString();ui.environmentError='';
          updateEnvironmentAlertBadge();
          const seen=new Set(seenEnvironmentAlertIds());
          if(ui.page==='environment')render();
          if(!seen.has(item.id)) {
            toast((item.headline_flag?'ENVIRONMENT HEADLINE · ':'ENVIRONMENT UPDATE · ')+item.title);
            if('Notification'in window&&Notification.permission==='granted')new Notification('INFRAIQ · Environment update',{body:item.title,tag:item.id});
          }
        }).subscribe(status=>{
          if(status==='SUBSCRIBED')ui.environmentStatus='Shared official-source feed · live';
          else if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')ui.environmentStatus='Live feed reconnecting · recent alerts remain available';
          if(ui.page==='environment')render();
        });
    }
    if(!ui.environmentPollTimer)ui.environmentPollTimer=window.setInterval(()=>loadEnvironmentAlerts(true),5*60*1000);
  }
  async function refreshEnvironmentFeed() {
    if(!cloudSession) { toast('Shared environmental alerts need a signed-in Supabase campus account. Official AQI and forecast links are available below.');return; }
    const buttonNode=ROOT.querySelector('[data-action="refresh-environment-feed"]');
    if(buttonNode){buttonNode.disabled=true;buttonNode.textContent='Checking official releases…';}
    ui.environmentStatus='Checking the official headline feed…';
    try {
      const sessionResult=await cloudClient.auth.getSession(),token=sessionResult?.data?.session?.access_token||cloudSession?.access_token;
      if(sessionResult?.error||!token)throw new Error('Your sign-in expired. Sign in again to refresh the shared environment feed.');
      const response=await fetch('/api/environment-monitor',{method:'GET',headers:{Authorization:'Bearer '+token}});
      let result={};try{result=await response.json();}catch{}
      if(!response.ok)throw new Error(result.error||'The official news feed is temporarily unavailable.');
      await loadEnvironmentAlerts(true);ui.environmentStatus='Official headline check completed';
      render();toast('Official releases checked · '+Number(result.newAlerts||0)+' new environment update(s) shared with campus members.');
    } catch(error) {
      ui.environmentError=error.message||'The official news feed could not be refreshed.';ui.environmentStatus='Unable to refresh the official feed';
      render();toast(ui.environmentError);
    }
  }
  async function activateCloudSession(session) {
    cloudSession=session||null;
    if(!cloudSession)return;
    const draft=read(CLOUD_DRAFT_KEY,{}),user=cloudSession.user;
    profile.authUserId=user.id;profile.email=String(user.email||'').toLowerCase();
    profile.personName=draft.personName||user.user_metadata?.full_name||profile.personName||'';
    ui.error='';ui.confirmationPending=false;
    const {data:member,error}=await cloudClient.from('institution_members').select('institution_id,role,block').eq('user_id',user.id).eq('is_active',true).maybeSingle();
    if(error){ui.cloudState='error';ui.error=error.message;render();return;}
    if(!member&&draft.inviteCode) {
      const {error:inviteError}=await cloudClient.rpc('claim_infraiq_invite',{p_code:draft.inviteCode,p_full_name:profile.personName});
      if(inviteError){ui.error=inviteError.message;ui.signupStep='campus';ui.inviteCode=draft.inviteCode;render();return;}
      localStorage.removeItem(CLOUD_DRAFT_KEY);
      const claimed=await cloudClient.from('institution_members').select('institution_id,role,block').eq('user_id',user.id).eq('is_active',true).maybeSingle();
      if(claimed.error||!claimed.data){ui.error=claimed.error?.message||'The invitation was accepted but membership could not be loaded.';render();return;}
      profile.institutionId=claimed.data.institution_id;profile.role=claimed.data.role;profile.completed=true;profile.signedIn=true;ui.page='command';await loadCloudWorkspace();return;
    }
    if(member){profile.institutionId=member.institution_id;profile.role=member.role;profile.completed=true;profile.signedIn=true;localStorage.removeItem(CLOUD_DRAFT_KEY);ui.page='command';await loadCloudWorkspace();return;}
    if(draft.collegeName)Object.assign(profile,{collegeName:draft.collegeName,city:draft.city||'',region:draft.region||'',address:draft.address||'',campusSize:draft.campusSize||'',blockCount:draft.blockCount||'',opening:draft.opening||'08:00',closing:draft.closing||'18:00'});
    ui.signupStep='campus';ui.inviteCode=draft.inviteCode||'';profile.completed=false;profile.signedIn=false;ui.cloudState='connected';render();
  }
  async function initializeCloud() {
    if(!cloudConfigured||!cloudClient)return;
    ui.cloudState='connecting';
    cloud.onAuthStateChange((event,session)=>{
      if(event==='SIGNED_OUT'){cloudSession=null;profile.signedIn=false;render();}
      else if(event==='PASSWORD_RECOVERY'){cloudSession=session;ui.resetPassword=true;render();}
      else if(session)cloudSession=session;
    });
    const {data,error}=await cloudClient.auth.getSession();
    if(error){ui.cloudState='error';ui.error=error.message;render();return;}
    if(data.session)await activateCloudSession(data.session);else {ui.cloudState='offline';render();}
  }
  function subscribeCloud() {
    if(!cloudSession||!profile.institutionId)return;
    subscribeEnvironmentAlerts();
    if(cloudChannel)return;
    cloudChannel=cloudClient.channel('infra-campus-'+profile.institutionId).on('postgres_changes',{
      event:'*',schema:'public',table:'workspace_records',filter:'institution_id=eq.'+profile.institutionId
    },event=>{
      if(cloudSyncPromise)return;
      const row=event.new||event.old;
      if(event.eventType==='INSERT'&&row?.kind==='incident'){
        const title=row.payload?.title||'New campus report',place=row.payload?.block||'Campus';
        toast((row.payload?.severity==='Urgent'?'URGENT · ':'')+title+' · '+place);
        if(['Urgent','High'].includes(row.payload?.severity)&&'Notification'in window&&Notification.permission==='granted')new Notification('INFRAIQ · '+row.payload.severity+' report',{body:title+' · '+place,tag:row.id});
      }
      clearTimeout(ui.remoteRefreshTimer);ui.remoteRefreshTimer=setTimeout(()=>{if(!cloudSyncPromise)loadCloudWorkspace(true);},500);
    }).on('postgres_changes',{
      event:'*',schema:'public',table:'institution_members',filter:'institution_id=eq.'+profile.institutionId
    },()=>{clearTimeout(ui.remoteRefreshTimer);ui.remoteRefreshTimer=setTimeout(()=>{if(!cloudSyncPromise)loadCloudWorkspace(true);},350);}).on('postgres_changes',{
      event:'UPDATE',schema:'public',table:'institutions',filter:'id=eq.'+profile.institutionId
    },()=>{clearTimeout(ui.remoteRefreshTimer);ui.remoteRefreshTimer=setTimeout(()=>{if(!cloudSyncPromise)loadCloudWorkspace(true);},350);}).subscribe(status=>{
      if(status==='SUBSCRIBED'){ui.cloudState='connected';render();}
      else if(status==='CHANNEL_ERROR'||status==='TIMED_OUT'){ui.cloudState='error';render();}
    });
  }
  function reporterName(email) {
    const member = data.crew.find(x => String(x.email).toLowerCase() === String(email || '').toLowerCase());
    return member?.name || (email === personKey() ? profile.personName : 'Workspace member');
  }
  function ensureCrewMember() {
    const email = personKey();
    if (!email) return;
    let member = data.crew.find(x => String(x.email).toLowerCase() === email);
    if (!member) {
      member = { id:id('crew'), name:profile.personName || email, email, role:profile.role, block:'', xp:0, joinedAt:new Date().toISOString() };
      data.crew.push(member);
    } else {
      member.name = profile.personName || member.name;
      member.role = profile.role;
    }
    save();
  }
  function memberFor(email) {
    return data.crew.find(x => String(x.email).toLowerCase() === String(email || '').toLowerCase());
  }
  function memberRank(xp) {
    const level = 1 + Math.floor(Math.max(0, Number(xp) || 0) / 100);
    const name = level >= 6 ? 'Campus champion' : level >= 4 ? 'Field lead' : level >= 3 ? 'Senior responder' : level >= 2 ? 'Responder' : 'New reporter';
    return {level, name};
  }
  function currentMember() { return memberFor(personKey()); }
  function activeShiftFor(email) {
    const key=String(email||personKey()).toLowerCase();
    return data.activeShifts.find(x=>String(x.email||'').toLowerCase()===key) || (data.activeShift&&String(data.activeShift.email||'').toLowerCase()===key?data.activeShift:null);
  }
  function openIncidents() { return data.incidents.filter(x => !['Resolved','Closed'].includes(x.status)); }
  function unresolvedCount() { return openIncidents().length; }
  function navForRole() { const allowed = rolePages[profile.role] || rolePages.admin; return nav.filter(n => allowed.includes(n[0])); }
  function button(label, action, cls, extra) {
    return '<button type=\"button\" class=\"button ' + esc(cls || '') + '\" data-action=\"' + esc(action) + '\" ' + (extra || '') + '>' + label + '</button>';
  }
  function head(kicker, title, subtitle, actions) {
    return '<div class=\"page-head\"><div><div class=\"eyebrow\">' + esc(kicker) + '</div><h1>' + esc(title) + '</h1><p>' + esc(subtitle) + '</p></div><div class=\"head-actions\">' + (actions || '') + '</div></div>';
  }
  function field(label, name, type, value, placeholder, required, extra) {
    return '<label class=\"field\">' + esc(label) + '<input name=\"' + esc(name) + '\" type=\"' + esc(type || 'text') + '\" value=\"' + esc(value || '') + '\" placeholder=\"' + esc(placeholder || '') + '\" ' + (required ? 'required' : '') + ' ' + (extra || '') + '></label>';
  }
  function selectField(label, name, entries, selected) {
    return '<label class=\"field\">' + esc(label) + '<select name=\"' + esc(name) + '\">' + entries.map(x => '<option value=\"' + esc(x[0]) + '\" ' + (x[0] === selected ? 'selected' : '') + '>' + esc(x[1]) + '</option>').join('') + '</select></label>';
  }
  function blockOptions(includeUnassigned) {
    const opts = data.blocks.map(b => [b.name, b.name]);
    if (includeUnassigned || !opts.length) opts.unshift(['', 'Campus / not specified']);
    return opts;
  }
  function requiredMonths() {
    const now = new Date();
    const first = new Date(now.getFullYear(), now.getMonth() - 6, 1);
    return Array.from({length:6}, (_, i) => {
      const d = new Date(first.getFullYear(), first.getMonth() + i, 1);
      return {key:d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'), label:new Intl.DateTimeFormat('en-IN',{month:'short',year:'numeric'}).format(d)};
    });
  }
  function historyReadiness() {
    const months = requiredMonths();
    const status = months.map(m => {
      const present = new Set(data.history.filter(r => String(r.date).slice(0,7) === m.key).map(r => r.category));
      const missing = categories.filter(c => !present.has(c[0])).map(c => c[1]);
      return Object.assign({}, m, {missing, count:data.history.filter(r => String(r.date).slice(0,7) === m.key).length});
    });
    const expected = months.length * categories.length;
    const complete = status.every(x => !x.missing.length);
    return {months:status, complete, expected, records:data.history.length, ratio:expected ? Math.min(1, status.reduce((n,m) => n + categories.length - m.missing.length, 0) / expected) : 0};
  }
  function categoryRecords(category) {
    return data.history.filter(r => r.category === category && Number.isFinite(Number(r.value)) && r.value !== '' && r.value !== null)
      .sort((a,b) => a.date.localeCompare(b.date));
  }
  function monthlyActual(category) {
    const rows = categoryRecords(category), byMonth = new Map();
    rows.forEach(r => {
      const month = String(r.date).slice(0,7);
      const item = byMonth.get(month) || {month, values:[], unit:r.unit || '', mixedUnits:false};
      if(item.values.length&&(item.unit||'')!==(r.unit||''))item.mixedUnits=true;
      if(!item.unit&&r.unit)item.unit=r.unit;
      item.values.push(Number(r.value)); byMonth.set(month,item);
    });
    return Array.from(byMonth.values()).sort((a,b)=>a.month.localeCompare(b.month)).map(x=>({month:x.month,value:x.values.reduce((s,v)=>s+v,0)/x.values.length,unit:x.unit,count:x.values.length,mixedUnits:x.mixedUnits}));
  }
  function forecastMonthly(category) {
    const rows = monthlyActual(category).slice(-6);
    if (rows.length < 3 || rows.some(x=>x.mixedUnits)) return null;
    const n = rows.length, ys = rows.map(x=>x.value), xm=(n-1)/2, ym=ys.reduce((s,v)=>s+v,0)/n;
    const den=ys.reduce((s,_,i)=>s+(i-xm)*(i-xm),0);
    const slope=den ? ys.reduce((s,v,i)=>s+(i-xm)*(v-ym),0)/den : 0;
    const pred=Math.max(0,ym+slope*(n-xm));
    const residual=ys.map((v,i)=>v-(ym+slope*(i-xm)));
    const sd=Math.sqrt(residual.reduce((s,v)=>s+v*v,0)/Math.max(1,n-2));
    return {value:pred,low:Math.max(0,pred-1.28*sd),high:pred+1.28*sd,unit:rows.at(-1)?.unit||'',history:rows};
  }
  function incidentTriage(x) {
    const category = x.category;
    const playbooks = {
      electrical: ['Possible causes: overload, insulation or connection failure, transformer protection trip, moisture, or a nearby cable fault. Treat these as possibilities until inspected by an authorized electrical engineer.',
        'Potential consequences: shock, fire, equipment damage, or interruption to dependent buildings. Actual impact depends on the transformer and connected loads.',
        'Response: keep people clear; do not touch, open, or reset the transformer. Alert the administrator and authorized electrical team now. If smoke, fire, or injury is present, use the campus emergency procedure and call local emergency services.'],
      water: ['Possible causes: leaking pipe or valve, tank overflow, pump/control fault, or unusually high demand. Confirm with the meter and site inspection.',
        'Potential consequences: water loss, damp or slip hazards, and service interruption if the affected supply is isolated.',
        'Response: warn nearby occupants, protect electrical areas, and ask authorized facilities staff to inspect and isolate the correct line. Do not enter a flooded electrical space.'],
      lab: ['Possible causes: instrument malfunction, ventilation issue, storage or handling error, or a process deviation. The report alone cannot establish a chemical cause.',
        'Potential consequences: exposure, contamination, equipment damage, or lab downtime depending on the material and condition.',
        'Response: stop the affected activity if safe, keep others away, notify the lab supervisor and safety officer, and follow the chemical-specific safety data sheet and site emergency procedure. Do not handle an unknown spill.'],
      security: ['Possible causes: access-control fault, door/lock issue, unauthorized entry, or an incomplete handover. Verify against the approved access log and camera procedure.',
        'Potential consequences: unauthorized access or risk to people/property; severity depends on the location and what was observed.',
        'Response: follow the campus security protocol, keep a safe distance, alert the shift supervisor, and contact emergency services for immediate danger. Do not confront a suspected intruder alone.'],
      fire: ['Possible causes: electrical fault, hot work, cooking, equipment overheating, or another ignition source. The source must be confirmed by responders.',
        'Potential consequences: injury, smoke exposure, fire spread, and evacuation or service interruption.',
        'Response: raise the campus alarm, evacuate by the approved route, keep clear of responders, and call local emergency services. Use an extinguisher only if trained and the exit remains clear.'],
      equipment: ['Possible causes: wear, overheating, misconfiguration, blockage, or loss of supply. Preserve the observed status for inspection.',
        'Potential consequences: reduced service, damage to connected equipment, or an unsafe condition depending on the asset.',
        'Response: keep people clear of moving or energized parts and assign an authorized technician to inspect and isolate the asset as required.'],
      other: ['Possible causes: not enough evidence yet. Record the visible indicators and check recent work orders, logs, and nearby observations.',
        'Potential consequences: depend on the location and duration. Escalate promptly if safety, essential services, or occupants may be affected.',
        'Response: keep people safe, notify the responsible supervisor, preserve evidence, and request an on-site check.']
    };
    const play = playbooks[category] || playbooks.other;
    const noticed = x.observedAt ? fmtDate(x.observedAt,true) : fmtDate(x.createdAt,true);
    let duration = 'Onset is unknown. The report confirms only that it was first noticed at ' + noticed + '. Check meter, access, maintenance, or incident logs to determine when it began.';
    if (x.startedAt) {
      const hours = Math.max(0, (new Date(x.observedAt || x.createdAt) - new Date(x.startedAt)) / 3600000);
      duration = 'Reporter-entered onset: ' + fmtDate(x.startedAt,true) + ' — about ' + fmtNumber(hours,1) + ' hours before first notice. This interval is unverified.';
    }
    return {problem:x.description, causes:play[0], duration, consequences:play[1], response:play[2], certainty:'Triage checklist · causes and consequences are unconfirmed until a qualified person verifies them.'};
  }
  function actualLatest(category) {
    return categoryRecords(category).at(-1) || null;
  }
  function metricLabel(r) {
    if (!r) return 'No institution record';
    return fmtNumber(r.value,2) + (r.unit ? ' ' + r.unit : '');
  }
  function activeHours() {
    const active=activeShiftFor();if(!active)return 0;
    return Math.max(0,(Date.now()-new Date(active.startedAt).getTime())/3600000);
  }
  function shiftTimeLabel() {
    const active=activeShiftFor();if(!active)return 'Not clocked in';
    let ms=Number(active.elapsedMs)||0;
    if(active.sessionId===ui.sessionId&&document.visibilityState==='visible')ms+=Math.max(0,Date.now()-ui.lastTick);
    else ms=Math.max(ms,Date.now()-new Date(active.startedAt).getTime());
    const mins = Math.floor(ms/60000);
    return String(Math.floor(mins/60)).padStart(2,'0') + ':' + String(mins%60).padStart(2,'0') + ' on shift';
  }
  function dataProfileCard() {
    const readiness = historyReadiness();
    return '<section class=\"card readiness-card\"><div class=\"readiness-top\"><div><div class=\"eyebrow\">INSTITUTION RECORDS</div><h2>Six-month data readiness</h2><p>Forecasts unlock only after all ' + categories.length + ' required categories are represented in each of the six completed months.</p></div><span class=\"readiness-score\">' + Math.round(readiness.ratio*100) + '%</span></div><div class=\"progress-track\"><span style=\"width:' + Math.round(readiness.ratio*100) + '%\"></span></div><div class=\"readiness-bottom\"><span>' + readiness.records + ' institution records</span><span>' + (readiness.complete ? 'Coverage complete · projections available' : 'Missing category/month coverage') + '</span><button class=\"button small\" data-action=\"go\" data-page=\"history\">Review required data ↗</button></div></section>';
  }
  function statCard(label, value, note, symbol) {
    return '<article class=\"card stat-card\"><div class=\"stat-symbol\">' + symbol + '</div><div class=\"stat-label\">' + esc(label) + '</div><div class=\"stat-value\">' + esc(value) + '</div><div class=\"stat-note\">' + esc(note) + '</div></article>';
  }
  function pathLine(values, width, height, color) {
    if (!values.length) return '';
    const vals=values.map(x=>Number(x.value)), min=Math.min(...vals), max=Math.max(...vals), span=max-min||1;
    const pts=vals.map((v,i)=>[32+i*(width-52)/Math.max(1,vals.length-1), height-28-(v-min)/span*(height-54)]);
    const path=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ');
    const dots=pts.map((p,i)=>'<circle cx=\"'+p[0]+'\" cy=\"'+p[1]+'\" r=\"4\" fill=\"'+color+'\"><title>'+esc(values[i].month+': '+fmtNumber(values[i].value,2)+' '+values[i].unit)+'</title></circle>').join('');
    const labels=values.map((x,i)=>'<text x=\"'+pts[i][0]+'\" y=\"'+(height-7)+'\" text-anchor=\"middle\">'+esc(x.month.slice(5))+'</text>').join('');
    return '<svg class=\"trend-svg\" viewBox=\"0 0 '+width+' '+height+'\" role=\"img\" aria-label=\"Measured institution data trend\"><path d=\"M32 18V'+(height-28)+'H'+(width-12)+'\" class=\"chart-axis\"/><path d=\"'+path+'\" class=\"chart-line\" stroke=\"'+color+'\"/><path d=\"'+path+'\" class=\"chart-glow\" stroke=\"'+color+'\"/>'+dots+labels+'</svg>';
  }
  function piePath(cx,cy,r,start,end,inner) {
    const a=start*Math.PI/180,b=end*Math.PI/180, large=end-start>180?1:0;
    const x1=cx+r*Math.cos(a),y1=cy+r*Math.sin(a),x2=cx+r*Math.cos(b),y2=cy+r*Math.sin(b);
    if (inner) {
      const ix2=cx+inner*Math.cos(b),iy2=cy+inner*Math.sin(b),ix1=cx+inner*Math.cos(a),iy1=cy+inner*Math.sin(a);
      return 'M '+x1+' '+y1+' A '+r+' '+r+' 0 '+large+' 1 '+x2+' '+y2+' L '+ix2+' '+iy2+' A '+inner+' '+inner+' 0 '+large+' 0 '+ix1+' '+iy1+' Z';
    }
    return 'M '+cx+' '+cy+' L '+x1+' '+y1+' A '+r+' '+r+' 0 '+large+' 1 '+x2+' '+y2+' Z';
  }
  function donut(values, title) {
    const rows=values.filter(x=>Number(x.value)>0);
    const total=rows.reduce((s,x)=>s+Number(x.value),0);
    if (!total) return '<div class=\"chart-empty\"><span>◌</span><strong>No records to chart yet</strong><p>Charts appear when the team enters institution data.</p></div>';
    const colors=['#77e7bc','#f2a45f','#89b4ff','#ed7186','#d1c475','#9f88df'];
    let cursor=-90;
    const arcs=rows.map((x,i)=>{
      const angle=Number(x.value)/total*360, start=cursor, end=cursor+angle;cursor=end;
      return '<path d=\"'+piePath(135,83,62,start,end,37)+'\" fill=\"'+colors[i%colors.length]+'\" class=\"pie-slice\"><title>'+esc(x.label)+': '+fmtNumber(x.value,1)+'</title></path>';
    }).join('');
    const legend=rows.map((x,i)=>'<div class=\"legend-item\"><i style=\"background:'+colors[i%colors.length]+'\"></i><span>'+esc(x.label)+'</span><b>'+fmtNumber(x.value,1)+'</b></div>').join('');
    return '<div class=\"donut-layout\"><div class=\"donut-stage\"><svg viewBox=\"0 0 270 180\" role=\"img\" aria-label=\"'+esc(title)+' measured records\"><ellipse cx=\"135\" cy=\"95\" rx=\"62\" ry=\"20\" fill=\"#050908\" opacity=\".8\"/><g class=\"donut-rotor\" style=\"--chart-rotation:'+ui.rotation+'deg\"><g transform=\"translate(0 27) scale(1 .68) translate(0 -27)\">'+rows.map((x,i)=>{const angle=Number(x.value)/total*360;const start=-90+rows.slice(0,i).reduce((s,v)=>s+Number(v.value)/total*360,0);return '<path d=\"'+piePath(135,83,62,start,start+angle,37)+'\" transform=\"translate(0 9)\" fill=\"#26332f\"/>';}).join('')+arcs+'</g></g><text x=\"135\" y=\"80\" text-anchor=\"middle\" class=\"donut-total\">'+fmtNumber(total,1)+'</text><text x=\"135\" y=\"98\" text-anchor=\"middle\" class=\"donut-caption\">RECORDED</text></svg></div><div class=\"donut-legend\">'+legend+'</div></div>';
  }
  function actualChartCard(title, category, description, color) {
    const rows=monthlyActual(category).slice(-6);
    if(rows.some(x=>x.mixedUnits)) return '<section class="card chart-card"><div class="card-head"><div><h2>'+esc(title)+'</h2><p>'+esc(description)+'</p></div><span class="data-tag">INSTITUTION DATA</span></div><div class="chart-empty"><strong>Units differ across these records</strong><p>Use a consistent unit before combining values in one chart.</p></div></section>';
    return '<section class=\"card chart-card\"><div class=\"card-head\"><div><h2>'+esc(title)+'</h2><p>'+esc(description)+'</p></div><span class=\"data-tag\">INSTITUTION DATA</span></div>'+(rows.length ? pathLine(rows,520,190,color||'#77e7bc') : '<div class=\"chart-empty\"><span>⌁</span><strong>No '+esc(title.toLowerCase())+' readings</strong><p>Upload or enter dated records to draw this chart.</p></div>')+'</section>';
  }
  function forecastPlot(f,color) {
    if(!f?.history?.length)return '';
    const vals=f.history.map(x=>Number(x.value)).concat(Number(f.value)),min=Math.min(...vals,Number(f.low)),max=Math.max(...vals,Number(f.high)),span=max-min||1,w=520,h=145;
    const x=i=>32+i*(w-54)/Math.max(1,vals.length-1),y=v=>h-24-(v-min)/span*(h-46);
    const actual=f.history.map((v,i)=>(i?'L':'M')+x(i).toFixed(1)+','+y(v.value).toFixed(1)).join(' '),forecastStart=f.history.length-1;
    const projected='M'+x(forecastStart).toFixed(1)+','+y(f.history.at(-1).value).toFixed(1)+' L'+x(vals.length-1).toFixed(1)+','+y(f.value).toFixed(1);
    const bandX=x(vals.length-1),bandY=y(f.high),bandH=Math.max(2,y(f.low)-bandY);
    const labels=f.history.map((v,i)=>'<text x="'+x(i)+'" y="'+(h-5)+'" text-anchor="middle">'+esc(v.month.slice(5))+'</text>').join('')+'<text x="'+x(vals.length-1)+'" y="'+(h-5)+'" text-anchor="middle">NEXT</text>';
    return '<svg class="trend-svg forecast-plot" viewBox="0 0 '+w+' '+h+'" role="img" aria-label="Actual monthly records and next month trend baseline"><path d="M32 18V'+(h-24)+'H'+(w-12)+'" class="chart-axis"/><rect x="'+(bandX-10)+'" y="'+bandY+'" width="20" height="'+bandH+'" rx="6" class="forecast-band"/><path d="'+actual+'" class="chart-line" stroke="'+color+'"/><path d="'+projected+'" class="forecast-line" stroke="'+color+'"/><circle cx="'+bandX+'" cy="'+y(f.value)+'" r="4" fill="'+color+'"><title>Next month baseline '+fmtNumber(f.value,1)+' '+esc(f.unit)+'</title></circle>'+labels+'</svg>';
  }
  function periodComparison(category,label) {
    const rows=categoryRecords(category);if(!rows.length)return '';
    const unit=rows.at(-1).unit||'',same=rows.filter(x=>(x.unit||'')===unit),now=new Date(),start=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime(),day=86400000;
    const windowStats=(from,to)=>{const vals=same.filter(r=>{const t=new Date(r.date+'T12:00:00').getTime();return t>=from&&t<to;}).map(r=>Number(r.value||0));return {count:vals.length,mean:vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0};};
    const cur=windowStats(start-7*day,start+day),prev=windowStats(start-14*day,start-7*day),current=cur.mean,previous=prev.mean,currCount=cur.count,prevCount=prev.count;
    if(!currCount||!prevCount)return '';
    const delta=previous===0?null:(current-previous)/Math.abs(previous)*100;
    return '<article class="period-chip"><span>'+esc(label)+' · mean of dated readings in 7 day window</span><b>'+fmtNumber(current,1)+' '+esc(unit)+'</b><small>Prior window mean: '+fmtNumber(previous,1)+' '+esc(unit)+(delta===null?'': ' · '+(delta>=0?'+':'')+fmtNumber(delta,0)+'%')+' · '+currCount+' / '+prevCount+' readings; not normalized by block occupancy</small></article>';
  }
  function electricityCostCard(){
    const rate=Number(profile.electricityTariff),row=actualLatest('electricity'),unit=String(row?.unit||'').trim().toLowerCase();
    if(!(rate>0)||!row||unit!=='kwh')return '<section class="card cost-nudge"><div><div class="eyebrow">ELECTRICITY COST · OPTIONAL</div><b>No tariff estimate yet</b><p>Enter your billed ₹/kWh rate and a measured kWh value in Campus Profile and Six-month data. No charge is assumed.</p></div><button class="button small" data-action="go" data-page="campus">Add tariff ↗</button></section>';
    return '<section class="card cost-estimate"><div><div class="eyebrow">RECORD-BASED COST ESTIMATE · NOT AN INVOICE</div><b>₹'+fmtNumber(Number(row.value)*rate,2)+'</b><p>'+fmtNumber(row.value,1)+' kWh on '+fmtDate(row.date)+' × entered tariff ₹'+fmtNumber(rate,2)+'/kWh. Taxes, demand/fixed charges, and billing adjustments are excluded.</p></div><span class="data-tag">SOURCE: '+esc(row.reference||row.metric||'MEASURED RECORD')+'</span></section>';
  }
  function trafficWeekdayVisual(){
    const rows=categoryRecords('traffic');
    if(!rows.length)return '<section class="card chart-card"><div class="card-head"><div><h2>Traffic by weekday</h2><p>Needs dated traffic records; no hours are inferred.</p></div></div><div class="chart-empty"><strong>No traffic observations</strong><p>Enter dated traffic counts to compare weekdays.</p></div></section>';
    const days=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],groups=days.map((name,i)=>{const values=rows.filter(r=>new Date(r.date+'T12:00:00').getDay()===i&&Number.isFinite(Number(r.value)));return {name,avg:values.length?values.reduce((s,x)=>s+Number(x.value),0)/values.length:null,count:values.length,unit:values[0]?.unit||''};}),vals=groups.filter(x=>x.avg!==null).map(x=>x.avg),min=Math.min(...vals),max=Math.max(...vals),span=max-min||1;
    return '<section class="card chart-card"><div class="card-head"><div><h2>Traffic by weekday</h2><p>Mean of recorded traffic values for each weekday; only dates present in your ledger appear.</p></div><span class="data-tag">DATED INPUTS</span></div><div class="weekday-grid">'+groups.map(x=>'<div class="weekday-cell '+(x.avg===null?'weekday-empty':'')+'" style="--cell-strength:'+(x.avg===null?0.12:0.2+0.72*(x.avg-min)/span)+'"><span>'+x.name+'</span><b>'+(x.avg===null?'—':fmtNumber(x.avg,0))+'</b><small>'+(x.avg===null?'No records':x.count+' readings '+esc(x.unit))+'</small></div>').join('')+'</div><p class="small-note">This is a weekday comparison only. The current history schema does not include hour-by-hour counts.</p></section>';
  }
  function movementBars(){
    const groups=[['equipment_import','equipment_export','Equipment'],['chemical_import','chemical_export','Chemicals']];
    const html=groups.map(([inc,out,label])=>{
      const a=monthlyActual(inc).at(-1),b=monthlyActual(out).at(-1);
      if(!a&&!b)return '<div class="movement-bar-empty"><b>'+label+'</b><small>No dated movement readings</small></div>';
      if(a&&b&&(a.unit||'')!==(b.unit||''))return '<div class="movement-bar-empty"><b>'+label+'</b><small>Units differ; enter compatible units to compare</small></div>';
      const incoming=Number(a?.value||0),outgoing=Number(b?.value||0),total=incoming+outgoing,scale=total?Math.round(incoming/total*100):0;
      return '<div class="movement-bar-row"><div><b>'+label+'</b><small>'+esc(a?.month||b?.month)+' · '+fmtNumber(incoming,1)+' in / '+fmtNumber(outgoing,1)+' out '+esc(a?.unit||b?.unit||'units')+'</small></div><div class="movement-bar"><span style="width:'+scale+'%"></span></div></div>';
    }).join('');
    return '<section class="card chart-card"><div class="card-head"><div><h2>Inventory & lab movement</h2><p>Latest recorded import/export period; values are not merged across units.</p></div><span class="data-tag">MEASURED LEDGER</span></div><div class="movement-bars">'+html+'</div></section>';
  }
  function forecastCards() {
    const metrics=[['electricity','Electricity use'],['water','Water use'],['traffic','Traffic volume']];
    return '<div class=\"forecast-grid\">'+metrics.map(([key,label])=>{
      const f=forecastMonthly(key);
      return '<article class=\"card forecast-card\"><div class=\"eyebrow\">TRANSPARENT BASELINE · NOT A SAFETY PREDICTION</div><h2>'+esc(label)+'</h2>'+(f?'<div class=\"forecast-number\">'+fmtNumber(f.value,1)+' <small>'+esc(f.unit||'units')+'</small></div><p>Next-month trend · range '+fmtNumber(f.low,1)+'–'+fmtNumber(f.high,1)+' '+esc(f.unit||'units')+'</p>'+forecastPlot(f,key==='water'?'#89b4ff':key==='traffic'?'#f2a45f':'#77e7bc')+'<div class=\"small-note\">Actual points and a linear trend baseline from '+f.history.length+' entered monthly averages. The range describes fit residuals, not guaranteed outcomes.</div>': '<div class=\"chart-empty\">Add numeric readings in at least three distinct months for this metric. A complete six-month, 11-category history is not required for this individual trend.</div>')+'</article>';
    }).join('')+'</div>';
  }
  function healthIndex() {
    const checks=[],coverage=historyReadiness();
    checks.push({key:'Data completeness',score:Math.round(coverage.ratio*100),weight:25,note:coverage.records+' history rows · '+Math.round(coverage.ratio*100)+'% of required month/category coverage'});
    const unresolved=openIncidents(),urgent=unresolved.filter(x=>x.severity==='Urgent').length,high=unresolved.filter(x=>x.severity==='High').length;
    checks.push({key:'Safety reports',score:Math.max(0,100-urgent*35-high*15),weight:20,note:urgent+' urgent and '+high+' high-priority open reports; no reports do not prove absence of risk'});
    for(const [key,label,weight] of [['electricity','Energy',15],['water','Water',15]]) {
      const months=monthlyActual(key).slice(-7);
      if(months.length>=4&&!months.slice(-4).some(x=>x.mixedUnits)) {
        const recent=months.at(-1).value,prior=months.slice(-4,-1).map(x=>x.value).sort((a,b)=>a-b),median=prior[Math.floor(prior.length/2)];
        const change=median===0?(recent===0?0:100):(recent-median)/Math.abs(median)*100;
        const score=Math.max(0,Math.min(100,100-Math.max(0,change)*1.5));
        checks.push({key:label,score:Math.round(score),weight,note:'Latest '+fmtNumber(recent,1)+' '+(months.at(-1).unit||'units')+' vs preceding 3-month median '+fmtNumber(median,1)+'; not normalized for occupancy or weather'});
      }
    }
    const envRows=data.history.filter(x=>['lab_condition','chemical_import','chemical_export'].includes(x.category));
    if(envRows.length)checks.push({key:'Environment & lab records',score:Math.min(100,Math.round(envRows.length/6*100)),weight:10,note:envRows.length+' dated lab / chemical records are available; a record count does not establish regulatory compliance'});
    const knownAssets=data.equipment.filter(x=>String(x.condition||'').trim()&& !/unknown|not entered/i.test(x.condition));
    if(knownAssets.length) {
      const troubled=knownAssets.filter(x=>/repair|service|fault|poor|replace|inspection|offline/i.test(x.condition)).length;
      checks.push({key:'Equipment',score:Math.round((knownAssets.length-troubled)/knownAssets.length*100),weight:10,note:troubled+' of '+knownAssets.length+' assets have a condition marked for review'});
    }
    const kitchen=data.kitchen.slice(-30),prepared=kitchen.reduce((s,x)=>s+Number(x.preparedKg||0),0),waste=kitchen.reduce((s,x)=>s+Number(x.wasteKg||0),0);
    if(kitchen.length&&prepared>0)checks.push({key:'Food waste',score:Math.round(Math.max(0,100-waste/prepared*100)),weight:5,note:fmtNumber(waste,1)+' kg measured waste from '+fmtNumber(prepared,1)+' kg prepared across '+kitchen.length+' entries'});
    const totalWeight=checks.reduce((s,x)=>s+x.weight,0),score=Math.round(checks.reduce((s,x)=>s+x.score*x.weight,0)/totalWeight);
    return {score,checks,coverage,totalWeight};
  }
  function healthCard() {
    const result=healthIndex();
    return '<section class="card health-card"><div class="health-orbit" aria-hidden="true"><div><strong>'+result.score+'</strong><small>/ 100</small></div></div><div class="health-copy"><div class="eyebrow">REPORTED OPERATIONS INDEX · INPUT DATA ONLY</div><h2>Campus readiness snapshot</h2><p>Weighted summary of data coverage, open safety reports, and entered resource/asset records. Open each factor to see its source and limits. This is a triage aid, not a safety certification or audit.</p><div class="health-components">'+result.checks.map(x=>'<details class="health-component"><summary><span>'+esc(x.key)+'</span><b>'+x.score+'%</b></summary><p>'+esc(x.note)+'</p></details>').join('')+'</div><small class="health-footnote">Weights are renormalized when a measurement category is unavailable. Current evidence: '+result.checks.length+' available indicators · data coverage '+Math.round(result.coverage.ratio*100)+'%.</small></div></section>';
  }
  function trendAlert(category,label) {
    const rows=monthlyActual(category).slice(-7),threshold=Math.max(5,Math.min(200,Number(profile.alertThresholdPct)||25));
    if(rows.length<4||rows.slice(-4).some(x=>x.mixedUnits))return '';
    const vals=rows.slice(-4,-1).map(x=>x.value).sort((a,b)=>a-b),median=vals[1],recent=rows.at(-1);
    if(median<=0||recent.value<=median*(1+threshold/100))return '';
    const pct=Math.round((recent.value/median-1)*100);
    return '<div class="usage-alert"><span>↗</span><div><b>'+esc(label)+' is '+pct+'% above its previous 3-month median</b><p>Latest entered period: '+esc(recent.month)+' · '+fmtNumber(recent.value,1)+' '+esc(recent.unit||'units')+'. Alert threshold: '+threshold+'%. Review the meter source and campus context before acting.</p></div></div>';
  }
  function campusSchematic() {
    const blocks=data.blocks;
    if(blocks.length&&!blocks.some(x=>x.id===ui.selectedBlock))ui.selectedBlock=blocks[0].id;
    if(!blocks.length)return '<section class="card campus-console"><div class="card-head"><div><div class="eyebrow">LIVE CAMPUS VIEW · SCHEMATIC</div><h2>Campus operations map</h2><p>Enter real block profiles to populate the schematic. It will not invent buildings or distances.</p></div><button class="button small" data-action="go" data-page="campus">Add blocks ↗</button></div><div class="empty-state"><strong>No block records to display</strong><p>The schematic uses entered campus blocks and is not a geographic map.</p></div></section>';
    const nodes=blocks.map((block,index)=>{
      const open=data.incidents.filter(x=>x.block===block.name&&!['Resolved','Closed'].includes(x.status));
      const urgent=open.some(x=>x.severity==='Urgent'),staff=data.activeShifts.filter(x=>x.block===block.name).length;
      const energy=categoryRecords('electricity').filter(x=>x.block===block.name).at(-1),water=categoryRecords('water').filter(x=>x.block===block.name).at(-1);
      const state=urgent?'critical':open.length?'watch':'clear';
      return '<button class="campus-node '+state+(ui.selectedBlock===block.id?' selected':'')+'" data-action="select-block" data-id="'+esc(block.id)+'"><span class="node-index">'+String(index+1).padStart(2,'0')+'</span><span class="node-name">'+esc(block.name)+'</span><span class="node-status"><i></i>'+ (urgent?'Urgent report':open.length?open.length+' open report'+(open.length>1?'s':''):'No open reports')+'</span><span class="node-meta">'+staff+' active shift'+(staff===1?'':'s')+' · '+esc(energy?fmtNumber(energy.value,0)+' '+(energy.unit||'kWh'):'no energy reading')+'</span><span class="node-meta">'+esc(water?fmtNumber(water.value,0)+' '+(water.unit||'kL'):'no water reading')+'</span></button>';
    }).join('');
    const selected=blocks.find(x=>x.id===ui.selectedBlock)||blocks[0],issues=data.incidents.filter(x=>x.block===selected.name&&!['Resolved','Closed'].includes(x.status)),assets=data.equipment.filter(x=>x.block===selected.name),crew=data.activeShifts.filter(x=>x.block===selected.name);
    const detail='<aside class="campus-inspector"><div class="eyebrow">SELECTED BUILDING</div><h3>'+esc(selected.name)+'</h3><div class="inspector-metrics"><span>'+esc(selected.students||'—')+'<small>students</small></span><span>'+esc(selected.faculty||'—')+'<small>faculty</small></span><span>'+esc(selected.workers||'—')+'<small>workers</small></span></div><p>'+esc(selected.labs||'—')+' labs · '+esc(selected.instruments||'—')+' instruments · '+esc(selected.opening||'—')+'–'+esc(selected.closing||'—')+'</p><div class="metric-line"><span>Open reports</span><b>'+issues.length+'</b></div><div class="metric-line"><span>Registered assets</span><b>'+assets.length+'</b></div><div class="metric-line"><span>Active shift records</span><b>'+crew.length+'</b></div><button class="button small primary" data-action="report-from-block" data-block="'+esc(selected.name)+'">Report from this block ↗</button><button class="button small ghost" data-action="copy-block-link" data-block="'+esc(selected.name)+'">Copy location report link</button></aside>';
    return '<section class="card campus-console"><div class="card-head"><div><div class="eyebrow">LIVE CAMPUS VIEW · SCHEMATIC</div><h2>Campus operations map</h2><p>Signals reflect saved campus records. Building positions are illustrative; this is not a measured site plan.</p></div><span class="data-tag">'+blocks.length+' ENTERED BLOCKS</span></div><div class="campus-console-layout"><div class="campus-schematic"><div class="flow-lines" aria-hidden="true"><span></span><span></span><span></span></div><div class="campus-nodes">'+nodes+'</div><div class="map-legend"><span><i class="legend-clear"></i>No open report</span><span><i class="legend-watch"></i>Open issue</span><span><i class="legend-critical"></i>Urgent issue</span></div></div>'+detail+'</div></section>';
  }
  function escalationTimeline(item) {
    const created=new Date(item.createdAt||Date.now()),elapsed=Math.max(0,Math.floor((Date.now()-created.getTime())/60000)),target=Number(item.expectedMinutes)||0;
    const overdue=target>0&&elapsed>target&&!['Resolved','Closed'].includes(item.status),remaining=target?Math.max(0,target-elapsed):null;
    const chain=item.category==='electrical'||item.category==='equipment'?'Field staff → Environmental / facilities engineer → Administrator':item.category==='security'||item.category==='fire'?'Field staff → Security / warden → Administrator':item.category==='lab'?'Field staff → Lab / environmental lead → Administrator':'Field staff → Assigned responder → Administrator';
    return '<div class="escalation-strip '+(overdue?'overdue':'')+'"><div><span class="eyebrow">RESPONSE WORKFLOW</span><b>'+esc(chain)+'</b></div><div><span class="eyebrow">REPORTED</span><b data-reported-at="'+created.getTime()+'">'+elapsed+' min ago</b></div><div><span class="eyebrow">TARGET</span><b data-response-deadline="'+(target?created.getTime()+target*60000:'')+'" data-response-done=\"'+(['Resolved','Closed'].includes(item.status)?'true':'false')+'\">'+(target?(overdue?'OVERDUE · ':remaining+' min remaining · ')+fmtDate(new Date(created.getTime()+target*60000),true):'No target entered')+'</b></div><div><span class="eyebrow">ACKNOWLEDGED</span><b>'+esc(item.acknowledgedAt?fmtDate(item.acknowledgedAt,true):'Awaiting acknowledgement')+'</b></div><div><span class="eyebrow">ASSIGNED RESPONDER</span><b>'+esc(item.assignedTo?reporterName(item.assignedTo):'Not assigned')+'</b></div></div>';
  }
  function equipmentMaintenanceSummary() {
    const today=dateInput(),limit=dateInput(new Date(Date.now()+30*86400000));
    const dated=data.equipment.filter(x=>validDateOnly(x.maintenanceDue)).sort((a,b)=>a.maintenanceDue.localeCompare(b.maintenanceDue));
    const due=dated.filter(x=>x.maintenanceDue<=today);
    const near=dated.filter(x=>x.maintenanceDue>today&&x.maintenanceDue<=limit);
    const later=dated.filter(x=>x.maintenanceDue>limit);
    return {due,near,later,dated};
  }
  function maintenanceScheduleRows(items) {
    const today=dateInput();
    return items.map(x=>{
      const overdue=x.maintenanceDue<today,state=overdue?'Overdue':x.maintenanceDue===today?'Due today':x.maintenanceDue<=dateInput(new Date(Date.now()+30*86400000))?'Due within 30 days':'Scheduled later';
      return '<div class="schedule-row '+(overdue?'overdue':'')+'"><span class="schedule-mark">'+(overdue?'!':x.maintenanceDue===today?'◷':'·')+'</span><div><b>'+esc(x.name)+'</b><small>'+esc(x.block||'Campus')+' · '+esc(fmtDate(x.maintenanceDue))+' · '+state+'</small></div>'+(canManage()?'<button class="button tiny ghost" type="button" data-action="open-scheduled-asset" data-id="'+esc(x.id)+'">Open asset ↗</button>':'')+'<button class="button tiny" type="button" data-action="draft-asset-work-order" data-id="'+esc(x.id)+'">Draft work order</button></div>';
    }).join('');
  }
  function preventiveSchedule(summary) {
    if(!summary.dated.length)return '<div class="empty-state"><strong>No preventive dates entered yet</strong><p>Add or update a real next-service date in the equipment register. Blank schedules are not estimated.</p>'+(canManage()?'<button class="button small" data-action="go" data-page="equipment">Open asset register ↗</button>':'<small>Asset schedule editing is available to administrators, deans, wardens, and environmental engineers.</small>')+'</div>';
    return (summary.due.length?'<div class="schedule-group"><div class="eyebrow">DUE NOW · '+summary.due.length+'</div><div class="maintenance-schedule">'+maintenanceScheduleRows(summary.due)+'</div></div>':'')
      +(summary.near.length?'<div class="schedule-group"><div class="eyebrow">NEXT 30 DAYS · '+summary.near.length+'</div><div class="maintenance-schedule">'+maintenanceScheduleRows(summary.near)+'</div></div>':'')
      +(summary.later.length?'<details class="schedule-later"><summary>Later dates · '+summary.later.length+' assets</summary><div class="maintenance-schedule">'+maintenanceScheduleRows(summary.later)+'</div></details>':'');
  }
  function renderOverview() {
    const urgent=openIncidents().filter(x=>['Urgent','High'].includes(x.severity)).length;
    const energy=actualLatest('electricity'),water=actualLatest('water'),traffic=actualLatest('traffic');
    const own=data.incidents.filter(x=>x.reporterEmail===personKey()).length;
    const isStaff=['worker','security','warden','kitchen'].includes(profile.role);
    const top=isStaff
      ? 'Your shift desk brings the report button, shift timer and assigned campus updates together.'
      : 'Facility activity, staff reports, and records entered by your campus team.';
    const incidentRows=openIncidents().slice(0,4).map(x=>'<article class=\"incident-row\"><span class=\"severity-dot '+esc(x.severity.toLowerCase())+'\"></span><div><strong>'+esc(x.title)+'</strong><p>'+esc(x.block||'Campus')+' · '+esc(x.severity)+' · '+esc(reporterName(x.reporterEmail))+'</p></div><button class=\"button small ghost\" data-action=\"go\" data-page=\"incidents\">Review</button></article>').join('');
    const kitchens=data.kitchen.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,7);
    const prepared=kitchens.reduce((s,x)=>s+Number(x.preparedKg||0),0),wasted=kitchens.reduce((s,x)=>s+Number(x.wasteKg||0),0);
    return head('CAMPUS OPERATIONS · '+currentRole().group, profile.collegeName || 'Institution workspace', top,
      button('Report an issue now','go','primary','data-page=\"incidents\"') + (isStaff?button('Open my shift','go','ghost','data-page=\"staff\"'):''))
      + '<section class=\"welcome-strip\"><div><div class=\"eyebrow\">SIGNED IN AS · '+esc(currentRole().label.toUpperCase())+'</div><h2>'+esc(profile.personName||'Campus team member')+'</h2><p>'+esc([profile.city,profile.region].filter(Boolean).join(' · ')||'Add a campus location in Campus Profile')+' · '+esc(profile.opening||'—')+'–'+esc(profile.closing||'—')+'</p></div><div class=\"welcome-actions\"><span class=\"live-pill\">'+urgent+' urgent / high open</span><span class=\"shift-status\">'+esc(shiftTimeLabel())+'</span></div></section>'
      + '<div class=\"stats-grid\">'+statCard('Latest electricity',metricLabel(energy),energy?'Record dated '+fmtDate(energy.date):'No reading entered','ϟ')+statCard('Latest water',metricLabel(water),water?'Record dated '+fmtDate(water.date):'No reading entered','⌁')+statCard('Latest traffic',metricLabel(traffic),traffic?'Record dated '+fmtDate(traffic.date):'No reading entered','⇄')+statCard('Reports you sent',String(own),'Counted from your submitted incidents','⚑')+'</div>'
      + '<section class="stewardship-moment"><span>THE INFRAIQ STEWARDSHIP NOTE</span><p>“'+esc(stewardshipQuote())+'”</p></section>'
      + dataProfileCard()
      + electricityCostCard()
      + (SHOWCASE_MODE?'<section class="showcase-banner"><span class="showcase-stamp">FICTIONAL DATA</span><div><b>Competition showcase · separate demo workspace</b><p>Every block, incident, staff record, and measurement here is fictional. It is stored separately and never mixes with campus records.</p></div><button class="button small" data-action="exit-showcase">Return to real workspace</button></section>':'')
      + healthCard()
      + campusSchematic()
      + '<div class="alert-stack">'+trendAlert('electricity','Electricity use')+trendAlert('water','Water use')+'</div>'
      + '<div class="period-comparisons">'+periodComparison('electricity','Electricity')+periodComparison('water','Water')+'</div>'
      + '<section class="card section-space"><div class="card-head"><div><h2>Maintenance readiness</h2><p>Scheduled work and due dates entered by your campus team.</p></div><button class="button small" data-action="go" data-page="maintenance">Open maintenance desk ↗</button></div><div class="maintenance-glance">'+(equipmentMaintenanceSummary().due.length?'<div class="maintenance-due"><b>'+equipmentMaintenanceSummary().due.length+' maintenance item(s) due today or overdue</b><span>Review the assigned technician and update the ticket status.</span></div>':'<div class="maintenance-ok"><b>No overdue maintenance dates are recorded</b><span>This reflects only assets with a due date entered.</span></div>')+'<span>'+data.maintenance.filter(x=>!['Resolved','Closed'].includes(x.status)).length+' open maintenance ticket(s)</span></div></section>'
      + '<div class=\"content-grid overview-grid\"><section class=\"card\"><div class=\"card-head\"><div><h2>Incident response queue</h2><p>Submitted by campus crew · sorted newest first</p></div><button class=\"button small\" data-action=\"go\" data-page=\"incidents\">Open incident desk ↗</button></div><div class=\"incident-list\">'+(incidentRows||'<div class=\"empty-state\"><strong>No incident reports yet</strong><p>When staff report an issue, it will appear here with an evidence-labeled response workflow.</p></div>')+'</div></section><section class=\"card\"><div class=\"card-head\"><div><h2>Kitchen pulse · recent entries</h2><p>Measured preparation and waste totals</p></div><button class=\"button small ghost\" data-action=\"go\" data-page=\"kitchen\">Kitchen log ↗</button></div>'+(kitchens.length?donut([{label:'Food used',value:Math.max(0,prepared-wasted)},{label:'Food wasted',value:wasted}],'Measured food use and waste'):'<div class=\"chart-empty\"><strong>No kitchen records</strong><p>Menu and food-use charts will appear after kitchen staff log actual amounts.</p></div>')+'</section></div>'
      + '<div class=\"content-grid\">'+actualChartCard('Electricity history','electricity','Monthly average from dated institution records.','#77e7bc')+actualChartCard('Traffic history','traffic','Monthly average from dated institution records.','#89b4ff')+'</div>'
      + '<div class=\"content-grid\">'+trafficWeekdayVisual()+movementBars()+'</div>'
      + forecastCards();
  }
  function maintenanceStatusRows() {
    return data.maintenance.slice().sort((a,b)=>String(a.dueDate||'9999').localeCompare(String(b.dueDate||'9999'))).map(ticket=>{
      const editable=canManage()||ticket.assignedTo===personKey(),due=ticket.dueDate&&ticket.dueDate<dateInput()&&!['Resolved','Closed'].includes(ticket.status);
      const status=editable?selectField('Status','ticket_status_'+ticket.id,[['Open','Open'],['Scheduled','Scheduled'],['In progress','In progress'],['Blocked','Blocked'],['Resolved','Resolved'],['Closed','Closed']],ticket.status||'Open').replace('<select name="ticket_status_'+ticket.id+'"','<select data-ticket-status-id="'+esc(ticket.id)+'"'): '<span class="status-tag">'+esc(ticket.status||'Open')+'</span>';
      const assignee=canManage()?selectField('Technician','ticket_assignee_'+ticket.id,[['','Unassigned'],...data.crew.map(m=>[m.email,m.name+' · '+(roles[m.role]?.label||m.role)])],ticket.assignedTo||'').replace('<select name="ticket_assignee_'+ticket.id+'"','<select data-ticket-assignee-id="'+esc(ticket.id)+'"'):'';
      return '<article class="maintenance-ticket '+(due?'ticket-overdue':'')+'"><div class="ticket-top"><div><span class="eyebrow">'+(due?'OVERDUE · ':'')+esc(ticket.priority||'Normal')+' PRIORITY</span><h3>'+esc(ticket.title)+'</h3></div><span class="data-tag">'+esc(ticket.status||'Open')+'</span></div><div class="ticket-meta"><span>'+esc(ticket.assetName||ticket.assetId||'General campus work')+'</span><span>'+esc(ticket.block||'Campus wide')+'</span><span>Due '+esc(ticket.dueDate?fmtDate(ticket.dueDate):'not scheduled')+'</span><span>Assigned '+esc(ticket.assignedTo?reporterName(ticket.assignedTo):'unassigned')+'</span></div><p>'+esc(ticket.description||'No work details entered.')+'</p>'+(ticket.resolutionEvidence?'<div class="resolution-evidence"><b>Resolution / inspection evidence</b><p>'+esc(ticket.resolutionEvidence)+'</p></div>':'')+(ticket.showcaseFictional?'<span class="fictional-tag">FICTIONAL SHOWCASE</span>':'')+(editable&&!['Resolved','Closed'].includes(ticket.status)?'<label class="field resolution-input">Completion evidence<textarea data-ticket-evidence-id="'+esc(ticket.id)+'" rows="2" placeholder="Required before closing · inspection result, action, and technician"></textarea></label>':'')+(editable?'<div class="ticket-controls">'+status+assignee+'</div>':'')+'</article>';
    }).join('');
  }
  function renderMaintenance() {
    const summary=equipmentMaintenanceSummary(),open=data.maintenance.filter(x=>!['Resolved','Closed'].includes(x.status)),urgent=open.filter(x=>x.priority==='Urgent').length;
    const assets=[['','General / infrastructure'],...data.equipment.map(x=>[x.id,x.name+' · '+(x.block||'Campus')])];
    const draft=ui.maintenanceDraft||{};
    return head('ASSET CARE · WORK ORDERS','Maintenance desk','Create a traceable work order, assign a technician, set a due date, update status, and record inspection or completion evidence.',button('Export work orders','maintenance-export','ghost')+button('Print maintenance report','print-report','ghost'))
      +'<div class="stats-grid">'+statCard('Open tickets',String(open.length),'Work orders requiring an update','⚙')+statCard('Urgent tickets',String(urgent),'Priority entered by the reporting team','!')+statCard('Due now / overdue',String(summary.due.length),'Asset schedule dates entered by staff','◷')+statCard('Next 30 days',String(summary.near.length),'Upcoming equipment schedule dates','⌁')+statCard('Scheduled assets',String(summary.dated.length),'Every equipment item with a due date','▦')+'</div>'
      +'<div class="content-grid"><section class="card"><div class="card-head"><div><h2>'+(draft.type==='maintenance_ticket'?'Review AI work order draft':'Create a work order')+'</h2><p>AI can prepare a draft; a campus person reviews and submits it. For immediate hazards, also submit an incident.</p></div></div><form class="form-grid" data-form="maintenance">'+field('Work order title','title','text',draft.title||'','e.g. Inspect pump vibration',true)+selectField('Linked asset','assetId',assets,draft.assetId||'')+selectField('Campus block','block',blockOptions(true),draft.block||'')+selectField('Priority','priority',[['Normal','Normal'],['High','High'],['Urgent','Urgent']],draft.priority||'Normal')+field('Due date','dueDate','date',draft.type==='maintenance_ticket'?(draft.dueDate||''):dateInput(),'',false)+selectField('Assign technician','assignedTo',[['','Unassigned'],...data.crew.map(m=>[m.email,m.name+' · '+(roles[m.role]?.label||m.role)])],'')+'<label class="field full-field">Work details<textarea name="description" rows="3" required placeholder="Observed condition, safe isolation needed, requested inspection or corrective work">'+esc(draft.description||'')+'</textarea></label><div class="form-actions full-field"><button class="button primary" type="submit">Create work order</button><button class="button ghost" type="button" data-action="clear-maintenance-draft">Clear draft</button></div></form></section><section class="card"><div class="card-head"><div><h2>Preventive schedule</h2><p>Every dated asset appears here, including schedules beyond the next 30 days.</p></div>'+(canManage()?'<button class="button small ghost" data-action="go" data-page="equipment">Open asset register ↗</button>':'')+'</div>'+preventiveSchedule(summary)+'<div class="trust-note">Schedule dates are reminders, not sensor readings or proof that work was performed.</div></section></div>'
      +'<section class="card section-space"><div class="card-head"><div><h2>Campus work orders</h2><p>Assigned responder, deadline, status, and resolution evidence.</p></div><span class="data-tag">'+data.maintenance.length+' TOTAL</span></div>'+(data.maintenance.length?'<div class="maintenance-list">'+maintenanceStatusRows()+'</div>':'<div class="empty-state"><strong>No maintenance tickets yet</strong><p>Create one from an observed concern or scheduled inspection.</p></div>')+'</section>';
  }
  function renderHealth() {
    const coverage=historyReadiness(),index=healthIndex(),schedule=equipmentMaintenanceSummary();
    const open=data.maintenance.filter(x=>!['Resolved','Closed'].includes(x.status));
    const reportTickets=data.maintenance.length?'<div class="table-wrap"><table class="data-table"><thead><tr><th>Work order</th><th>Asset / block</th><th>Status</th><th>Due</th><th>Assigned</th><th>Evidence</th></tr></thead><tbody>'+data.maintenance.map(x=>'<tr><td>'+esc(x.title)+'</td><td>'+esc((x.assetName||'General')+' · '+(x.block||'Campus'))+'</td><td>'+esc(x.status||'Open')+'</td><td>'+esc(x.dueDate?fmtDate(x.dueDate):'—')+'</td><td>'+esc(x.assignedTo?reporterName(x.assignedTo):'Unassigned')+'</td><td>'+esc(x.resolutionEvidence||'Not recorded')+'</td></tr>').join('')+'</tbody></table></div>':'<p class="small-note">No maintenance work orders recorded.</p>';
    const cues=index.checks.length?index.checks.map(x=>'<article class="health-cue"><div><b>'+esc(x.key)+'</b><span class="data-tag">'+x.score+'% RECORDED SIGNAL</span></div><p>'+esc(x.note)+'</p><small>Rule-based signal from entered data · does not certify safety or compliance.</small></article>').join(''):'<div class="empty-state"><strong>No health cues can be calculated yet</strong><p>Add dated, measured campus data and asset conditions. Missing values are not filled with assumptions.</p></div>';
    const report=ui.healthReport;
    const aiContent=ui.healthReportLoading?'<div class="ai-report-text" id="campus-ai-report-stream">'+esc(ui.healthReportDraft||'')+'</div>':report?'<div class="ai-report-text" id="campus-ai-report">'+esc(report.text)+'</div>'+(report.sources?.length?'<small class="report-sources">Evidence: '+esc(report.sources.join(' · '))+'</small>':''):'<div class="empty-state"><strong>AI campus analysis is ready when securely connected</strong><p>It reviews only records your signed-in role may access, labels estimates, highlights favorable recorded cues and data gaps, and never certifies that a campus is safe.</p></div>';
    return head('CAMPUS OPERATIONS · EVIDENCE SUMMARY','Campus health reports','A campus-wide view of actual records, operational cues, data gaps, and cautious AI analysis. Estimates are labeled and never substituted for missing measurements.',button(ui.healthReportLoading?'Analyzing campus records…':'Generate AI report','generate-health-report','primary',cloudSession?'':'disabled')+button('Print campus report','print-report','ghost')+button('Export incident evidence CSV','evidence-export','ghost')+button('Export history CSV','history-export','ghost')+button('Export crew CSV','crew-export','ghost'))
      +healthCard()
      +'<div class="stats-grid">'+statCard('History coverage',Math.round(coverage.ratio*100)+'%',coverage.records+' entered rows · '+(coverage.complete?'six-month gate complete':'some periods/categories missing'),'▤')+statCard('Equipment records',fmtNumber(data.equipment.length,0),'Assets visible to this account','▦')+statCard('Scheduled maintenance',fmtNumber(schedule.due.length+schedule.near.length+schedule.later.length,0),'Due today, soon, or later','⚙')+statCard('Open incidents',fmtNumber(openIncidents().length,0),'Visible records · '+openIncidents().filter(x=>['Urgent','High'].includes(x.severity)).length+' urgent / high','⚑')+'</div>'
      +'<section class="card section-space"><div class="card-head"><div><h2>Recorded campus cues</h2><p>Transparent calculations based on records available to this account.</p></div><span class="data-tag">'+index.checks.length+' SIGNALS</span></div><div class="health-cue-grid">'+cues+'</div><div class="trust-note">The readiness score is a triage aid. No reports, readings, or alerts do not prove an absence of risk. AI and rule-based cues require review by qualified campus staff.</div></section>'
      +'<div class="content-grid section-space">'+actualChartCard('Electricity use','electricity','Entered, dated institution readings only.','#77e7bc')+actualChartCard('Water use','water','Entered, dated institution readings only.','#89b4ff')+'</div>'
      +'<section class="card section-space ai-report-card"><div class="card-head"><div><div class="eyebrow">AI-ASSISTED · SOURCE-GROUNDED</div><h2>Whole-campus analysis</h2><p>Positive cues, issues to review, missing evidence, cautious outlook, and prioritized recommendations.</p></div><span class="data-tag">'+(cloudSession?'AUTHENTICATED':'SECURE SIGN-IN REQUIRED')+'</span></div><div class="ai-report-body">'+(ui.healthReportLoading?'<div class="loading-cue"><span class="live-dot"></span><p>Reviewing role-permitted campus records…</p></div>':'')+aiContent+'</div><div class="trust-note">Any projected value is an estimate derived from dated records and will be identified as such. The AI does not collect sensors, verify inspections, or make compliance determinations.</div></section>'
      +'<section class="print-report card" id="campus-report"><div class="print-report-head"><div class="eyebrow">INFRAIQ · CAMPUS HEALTH & OPERATIONS REPORT</div><h2>'+esc(profile.collegeName||'Institution workspace')+'</h2><p>Generated '+esc(fmtDate(new Date(),true))+' · '+esc([profile.city,profile.region].filter(Boolean).join(', '))+'</p></div><div class="print-report-grid"><div><b>Readiness index</b><strong>'+index.score+' / 100</strong><small>Reported-operations triage aid · not a certification</small></div><div><b>Six-month coverage</b><strong>'+Math.round(coverage.ratio*100)+'%</strong><small>'+coverage.records+' entered history rows</small></div><div><b>Open incidents</b><strong>'+openIncidents().length+'</strong><small>'+openIncidents().filter(x=>['Urgent','High'].includes(x.severity)).length+' urgent / high</small></div><div><b>Open maintenance</b><strong>'+open.length+'</strong><small>'+summaryMaintenancePhrase()+'</small></div></div><h3>AI campus analysis</h3>'+(report?'<div class="ai-report-text">'+esc(report.text)+'</div>':'<p class="small-note">No AI report has been generated. Use Generate AI report while signed into the secured deployment.</p>')+'<h3>Entered resource records</h3><div class="print-report-charts">'+actualChartCard('Electricity use','electricity','Dated institution records','#77e7bc')+actualChartCard('Water use','water','Dated institution records','#89b4ff')+'</div><h3>Open incident register</h3>'+incidentTable(openIncidents(),false)+'<h3>Maintenance work orders</h3>'+reportTickets+'<p class="small-note">This document summarizes records visible to the signed-in role. It does not certify safety, compliance, or forecast accuracy.</p></section>';
  }
  function summaryMaintenancePhrase(){const due=equipmentMaintenanceSummary();return due.due.length+' due today or overdue · '+due.near.length+' in 30 days · '+due.later.length+' scheduled later';}
  function renderStaff() {
    const member=currentMember(), mine=data.incidents.filter(x=>x.reporterEmail===personKey()).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
    const assigned=data.incidents.filter(x=>x.assignedTo===personKey()&&!['Resolved','Closed'].includes(x.status)).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
    const start= !!activeShiftFor();
    const shiftButton=start?button('End shift','clock-out','danger'):button('Start shift','clock-in','primary');
    return head('STAFF DESK · '+currentRole().group,'My shift & reports','Start or end your on-site session and send a report directly into the campus incident queue.',shiftButton)
      +'<div class=\"content-grid staff-grid\"><section class=\"card shift-card\"><div class=\"eyebrow\">TIME ON THIS WORKSPACE</div><div class=\"shift-clock\" id=\"shift-clock\">'+esc(shiftTimeLabel())+'</div><p>Clock in when your shift begins and clock out when it ends. Time is recorded in this browser workspace.</p><div class=\"metric-line\"><span>Role</span><b>'+esc(currentRole().label)+'</b></div><div class=\"metric-line\"><span>Assigned block</span><b>'+esc(member?.block||'Not assigned')+'</b></div><div class=\"metric-line\"><span>Your report count</span><b>'+mine.length+' total</b></div>'+shiftButton+'</section><section class=\"card\"><div class=\"card-head\"><div><h2>Send an incident report</h2><p>Urgent reports are added immediately to the administrator’s open queue in this workspace.</p></div><span class=\"urgent-chip\">SAFETY FIRST</span></div>'+incidentForm()+'</section></div>'
      +'<section class=\"card section-space\"><div class=\"card-head\"><div><h2>My submitted reports</h2><p>Only verified information earns recognition points.</p></div><span class=\"data-tag\">'+mine.length+' REPORTS</span></div>'+incidentTable(mine,false)+'</section>'      +'<section class=\"card section-space\"><div class=\"card-head\"><div><h2>Assigned to me</h2><p>Acknowledge or update the status of work assigned to your account.</p></div><span class=\"data-tag\">'+assigned.length+' OPEN</span></div>'+incidentTable(assigned,true)+'</section>'
      +'<div class=\"trust-note\">The current website stores data in this browser. Separate-device delivery, identity verification, and off-screen push alerts require a hosted shared backend.</div>';
  }
  function incidentForm() {
    const cats=[['electrical','Electrical / transformer'],['water','Water / plumbing'],['lab','Laboratory / chemical'],['equipment','Equipment / asset'],['security','Security / access'],['fire','Fire / smoke'],['other','Other campus issue']];
    return '<form class=\"form-grid incident-form\" data-form=\"incident\">'+field('Short title','title','text','','e.g. Transformer making a sharp buzzing sound',true)
      + selectField('Issue type','category',[['','Choose an issue type'],...cats],'').replace('<select name="category"','<select name="category" required')
      + selectField('Campus block / location','block',blockOptions(true),ui.reportBlock||'')
      + selectField('Urgency','severity',[['','Choose urgency'],['Urgent','Urgent · immediate danger / essential service'],['High','High · prompt response needed'],['Normal','Normal · track and assign']], '').replace('<select name="severity"','<select name="severity" required')
      + field('First noticed at','observedAt','datetime-local',localDateTimeInput(),'',true)
      + field('Known onset, if known','startedAt','datetime-local','','optional')
      + field('Response target · minutes','expectedMinutes','number','','Optional target set by campus policy',false,'min="1" step="1" max="10080"')
      + '<label class=\"field full-field\">What you observed<textarea name=\"description\" rows=\"3\" required placeholder=\"Describe visible signs, sounds, smell, affected area, equipment label, or meter reading. Do not guess at a cause.\"></textarea></label>'
      + '<label class=\"field full-field\">Immediate action already taken<textarea name=\"actionTaken\" rows=\"2\" placeholder=\"People moved away, supervisor called, or no action yet\"></textarea></label>'
      + '<label class=\"field full-field\">Optional photo / PDF evidence<input type=\"file\" name=\"incidentEvidence\" accept=\"image/*,application/pdf\" '+(cloudSession?'':'disabled')+'><small>'+(cloudSession?'Private campus storage · images or PDFs up to 8 MB.':'Secure upload activates after Supabase storage is configured; do not put files into this local demo.')+'</small></label>'
      + '<label class=\"consent-line full-field\"><input type=\"checkbox\" name=\"confirmObserved\" required><span>I am reporting what I observed. Cause and duration may be unknown.</span></label>'
      + '<div class=\"form-actions full-field\"><button class=\"button primary\" type=\"submit\">Send report to incident desk ↗</button><span class=\"small-note\">For immediate danger follow campus emergency procedures and contact local emergency services.</span></div></form>';
  }
  function incidentTable(rows, manage) {
    if (!rows.length) return '<div class=\"empty-state\"><strong>No reports recorded</strong><p>Submitted reports will be listed here.</p></div>';
    return '<div class=\"incident-stack\">'+rows.map(x=>{
      const triage=x.triage||incidentTriage(x);
      const canUpdate=manage && (canManage() || x.assignedTo===personKey()),canAssign=manage && canManage();
      const assignment=canAssign?selectField('Assign to','assignee_'+x.id,[['','Unassigned'],...data.crew.map(m=>[m.email,m.name+' · '+(roles[m.role]?.label||m.role)])],x.assignedTo||'').replace('<select name=\"assignee_'+x.id+'\"','<select data-assignee-id=\"'+esc(x.id)+'\"'):'';
      const reward=assignment+(x.verified ? '<span class=\"verified-tag\">VERIFIED · +10 XP</span>' : (isLeader() ? button('Verify report · +10 XP','verify','small','data-id=\"'+esc(x.id)+'\"') : '<span class=\"unverified-tag\">AWAITING REVIEW</span>'));
      const sensitive=['electrical','lab','fire','security'].includes(x.category);
      const caution=sensitive?'<div class=\"incident-banner safety-caution\"><span>!</span><div><b>Human inspection required</b><p>INFRAIQ cannot confirm an electrical, chemical/lab, fire, or security cause remotely. Follow the campus emergency procedure; contact emergency services when needed.</p></div></div>':'';
      const resolution=x.resolutionEvidence?'<div class=\"resolution-evidence\"><b>Resolution / inspection evidence</b><p>'+esc(x.resolutionEvidence)+'</p><small>'+(x.resolvedBy?'Recorded by '+esc(reporterName(x.resolvedBy))+' · ':'')+esc(x.resolvedAt?fmtDate(x.resolvedAt,true):'')+'</small></div>':'';
      const attached=x.evidencePath?'<button class=\"button small ghost\" data-action=\"open-evidence\" data-path=\"'+esc(x.evidencePath)+'\">Open private evidence · '+esc(x.evidenceName||'file')+' ↗</button>':'';
      const resolutionInput=canUpdate&&!['Resolved','Closed'].includes(x.status)?'<label class=\"field resolution-input\">Resolution evidence<textarea data-resolution-id=\"'+esc(x.id)+'\" rows=\"2\" placeholder=\"Required before marking resolved · inspection, reading, action, and verifier\"></textarea></label>':'';
      return '<details class=\"incident-card '+esc(x.severity.toLowerCase())+'\"><summary><span class=\"severity-dot '+esc(x.severity.toLowerCase())+'\"></span><span class=\"incident-summary-main\"><b>'+esc(x.title)+'</b><small>'+esc(x.block||'Campus')+' · '+esc(x.categoryLabel||x.category)+' · reported '+fmtDate(x.createdAt,true)+' by '+esc(reporterName(x.reporterEmail))+'</small></span><span class=\"status-tag\">'+esc(x.status)+'</span><span class=\"severity-tag\">'+esc(x.severity)+'</span></summary><div class=\"incident-detail\">'+escalationTimeline(x)+'<div class=\"incident-facts\"><div><span>Observed problem</span><p>'+esc(triage.problem)+'</p></div><div><span>Possible causes · unconfirmed</span><p>'+esc(triage.causes)+'</p></div><div><span>How long?</span><p>'+esc(triage.duration)+'</p></div><div><span>Potential consequences</span><p>'+esc(triage.consequences)+'</p></div><div><span>Recommended response</span><p>'+esc(triage.response)+'</p></div></div><p class=\"triage-note\">'+esc(triage.certainty)+'</p>'+caution+'<div class=\"reported-evidence\"><b>Reporter’s notes</b><p>'+esc(x.description)+'</p>'+(x.actionTaken?'<p><b>Action taken:</b> '+esc(x.actionTaken)+'</p>':'')+'</div>'+attached+resolution+'<div class=\"incident-tools\">'+(canUpdate?selectField('Update status','status_'+x.id,[['Submitted','Submitted'],['Acknowledged','Acknowledged'],['In progress','In progress'],['Resolved','Resolved'],['Closed','Closed']],x.status).replace('<select name=\"status_'+x.id+'\"','<select data-status-id=\"'+esc(x.id)+'\"'):'')+reward+'</div>'+resolutionInput+'</div></details>';
    }).join('')+'</div>';
  }
  function renderIncidents() {
    const rows=data.incidents.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));
    return head('CAMPUS RESPONSE · INCIDENT DESK','Reports & response workflows','Every workflow separates observed facts, possible causes, unknown duration, potential consequences, and safe next steps.',button('New report','go','primary','data-page=\"staff\"'))
      +'<div class=\"incident-banner\"><span>!</span><div><b>Emergency routing is enabled in this workspace.</b><p>Reports are stored locally and appear in the administrator queue on this shared browser. Do not rely on this front-end demo for cross-device emergency dispatch.</p></div></div>'
      +'<div class=\"stats-grid\">'+statCard('Open reports',String(openIncidents().length),'Submitted or still being handled','⚑')+statCard('Urgent / high',String(rows.filter(x=>!['Resolved','Closed'].includes(x.status)&&['Urgent','High'].includes(x.severity)).length),'Requires immediate human review','!')+statCard('Verified reports',String(rows.filter(x=>x.verified).length),'Eligible reports earn XP once reviewed','✓')+statCard('Latest report',rows.length?fmtDate(rows[0].createdAt):'No reports',rows[0]?rows[0].title:'No institution report yet','◷')+'</div>'
      +'<section class=\"card section-space\"><div class=\"card-head\"><div><h2>Campus incident queue</h2><p>Newest report first · select a row to open the workflow</p></div><span class=\"data-tag\">'+rows.length+' TOTAL</span></div>'+incidentTable(rows,true)+'</section>';
  }
  function renderCrew() {
    const ranked=data.crew.slice().sort((a,b)=>(Number(b.xp)||0)-(Number(a.xp)||0));
    const roster=ranked.map((m,i)=>{
      const r=memberRank(m.xp);
      const shifts=data.shifts.filter(s=>s.email===String(m.email).toLowerCase());
      const reports=data.incidents.filter(x=>x.reporterEmail===String(m.email).toLowerCase());
      const daily=reports.filter(x=>dateInput(new Date(x.createdAt))===dateInput()).length;
      return '<tr><td><span class=\"rank-number\">'+(i+1)+'</span> '+esc(m.name)+'</td><td>'+esc(roles[m.role]?.label||m.role)+'</td><td>'+esc(m.block||'—')+'</td><td>'+reports.length+' total · '+daily+' today</td><td>'+fmtNumber(shifts.reduce((s,x)=>s+Number(x.hours||0),0),1)+' h</td><td><span class=\"xp-badge\">'+fmtNumber(m.xp||0,0)+' XP</span><small>'+esc(r.name)+' · Level '+r.level+'</small></td></tr>';
    }).join('');
    return head('PEOPLE · CREW AND RECOGNITION','Campus crew','Review shifts, report frequency, verification status, and locally earned INFRAIQ recognition points.',isLeader()?button('Export crew CSV','crew-export','ghost'):'')
      +'<div class=\"content-grid\"><section class=\"card\"><div class=\"card-head\"><div><h2>Information contributions</h2><p>Report volume is visible; XP is granted after a leader verifies a report.</p></div><span class=\"data-tag\">QUALITY-GATED</span></div>'+ (ranked.length?'<div class=\"table-wrap\"><table class=\"data-table\"><thead><tr><th>Position</th><th>Role</th><th>Block</th><th>Information</th><th>Shift hours</th><th>Recognition</th></tr></thead><tbody>'+roster+'</tbody></table></div>':'<div class=\"empty-state\"><strong>No crew roster yet</strong><p>Team members appear here as they join this browser workspace.</p></div>')+'</section>'
      +(isLeader()?'<section class=\"card\"><div class=\"card-head\"><div><h2>Add crew member</h2><p>Register the role and normal work location for this shared workspace.</p></div></div><form class=\"form-grid\" data-form=\"crew\">'+field('Name','name','text','','Full name',true)+field('Work email','email','email','','name@college.edu',true)+selectField('Position','role',Object.entries(roles).map(x=>[x[0],x[1].label]),'worker')+selectField('Assigned block','block',blockOptions(true),'')+'<div class=\"form-actions full-field\"><button class=\"button primary\" type=\"submit\">Add to crew</button></div></form><div class=\"trust-note\">XP is a recognition feature in this local demo, not payroll, formal evaluation, or a substitute for supervisor review.</div></section>':'')+'</div>';
  }
  function renderKitchen() {
    const rows=data.kitchen.slice().sort((a,b)=>b.date.localeCompare(a.date));
    const recent=rows.slice(0,7), prepared=recent.reduce((s,x)=>s+Number(x.preparedKg||0),0),wasted=recent.reduce((s,x)=>s+Number(x.wasteKg||0),0);
    const table=rows.length?'<div class=\"table-wrap\"><table class=\"data-table\"><thead><tr><th>Date</th><th>Day</th><th>Menu</th><th>Prepared</th><th>Meals served</th><th>Food waste</th><th>By</th></tr></thead><tbody>'+rows.slice(0,40).map(x=>'<tr><td>'+fmtDate(x.date)+'</td><td>'+esc(x.weekday)+'</td><td>'+esc(x.menu)+'</td><td>'+fmtNumber(x.preparedKg,1)+' kg</td><td>'+fmtNumber(x.meals,0)+'</td><td>'+fmtNumber(x.wasteKg,1)+' kg</td><td>'+esc(reporterName(x.createdBy))+'</td></tr>').join('')+'</tbody></table></div>':'<div class=\"empty-state\"><strong>No kitchen logs yet</strong><p>Enter each day’s menu, prepared food, meals served and measured waste.</p></div>';
    return head('FOOD SERVICES · KITCHEN LOG','Menu, use & food waste','Kitchen staff can update the day-wise menu and actual preparation, service, and waste quantities.',isLeader()?button('Export kitchen CSV','kitchen-export','ghost'):'')
      +'<div class=\"content-grid\"><section class=\"card\"><div class=\"card-head\"><div><h2>Daily kitchen entry</h2><p>One record per service day; later edits replace that date’s entry.</p></div></div><form class=\"form-grid\" data-form=\"kitchen\">'+field('Service date','date','date',dateInput(),'',
       true)+field('Weekday','weekday','text',new Intl.DateTimeFormat('en-IN',{weekday:'long'}).format(new Date()),'Monday',true)
      +'<label class=\"field full-field\">Menu for the day<textarea name=\"menu\" rows=\"2\" required placeholder=\"Breakfast / lunch / dinner items\"></textarea></label>'
      +field('Food prepared','preparedKg','number','','kg',true,'min=\"0\" step=\"any\"')
      +field('Meals served','meals','number','','count',true,'min=\"0\" step=\"1\"')
      +field('Food discarded / wasted','wasteKg','number','','kg',true,'min=\"0\" step=\"any\"')
      +field('Source / note','note','text','','Kitchen scale, meal counter…',false)
      +'<div class=\"form-actions full-field\"><button class=\"button primary\" type=\"submit\">Save kitchen day</button></div></form></section><section class=\"card\"><div class=\"card-head\"><div><h2>Measured weekly balance</h2><p>Most recent seven kitchen entries · recorded quantities only</p></div><button class=\"button small ghost\" data-action=\"rotate-chart\">Rotate chart ↻</button></div>'+(recent.length?donut([{label:'Prepared food used',value:Math.max(0,prepared-wasted)},{label:'Food waste',value:wasted}],'Measured kitchen food used and wasted'):'<div class=\"chart-empty\"><strong>Chart waiting for measured entries</strong><p>No decorative or assumed quantities are displayed.</p></div>')+'</section></div>'
      +'<section class=\"card section-space\"><div class=\"card-head\"><div><h2>Day-wise kitchen ledger</h2><p>Campus administration and kitchen users share this browser workspace.</p></div></div>'+table+'</section>';
  }
  function renderEquipment() {
    const items=data.equipment.slice().sort((a,b)=>a.name.localeCompare(b.name));
    const rows=items.map(x=>'<tr id="asset-row-'+esc(x.id)+'" class="'+(ui.focusAssetId===x.id?'asset-row-focused':'')+'"><td><b>'+esc(x.name)+'</b><small>'+esc(x.serial||'No tag recorded')+'</small></td><td>'+esc(x.type)+'</td><td>'+esc(x.block||'Campus')+'</td><td>'+esc(x.condition)+'</td><td>'+esc(x.quantity)+'</td><td><label class="asset-date-field"><span class="sr-only">Next maintenance date for '+esc(x.name)+'</span><input type="date" value="'+esc(x.maintenanceDue||'')+'" data-asset-maintenance-id="'+esc(x.id)+'" '+(canManage()?'':'disabled')+' aria-label="Next maintenance date for '+esc(x.name)+'"></label><small>'+(x.maintenanceDue?'Saved schedule':'No schedule')+'</small></td><td><button class="button small ghost" data-action="open-scheduled-asset" data-id="'+esc(x.id)+'">Open</button> <button class="button small ghost" data-action="remove-equipment" data-id="'+esc(x.id)+'">Remove</button></td></tr>').join('');
    return head('ASSET MANAGEMENT · ACTUAL REGISTER','Equipment register','List the instruments and equipment that are physically available on campus. Import and export movements are tracked in Six-month data.',button('Export equipment CSV','equipment-export','ghost'))
      +'<div class="content-grid"><section class="card"><div class="card-head"><div><h2>Add equipment / instrument</h2><p>Record one asset or a homogeneous inventory lot.</p></div></div><form class="form-grid" data-form="equipment">'+field('Name / instrument','name','text','','Transformer A, microscope…',true)+field('Asset type','type','text','','Electrical, lab, HVAC…',true)+field('Serial / inventory tag','serial','text','','Optional',false)+selectField('Campus block','block',blockOptions(true),'')+selectField('Condition','condition',[['Operational','Operational'],['Needs inspection','Needs inspection'],['Out of service','Out of service'],['Unknown','Unknown']], 'Operational')+field('Quantity','quantity','number','1','',true,'min="1" step="1"')+field('Next maintenance due','maintenanceDue','date','','Optional · actual schedule date',false)+'<div class="form-actions full-field"><button class="button primary" type="submit">Save asset</button></div></form></section><section class="card"><div class="card-head"><div><h2>Inventory movement</h2><p>Movements use the verified history ledger and its six-month record coverage.</p></div></div><div class="movement-steps"><div><b>1</b><span>Open Six-month data</span></div><div><b>2</b><span>Record equipment import/export with date, quantity and reference</span></div><div><b>3</b><span>Keep the register condition in sync after receipt or disposal</span></div></div><button class="button" data-action="go" data-page="history">Open movement ledger ↗</button><div class="trust-note">No equipment movement is assumed from the current asset list.</div></section></div><section class="card section-space"><div class="card-head"><div><h2>Available equipment</h2><p>Institution-entered register · '+(cloudSession?'shared campus database':'local workspace')+' · '+(canManage()?'edit schedules inline':'schedules are read-only for this role')+'</p></div><span class="data-tag">'+items.length+' ASSET ROWS</span></div>'+(items.length?'<div class="table-wrap"><table class="data-table"><thead><tr><th>Name / tag</th><th>Type</th><th>Block</th><th>Condition</th><th>Quantity</th><th>Next maintenance</th><th>Actions</th></tr></thead><tbody>'+rows+'</tbody></table></div>':'<div class="empty-state"><strong>No equipment has been entered</strong><p>Register instruments before asking the assistant about available assets.</p></div>')+'</section>';
  }
  function renderCampus() {
    const q=[profile.address,profile.city,profile.region].filter(Boolean).join(', ')||profile.collegeName||'';
    const mapUrl='https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(profile.latitude&&profile.longitude?profile.latitude+','+profile.longitude:q);
    const map = profile.mapsKey&&profile.latitude&&profile.longitude
      ? '<iframe class=\"campus-map\" title=\"Google Map for '+esc(profile.collegeName)+'\" loading=\"lazy\" referrerpolicy=\"strict-origin-when-cross-origin\" src=\"https://www.google.com/maps/embed/v1/place?key='+encodeURIComponent(profile.mapsKey)+'&q='+encodeURIComponent(profile.latitude+','+profile.longitude)+'\"></iframe>'
      : '<div class=\"map-placeholder\"><span>⌖</span><b>'+esc(profile.collegeName||'Campus location')+'</b><p>'+esc(q||'Enter a campus address to open it in Google Maps.')+'</p><a class=\"button\" href=\"'+esc(mapUrl)+'\" target=\"_blank\" rel=\"noopener\">Open in Google Maps ↗</a></div>';
    const blocks=data.blocks.map(b=>'<article class=\"block-card\"><div class=\"block-top\"><div><span class=\"eyebrow\">CAMPUS BLOCK</span><h3>'+esc(b.name)+'</h3></div><span class=\"data-tag\">'+esc(b.opening||'—')+'–'+esc(b.closing||'—')+'</span></div><div class=\"block-counts\"><span><b>'+esc(b.students||'—')+'</b> students</span><span><b>'+esc(b.faculty||'—')+'</b> faculty</span><span><b>'+esc(b.workers||'—')+'</b> staff</span></div><p>'+esc(b.labs||0)+' labs · '+esc(b.instruments||0)+' instruments'+(b.area?' · '+esc(b.area)+' m²':'')+'</p><button class=\"button small ghost\" data-action=\"remove-block\" data-id=\"'+esc(b.id)+'\">Remove block</button></article>').join('');
    return head('FACILITY PROFILE · CAMPUS DETAILS','Campus & blocks','Set your institution’s actual schedule, location, footprint, block occupancy, labs and instruments.',button('Save campus profile','save-campus','primary'))
      +'<div class=\"content-grid\"><section class=\"card\"><div class=\"card-head\"><div><h2>Institution details</h2><p>Optional occupancy details improve context; blank fields are not estimated.</p></div></div><form class=\"form-grid\" data-form=\"campus\">'+field('College / institution','collegeName','text',profile.collegeName,'Institution name',true)+field('City','city','text',profile.city,'City',true)+field('State / region','region','text',profile.region,'State / region',true)+field('Campus address','address','text',profile.address,'Street / locality',false)+field('Latitude','latitude','number',profile.latitude,'optional',false,'step=\"any\" min=\"-90\" max=\"90\"')+field('Longitude','longitude','number',profile.longitude,'optional',false,'step=\"any\" min=\"-180\" max=\"180\"')+field('Campus area · m²','campusSize','number',profile.campusSize,'optional',false,'min=\"0\" step=\"any\"')+field('Number of blocks','blockCount','number',profile.blockCount,'optional',false,'min=\"0\" step=\"1\"')+field('College opens','opening','time',profile.opening||'08:00','',false)+field('College closes','closing','time',profile.closing||'18:00','',false)+field('Electricity tariff · ₹ / kWh','electricityTariff','number',profile.electricityTariff,'Optional · from current bill',false,'min="0" step="any"')+field('Usage alert threshold · %','alertThresholdPct','number',profile.alertThresholdPct||'25','Optional · default 25%',false,'min="5" max="200" step="1"')+field('Restricted Maps Embed API key','mapsKey','password',profile.mapsKey,'Optional; stored in this browser',false,'autocomplete=\"off\"')+'<div class=\"form-actions full-field\"><button class=\"button primary\" type=\"submit\">Save details</button></div><p class=\"small-note full-field\">Google Maps search works without a key. Restrict any embed key to your deployed domain and Maps Embed API.</p></form></section><section class=\"card\"><div class=\"card-head\"><div><h2>Campus location</h2><p>Google Maps search from your saved address or coordinates.</p></div></div><div class=\"map-frame\">'+map+'</div></section></div>'
      +'<div class=\"content-grid section-space\"><section class=\"card\"><div class=\"card-head\"><div><h2>Campus blocks</h2><p>Student, faculty and worker counts are optional actual figures.</p></div><span class=\"data-tag\">'+data.blocks.length+' BLOCKS</span></div>'+(blocks?'<div class=\"block-grid\">'+blocks+'</div>':'<div class=\"empty-state\"><strong>No block profiles</strong><p>Add a block below. INFRAIQ will not invent occupancy, labs, or equipment counts.</p></div>')+'</section>'
      +'<section class=\"card\"><div class=\"card-head\"><div><h2>Add a campus block</h2><p>Opening and closing times can differ from the college schedule.</p></div></div><form class=\"form-grid\" data-form=\"block\">'+field('Block name / number','name','text','','Block 1',true)+field('Area · m²','area','number','','optional',false,'min=\"0\" step=\"any\"')+field('Students','students','number','','optional',false,'min=\"0\" step=\"1\"')+field('Faculty','faculty','number','','optional',false,'min=\"0\" step=\"1\"')+field('Workers','workers','number','','optional',false,'min=\"0\" step=\"1\"')+field('Labs','labs','number','','optional',false,'min=\"0\" step=\"1\"')+field('Instruments','instruments','number','','optional',false,'min=\"0\" step=\"1\"')+field('Opens','opening','time','08:00','',false)+field('Closes','closing','time','18:00','',false)+'<div class=\"form-actions full-field\"><button class=\"button primary\" type=\"submit\">Add block</button></div></form></section></div>';
  }
  function historyTemplate() {
    const months=requiredMonths();
    const lines=[['date','category','block','metric','value','unit','details','reference'].join(',')];
    months.forEach(m=>categories.forEach(c=>lines.push([m.key+'-01',c[0],'','','','','',''].join(','))));
    download('infraiq-six-month-campus-template.csv',lines.join('\r\n'),'text/csv;charset=utf-8');
    toast('Blank template downloaded. It contains no example readings.');
  }
  function renderAiStartChoice() {
    const six=historyReadiness();
    return '<main class="signup-shell"><section class="signup-art"><a class="brand" href="about.html">INFRA<span>IQ</span></a><div class="eyebrow">YOUR CAMPUS · YOUR CHOICE</div><h1>Start with<br><em>what you know.</em></h1><p>Six months of history can improve trends, but you do not need to wait. Start with current records, reports, or clearly labeled simulation data.</p><div class="signup-mark">IQ</div></section><section class="signup-panel"><div class="signup-card"><div class="eyebrow">AI DATA SETUP · OPTIONAL</div><h2>How would you like to begin?</h2><p>Historic data gives the trend tools a longer reference. It does not train a machine-learning model, and you can add it later.</p><div class="choice-card"><div class="eyebrow">MORE HISTORICAL CONTEXT</div><h3>Enter six months of campus records</h3><p>Continue to the existing history workspace. You can add actual records category-by-category; the data remains editable.</p><button class="button primary full-button" data-action="choose-ai-start" data-choice="six_months">Enter six-month data ↗</button><small>'+Math.round(six.ratio*100)+'% of the existing 11-category coverage checklist is currently present.</small></div><div class="choice-card"><div class="eyebrow">START USING INFRAIQ NOW</div><h3>Go straight to the workspace</h3><p>Enter regular records whenever they are available. Explore resource intelligence with generated data that is clearly labeled fictional.</p><button class="button full-button" data-action="choose-ai-start" data-choice="start_now">Start now with regular data ↗</button><small>Forecasts show a data gap until there are enough comparable measurements.</small></div><div class="trust-note">This question appears once after sign-in. You can add six-month data at any time from the sidebar.</div></div></section></main>';
  }
  function localAiNaiveBayes(text) {
    const training={electrical:['transformer vibration buzzing breaker power cable spark outage electrical','motor humming overheating current trip socket'],water:['water leak dripping pipe tap pump tank overflow consumption meter','toilet flush running wet floor valve water pressure'],hvac:['air conditioner hvac ventilation hot cold temperature fan cooling heating','lab ventilation unit filter thermostat room temperature'],lighting:['light lamp bulb switch left on dark corridor lighting','classroom lights running daytime occupancy sensor'],waste:['food waste garbage overflowing bins plastic waste collection','canteen leftover waste segregation'],security:['door lock gate access intruder suspicious entry camera','broken fence security badge unauthorized entry']};
    const tokenize=s=>(String(s||'').toLowerCase().match(/[a-z]{3,}/g)||[]).filter(w=>!['the','and','with','from','this','that','was','for','near','our','has','are','have','very'].includes(w));
    const words=tokenize(text);if(!words.length)return {category:'other',confidence:0,role:'Campus administrator'};
    const vocab=new Set(Object.values(training).flatMap(tokenize)),scores=[];
    for(const [category,examples]of Object.entries(training)){const samples=tokenize(examples.join(' ')),counts=new Map();samples.forEach(w=>counts.set(w,(counts.get(w)||0)+1));let score=Math.log(1/Object.keys(training).length);for(const w of words)score+=Math.log(((counts.get(w)||0)+1)/(samples.length+vocab.size));scores.push({category,score});}
    scores.sort((a,b)=>b.score-a.score);const ex=scores[0].score,den=scores.reduce((sum,x)=>sum+Math.exp(x.score-ex),0),confidence=Math.exp(ex)/den;const role={electrical:'Environmental engineer / authorized electrical team',water:'Facilities / plumbing team',hvac:'Facilities / HVAC technician',lighting:'Facilities / electrical team',waste:'Kitchen / housekeeping team',security:'Security supervisor'}[scores[0].category]||'Campus administrator';return {category:scores[0].category,confidence,role};
  }
  function categorizeComplaints() {
    const rows=data.incidents.map(item=>{const result=localAiNaiveBayes([item.title,item.description,item.categoryLabel].join(' '));return {...result,item};});
    const groups=new Map();for(const row of rows){const item=groups.get(row.category)||{category:row.category,items:[],high:0,oldest:null};item.items.push(row);if(['Urgent','High'].includes(row.item.severity)&&!['Resolved','Closed'].includes(row.item.status))item.high++;const at=Date.parse(row.item.createdAt||row.item.observedAt||'');if(Number.isFinite(at)&&(!item.oldest||at<item.oldest))item.oldest=at;groups.set(row.category,item);}return [...groups.values()].sort((a,b)=>b.high-a.high||b.items.length-a.items.length);
  }
  function linearModelFit(rows,focusDomain) {
    if(rows.length<12)return null;const target=r=>focusDomain==='water'?r.water:r.energy,features=r=>[1,r.occupancy,r.temperature,r.hvac,r.lighting,r.solar,r.floor],split=Math.max(8,Math.floor(rows.length*.8)),train=rows.slice(0,split),test=rows.slice(split);if(test.length<2)return null;
    const n=7,A=Array.from({length:n},()=>Array(n+1).fill(0));for(const r of train){const x=features(r);for(let i=0;i<n;i++){for(let j=0;j<n;j++)A[i][j]+=x[i]*x[j];A[i][n]+=x[i]*target(r);}}
    for(let i=1;i<n;i++)A[i][i]+=1e-5;
    for(let col=0;col<n;col++){let pivot=col;for(let row=col+1;row<n;row++)if(Math.abs(A[row][col])>Math.abs(A[pivot][col]))pivot=row;[A[col],A[pivot]]=[A[pivot],A[col]];const d=A[col][col];if(Math.abs(d)<1e-10)return null;for(let j=col;j<=n;j++)A[col][j]/=d;for(let row=0;row<n;row++)if(row!==col){const factor=A[row][col];for(let j=col;j<=n;j++)A[row][j]-=factor*A[col][j];}}
    const beta=A.map(row=>row[n]),errors=test.map(r=>target(r)-Math.max(0,features(r).reduce((sum,x,i)=>sum+x*beta[i],0))),mae=errors.reduce((s,x)=>s+Math.abs(x),0)/errors.length,rmse=Math.sqrt(errors.reduce((s,x)=>s+x*x,0)/errors.length),mape=test.reduce((s,r,i)=>s+Math.abs(errors[i])/Math.max(1,target(r)),0)/test.length*100;return {beta,mae,rmse,mape,train:train.length,test:test.length};
  }
  function simulationAnalysis(run) {
    if(!run?.rows?.length)return null;const rows=run.rows,model=linearModelFit(rows,run.focusDomain),energy=rows.reduce((s,r)=>s+r.energy,0),water=rows.reduce((s,r)=>s+r.water,0),renewable=rows.reduce((s,r)=>s+r.solar+r.battery,0);
    const median=values=>{const sorted=values.slice().sort((a,b)=>a-b);return sorted[Math.floor(sorted.length/2)]||0;};const expectedEnergy=median(rows.filter(r=>r.occupancy<.25&&!r.anomaly).map(r=>r.energy));
    const anomalies=rows.filter(r=>r.anomaly||r.energy>Math.max(1,expectedEnergy*2.1)&&r.occupancy<.25||r.water>Math.max(1,median(rows.map(x=>x.water))*2.1));
    const lightOpportunity=rows.filter(r=>r.occupancy<.28).reduce((s,r)=>s+r.lighting*.18,0),hvacOpportunity=rows.filter(r=>r.occupancy<.4&&r.temperature<29).reduce((s,r)=>s+r.hvac*.1,0),potential=Math.min(.18,Math.max(0,(lightOpportunity+hvacOpportunity)/Math.max(energy,1)));
    return {energy,water,renewable,renewablePct:energy?renewable/energy*100:0,anomalies,model,potential,estimatedSavingsKwh:energy*potential};
  }
  function generateScenario(form) {
    const fd=new FormData(form),days=Number(fd.get('days')),buildings=Number(fd.get('buildings')),floors=Number(fd.get('floors')),peak=Number(fd.get('occupancy')),season=String(fd.get('season')),fault=String(fd.get('anomaly'));
    if(!Number.isInteger(days)||days<7||days>30||!Number.isInteger(buildings)||buildings<1||buildings>4||!Number.isInteger(floors)||floors<1||floors>6||!Number.isFinite(peak)||peak<1||peak>5000){toast('Scenario bounds are 7–30 days, 1–4 buildings, 1–6 floors, and 1–5,000 peak people per floor.');return;}
    const blocks=data.blocks.map(x=>x.name);const base=String(fd.get('block')||'Building A'),seasonBase={summer:34,monsoon:29,winter:19,shoulder:27}[season]||27,rows=[];let anomalyUsed=false;
    for(let di=days-1;di>=0;di--){const dateObj=new Date();dateObj.setDate(dateObj.getDate()-di);const date=dateInput(dateObj),weekend=[0,6].includes(dateObj.getDay());
      for(let b=0;b<buildings;b++)for(let floor=1;floor<=floors;floor++)for(const hour of [0,6,12,18]){
        const periodOcc=hour===0?.025:hour===6?.32:hour===12?.86:.58,occupancy=Math.max(0,peak*periodOcc*(weekend?.48:1)*(1+(b%3)*.04));const temp=seasonBase+8*Math.sin((hour-8)/24*Math.PI*2)+(floor-1)*.15+(weekend?-.3:0);
        const hvac=Math.min(.92,Math.max(.08,.15+Math.max(0,temp-22)*.033)*(periodOcc>.5?1:.7));const lighting=hour>=6&&hour<18?Math.min(.9,.32+periodOcc*.42):.1;const solar=Math.max(0,Math.sin((hour-6)/12*Math.PI))*(season==='monsoon'?.35:.72)*(floor%2?.9:1);const building=b===0?base:(blocks.length>1?blocks[(blocks.indexOf(base)+b)%blocks.length]:`${base} · Building ${b+1}`);
        let energy=Math.max(.5,8+occupancy*.025+temp*.12+hvac*24+lighting*18+floor*1.2-solar*8);let water=Math.max(.2,7+occupancy*.018+floor*1.1);let anomaly='';
        if(!anomalyUsed&&fault==='energy'&&hour===0&&di===Math.floor(days*.65)&&b===0&&floor===1){energy*=3.1;anomaly='Injected after-hours energy spike';anomalyUsed=true;}
        if(!anomalyUsed&&fault==='water'&&hour===12&&di===Math.floor(days*.65)&&b===0&&floor===1){water*=4.2;anomaly='Injected possible water leak spike';anomalyUsed=true;}
        const generation=solar*energy*.34,battery=generation*.15,municipal=water*.62,groundwater=water*.25,rainwater=water*.13;
        rows.push({id:id('sim-interval'),date,time:String(hour).padStart(2,'0')+':00',dayType:weekend?'weekend':'weekday',season,block:building,floor,occupancy,temperature:Number(temp.toFixed(1)),hvac:Number(hvac.toFixed(3)),lighting:Number(lighting.toFixed(3)),solar:Number(generation.toFixed(2)),battery:Number(battery.toFixed(2)),grid:Number(Math.max(0,energy-generation-battery).toFixed(2)),energy:Number(energy.toFixed(2)),water:Number(water.toFixed(2)),waterSources:{municipal:Number(municipal.toFixed(2)),groundwater:Number(groundwater.toFixed(2)),rainwater:Number(rainwater.toFixed(2))},anomaly,synthetic:true});
      }
    }
    if(fault!=='none'&&!anomalyUsed)toast('The requested anomaly could not be placed in this date window; scenario generated without an injected fault.');
    const run={id:id('simulation'),name:String(fd.get('name')||'Campus scenario').trim().slice(0,100),createdAt:new Date().toISOString(),season,focusDomain:String(fd.get('focusDomain')||'energy'),days,buildings,floors,block:base,peakOccupancy:peak,tariff:Number(fd.get('tariff'))||null,alternativeTariff:Number(fd.get('alternativeTariff'))||null,rows,synthetic:true,createdBy:personKey(),model:'local-multivariate-linear-regression'};
    const mine=data.simulationRuns.filter(x=>String(x.createdBy||'').toLowerCase()===personKey()).slice(-3);data.simulationRuns=[...data.simulationRuns.filter(x=>String(x.createdBy||'').toLowerCase()!==personKey()),...mine,run];save();ui.simulationView='results';render();toast('Synthetic scenario generated and evaluated. It was not added to measured history.');
  }
  function saveResourceMix(form) {
    const fd=new FormData(form),date=String(fd.get('date')||''),keys=['gridKwh','solarKwh','batteryKwh','municipalKl','groundwaterKl','rainwaterKl'];const vals=Object.fromEntries(keys.map(key=>[key,fd.get(key)===''?null:Number(fd.get(key))]));
    if(!validDateOnly(date)||date>dateInput()||Object.values(vals).some(v=>v!==null&&(!Number.isFinite(v)||v<0))||Object.values(vals).every(v=>v===null)){toast('Add a valid past/today date and at least one non-negative measured source value.');return;}
    const row={id:id('source_mix'),date,...vals,reference:String(fd.get('reference')||'').trim(),createdBy:personKey(),recordType:'actual_source_mix'};data.resourceSources.push(row);save();render();toast('Actual source mix saved separately from the simulator.');
  }
  function saveResourceObservation(form) {
    const fd=new FormData(form),date=String(fd.get('date')||''),time=String(fd.get('time')||''),block=String(fd.get('block')||'').trim(),floor=Number(fd.get('floor'))||1;
    const metrics=['energyKwh','waterKl','temperatureC','occupancy','hvacHours','lightingHours'],values=Object.fromEntries(metrics.map(key=>[key,fd.get(key)===''?null:Number(fd.get(key))]));
    if(!validDateOnly(date)||date>dateInput()||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)||!block||!Number.isInteger(floor)||floor<1||Object.values(values).some(v=>v!==null&&(!Number.isFinite(v)||v<0))||(values.energyKwh===null&&values.waterKl===null)){toast('Enter a valid past/today time, building, floor, and at least one non-negative energy or water reading.');return;}
    const row={id:id('resource_obs'),date,time,block,floor,...values,createdBy:personKey(),recordType:'actual_interval_observation'};data.resourceObservations.push(row);save();render();toast('Measured interval saved. Spike comparisons will appear after six comparable earlier readings.');
  }
  function actualObservationAlerts() {
    const all=data.resourceObservations.slice().sort((a,b)=>(String(a.date)+String(a.time)).localeCompare(String(b.date)+String(b.time))),alerts=[];
    const median=values=>{const sorted=values.slice().sort((a,b)=>a-b),mid=Math.floor(sorted.length/2);return sorted.length%2?sorted[mid]:(sorted[mid-1]+sorted[mid])/2;};
    for(const row of all)for(const [key,label,unit] of [['energyKwh','Energy','kWh / interval'],['waterKl','Water','kL / interval']]){
      if(row[key]==null||row[key]==='')continue;const value=Number(row[key]);if(!Number.isFinite(value))continue;const prior=all.filter(x=>String(x.block)===String(row.block)&&Number(x.floor)===Number(row.floor)&&String(x.time).slice(0,2)===String(row.time).slice(0,2)&&(String(x.date)+String(x.time))<(String(row.date)+String(row.time))&&x[key]!=null&&x[key]!==''&&Number.isFinite(Number(x[key]))).slice(-6);
      if(prior.length<6)continue;const base=median(prior.map(x=>Number(x[key]))),mad=median(prior.map(x=>Math.abs(Number(x[key])-base))),threshold=Math.max(base*1.5,base+3*mad);if(value>threshold&&value>0)alerts.push({date:row.date,time:row.time,block:row.block,floor:row.floor,label,unit,value,baseline:base,prior:prior.length});
    }
    return alerts.sort((a,b)=>(String(b.date)+String(b.time)).localeCompare(String(a.date)+String(a.time)));
  }
  function simulationChart(run) {
    const rows=run?.rows||[];if(!rows.length)return '';const hours=[0,6,12,18],groups=hours.map(hour=>rows.filter(r=>Number(r.time.slice(0,2))===hour)),energy=groups.map(g=>g.reduce((s,r)=>s+r.energy,0)/Math.max(1,g.length)),water=groups.map(g=>g.reduce((s,r)=>s+r.water,0)/Math.max(1,g.length)),maxEnergy=Math.max(...energy,1),maxWater=Math.max(...water,1),y=(v,max)=>230-(v/max)*175,points=(values,max)=>values.map((v,i)=>`${i?'L':'M'} ${70+i*210} ${y(v,max)}`).join(' ');
    return '<svg class="trend-svg forecast-plot" viewBox="0 0 760 270" role="img" aria-label="Synthetic energy and water time profile indexed separately to each series peak"><path d="M48 18V238H740" class="chart-axis"/><path d="'+points(energy,maxEnergy)+'" class="chart-line chart-glow" stroke="#77e7bc"/><path d="'+points(water,maxWater)+'" class="chart-line chart-glow" stroke="#89b4ff"/>'+hours.map((h,i)=>'<circle cx="'+(70+i*210)+'" cy="'+y(energy[i],maxEnergy)+'" r="4" fill="#77e7bc"><title>'+h+':00 synthetic energy profile</title></circle><circle cx="'+(70+i*210)+'" cy="'+y(water[i],maxWater)+'" r="4" fill="#89b4ff"><title>'+h+':00 synthetic water profile</title></circle><text x="'+(70+i*210)+'" y="258" text-anchor="middle" class="chart-label">'+String(h).padStart(2,'0')+':00</text>').join('')+'<text x="520" y="22" class="chart-label">Normalized profile · each peak = 100</text></svg>';
  }
  function latestSimulation() { return data.simulationRuns.slice().sort((a,b)=>String(a.createdAt||'').localeCompare(String(b.createdAt||''))).at(-1)||null; }
  function renderIntelligence() {
    const latest=latestSimulation(),analysis=simulationAnalysis(latest),complaints=categorizeComplaints(),actualAlerts=actualObservationAlerts(),blocks=data.blocks.length?data.blocks.map(x=>[x.name,x.name]):[['Building A','Building A'],['Building B','Building B'],['Building C','Building C']];
    const sourceValue=value=>value==null?'—':fmtNumber(value,1);
    const anomalyRows=analysis?.anomalies?.slice(0,8).map(x=>'<div class="metric-line"><span>'+esc(x.date)+' · '+esc(x.time)+' · '+esc(x.block)+' / Floor '+x.floor+'</span><b>'+esc(x.anomaly||'Outlier pattern')+' · '+(x.anomaly?.toLowerCase().includes('water')?fmtNumber(x.water,1)+' L / 6h':fmtNumber(x.energy,1)+' kWh / 6h')+'</b></div>').join('')||'';
    const complaintRows=complaints.slice(0,6).map(x=>'<div class="metric-line"><span>'+esc(x.category.toUpperCase())+' · '+x.items.length+' report(s)'+(x.high?' · '+x.high+' urgent/high open':'')+'<small>'+esc(x.role)+' · offline text classifier · verify by a person</small></span><b>'+esc(x.items.slice(0,2).map(y=>y.item.title).join(' / '))+'</b></div>').join('');
    const simulatedBanner=analysis?'<section class="card sim-banner"><div><span class="data-tag">SYNTHETIC SCENARIO · NOT CAMPUS MEASUREMENTS</span><h2>'+esc(latest.name)+'</h2><p>'+latest.rows.length+' generated six-hour intervals · '+esc(latest.days)+' days · '+esc(latest.buildings)+' buildings × '+esc(latest.floors)+' floors · '+esc(latest.season)+' scenario</p></div><button class="button small ghost" data-action="export-simulation">Export scenario CSV</button></section>':'';
    return head('PS-04 · RESOURCE & ESTATE INTELLIGENCE','Resource intelligence','Focused energy and water analysis for one university-campus model. Use actual records or create a clearly marked synthetic scenario; no live sensors are required.',button('Six-month records','go','ghost','data-page="history"'))
      +'<section class="card info-callout"><div class="eyebrow">OPTIONAL HISTORY · START WITHOUT WAITING</div><b>Six months improve the history-based trend. They are not required for regular records, offline complaint analysis, or this scenario simulator.</b><p>Generated data is stored separately from measured records and never appears as an actual utility reading.</p></section>'
      +'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">SCENARIO BUILDER · CPU ONLY</div><h2>Generate building and floor intervals</h2><p>Vary campus blocks, floor counts, occupancy, time of day, day type, season, HVAC, lighting, and renewable/water sources. Values are illustrative and explicitly synthetic.</p></div><span class="data-tag">NO DEVICE REQUIRED</span></div><form class="form-grid" data-form="simulation">'+field('Scenario name','name','text','Campus energy/water scenario','e.g. Summer weekday baseline',true)+selectField('Primary model focus','focusDomain',[['energy','Energy & HVAC'],['water','Water use & leaks']],'energy')+selectField('Campus building / block','block',blocks,blocks[0][0])+field('Buildings to include','buildings','number','2','',true,'min="1" max="4" step="1"')+field('Floors per building','floors','number','3','',true,'min="1" max="6" step="1"')+field('Scenario days','days','number','21','',true,'min="7" max="30" step="1"')+selectField('Season / climate profile','season',[['summer','Summer · hot'],['monsoon','Monsoon · humid'],['winter','Winter · cool'],['shoulder','Shoulder season']],'winter')+selectField('Inject a test anomaly','anomaly',[['none','No injected fault'],['energy','After-hours energy spike'],['water','Possible water leak spike']], 'none')+field('Estimated people at peak per floor','occupancy','number','180','scenario assumption',true,'min="1" max="5000" step="1"')+field('Current grid tariff · ₹ / kWh','tariff','number',profile.electricityTariff||'','Optional; from actual bill',false,'min="0" step="any"')+field('Alternative supply scenario · ₹ / kWh','alternativeTariff','number','','Optional; approved quote only',false,'min="0" step="any"')+'<div class="form-actions full-field"><button class="button primary" type="submit">Generate & analyze synthetic scenario ↗</button></div></form><div class="trust-note">Deterministic scenario equations run locally on this device. They do not read campus sensors, weather services, or any real institution data.</div></section>'
      +simulatedBanner
      +(analysis?'<div class="stats-grid section-space">'+statCard('Scenario energy',fmtNumber(analysis.energy,0)+' kWh','Generated interval totals · synthetic','ϟ')+statCard('Scenario water',fmtNumber(analysis.water,0)+' L','Generated interval totals · synthetic','⌁')+statCard('Renewables modeled',fmtNumber(analysis.renewablePct,1)+'%',fmtNumber(analysis.renewable,0)+' kWh solar/battery in scenario','☼')+statCard('Detected patterns',String(analysis.anomalies.length),'Injected or rule-detected scenario outliers','⌁')+'</div><section class="card section-space"><div class="card-head"><div><div class="eyebrow">MOTION-READY TIME-OF-DAY GRAPH</div><h2>Scenario load profile</h2><p>Average energy and water profiles by 00:00 / 06:00 / 12:00 / 18:00. Each series is normalized to its own peak because their units differ.</p></div><span class="data-tag">SYNTHETIC ONLY</span></div>'+simulationChart(latest)+'</section>':'')
      +(analysis?'<div class="content-grid section-space"><section class="card"><div class="card-head"><div><div class="eyebrow">HELD-OUT VALIDATION</div><h2>'+esc(latest.focusDomain==='water'?'Water use':'Energy & HVAC')+' regression evaluation</h2><p>CPU multivariable least-squares model · later intervals held out from fitting.</p></div></div>'+(analysis.model?'<div class="metric-line"><span>Train / test intervals</span><b>'+analysis.model.train+' / '+analysis.model.test+'</b></div><div class="metric-line"><span>Mean absolute error</span><b>'+fmtNumber(analysis.model.mae,2)+' '+(latest.focusDomain==='water'?'L':'kWh')+' / interval</b></div><div class="metric-line"><span>Root mean squared error</span><b>'+fmtNumber(analysis.model.rmse,2)+' '+(latest.focusDomain==='water'?'L':'kWh')+' / interval</b></div><div class="metric-line"><span>Mean absolute percentage error</span><b>'+fmtNumber(analysis.model.mape,1)+'%</b></div>':'<div class="chart-empty">Add more scenario intervals to fit and evaluate the model.</div>')+'<p class="small-note">These scores validate against synthetic held-out samples only. They do not measure real-campus model accuracy.</p></section><section class="card"><div class="card-head"><div><div class="eyebrow">RESOURCE OPTIMIZATION · SIMULATED</div><h2>Efficiency & procurement view</h2></div></div><div class="metric-line"><span>Modeled low-occupancy lighting/HVAC opportunity</span><b>'+fmtNumber(analysis.estimatedSavingsKwh,1)+' kWh · '+fmtNumber(analysis.potential*100,1)+'%</b></div><div class="metric-line"><span>Current all-grid rate scenario</span><b>'+(Number(latest.tariff)>0?'₹'+fmtNumber(analysis.energy*Number(latest.tariff),0):'Current tariff not entered')+'</b></div><div class="metric-line"><span>Alternative rate scenario</span><b>'+(Number(latest.alternativeTariff)>0?'₹'+fmtNumber(analysis.energy*Number(latest.alternativeTariff),0)+' · modeled difference ₹'+fmtNumber(analysis.energy*(Number(latest.tariff||0)-Number(latest.alternativeTariff)),0):'No alternative quote entered')+'</b></div><div class="metric-line"><span>Scenario solar + battery share</span><b>'+fmtNumber(analysis.renewablePct,1)+'%</b></div><p>'+ (analysis.renewablePct<20?'Scenario is highly grid-dependent. To assess a renewable option, add measured solar output and compare a site feasibility study plus an approved tariff quote. No rooftop or generation estimate is inferred here.':'The scenario includes a renewable share. Compare it with actual source-mix records before using the result for a purchase decision.')+'</p><p class="small-note">Potential savings and tariff comparisons are scenario estimates, not proposals or promises; comfort/service quality and contract terms are not independently validated. Use approved campus data and procurement review.</p></section></div>':'')
      +(analysis?'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">RULE-BASED ANOMALY SCREEN</div><h2>Patterns to inspect</h2><p>Spike detection compares simulated intervals against the scenario baseline.</p></div></div>'+(anomalyRows||'<div class="empty-state"><strong>No scenario outlier was detected</strong><p>Try the water-leak or after-hours spike scenario to inspect the alert workflow.</p></div>')+'</section>':'')
      +'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">MEASURED INTERVALS · MANUAL / SENSOR EXPORT</div><h2>Enter actual energy and water readings</h2><p>Record real meter or sensor-export values by building, floor, date, and time. Comparisons use only prior readings for that building and time of day.</p></div><span class="data-tag">'+data.resourceObservations.length+' ACTUAL READINGS</span></div><form class="form-grid" data-form="resource-observation">'+field('Reading date','date','date',dateInput(),'',true)+field('Reading time','time','time','08:00','',true)+selectField('Campus building / block','block',blocks,blocks[0][0])+field('Floor number','floor','number','1','',true,'min="1" step="1"')+field('Electricity · kWh for interval','energyKwh','number','','Leave blank if unknown',false,'min="0" step="any"')+field('Water · kL for interval','waterKl','number','','Leave blank if unknown',false,'min="0" step="any"')+field('Temperature · °C','temperatureC','number','','Optional actual reading',false,'step="any"')+field('Occupancy · people','occupancy','number','','Optional counted value',false,'min="0" step="1"')+field('HVAC runtime · hours','hvacHours','number','','Optional actual hours',false,'min="0" max="24" step="any"')+field('Lighting runtime · hours','lightingHours','number','','Optional actual hours',false,'min="0" max="24" step="any"')+'<div class="form-actions full-field"><button class="button primary" type="submit">Save measured reading</button></div></form><div class="trust-note">No sensor is connected. Enter actual meter readings or values exported from your own sensors. A possible spike is a review cue only, not proof of a leak or equipment fault.</div></section>'
      +'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">MEASURED PATTERN REVIEW</div><h2>Unusual actual readings</h2><p>High readings are compared to the six most recent earlier entries for the same building and hour, using a robust median / median-deviation baseline.</p></div><span class="data-tag">'+actualAlerts.length+' REVIEW CUES</span></div>'+(actualAlerts.slice(0,12).map(x=>'<div class="metric-line"><span>'+esc(x.date)+' · '+esc(x.time)+' · '+esc(x.block)+' / Floor '+x.floor+' · '+esc(x.label)+'</span><b>'+fmtNumber(x.value,2)+' '+x.unit+' · baseline '+fmtNumber(x.baseline,2)+'</b></div>').join('')||'<div class="empty-state"><strong>No actual interval spike has enough comparison history</strong><p>Enter at least seven readings for the same building and time of day before the rule screen can compare later values.</p></div>')+'</section>'
      +'<div class="content-grid section-space"><section class="card"><div class="card-head"><div><div class="eyebrow">LOCAL NLP · NO PROVIDER KEY</div><h2>Complaint themes & suggested teams</h2><p>Classifies existing incident descriptions on this device, groups recurring themes, and ranks open high-priority items.</p></div><span class="data-tag">'+data.incidents.length+' REPORTS</span></div>'+(complaintRows||'<div class="empty-state"><strong>No complaints to classify</strong><p>Staff reports will appear here once entered.</p></div>')+'<div class="trust-note">Lightweight local Naive Bayes classifier trained on generic example phrases; not a hosted LLM. Verify the category and team before assigning or taking action.</div></section><section class="card"><div class="card-head"><div><div class="eyebrow">ENERGY & WATER SOURCES</div><h2>Record real source mix</h2><p>Keep real source records separate from scenarios.</p></div></div><form class="form-grid" data-form="resource-source">'+field('Record date','date','date',dateInput(),'',true)+field('Grid electricity · kWh','gridKwh','number','','',false,'min="0" step="any"')+field('Solar · kWh','solarKwh','number','','',false,'min="0" step="any"')+field('Battery discharge · kWh','batteryKwh','number','','',false,'min="0" step="any"')+field('Municipal water · kL','municipalKl','number','','',false,'min="0" step="any"')+field('Groundwater · kL','groundwaterKl','number','','',false,'min="0" step="any"')+field('Rainwater · kL','rainwaterKl','number','','',false,'min="0" step="any"')+field('Meter / source reference','reference','text','','Optional source note',false)+'<div class="form-actions full-field"><button class="button primary" type="submit">Save actual source mix</button></div></form></section></div>'
      +'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">SYNTHETIC RUNS · CPU ANALYTICS</div><h2>Recent generated scenarios</h2><p>Saved separately from the measured campus history.</p></div></div>'+(data.simulationRuns.slice().reverse().slice(0,5).map(x=>'<div class="metric-line"><span>'+esc(x.name)+' · '+esc(x.season)+' · '+x.rows.length+' generated intervals</span><b>'+esc(fmtDate(x.createdAt))+' · SYNTHETIC</b></div>').join('')||'<div class="empty-state"><strong>No synthetic scenarios created</strong><p>Use the scenario builder above to generate one.</p></div>')+'</section>'
      +'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">ACTUAL SOURCE MIX</div><h2>Recent energy & water-source records</h2><p>Manually supplied measured values; source references retained.</p></div><span class="data-tag">'+data.resourceSources.length+' INPUTS</span></div>'+(data.resourceSources.slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).slice(0,8).map(x=>'<div class="metric-line"><span>'+esc(x.date)+' · '+esc(x.reference||'Measured source mix')+'</span><b>Grid '+sourceValue(x.gridKwh)+' / Solar '+sourceValue(x.solarKwh)+' / Battery '+sourceValue(x.batteryKwh)+' kWh · Water municipal '+sourceValue(x.municipalKl)+' / groundwater '+sourceValue(x.groundwaterKl)+' / rain '+sourceValue(x.rainwaterKl)+' kL</b></div>').join('')||'<div class="empty-state"><strong>No source-mix records yet</strong><p>Enter an actual dated source total above. Blank source types remain unknown, not zero.</p></div>')+'</section>'
      +'<section class="card section-space"><div class="eyebrow">WHAT THIS ADDS / WHAT IT DOES NOT CLAIM</div><p>One university-campus model with building/floor, hourly-period, weekday/weekend and seasonal variation; renewable and water-source breakdown; synthetic fault injection; held-out CPU regression scoring; scenario savings estimates; and offline complaint classification. No sensor connection, real institution names, live weather, or GPU is required.</p><p class="small-note">Local intelligence can run without a model-provider key. The existing secure hosted assistant remains available for evidence-grounded long-form answers after its server configuration is complete.</p></section>';
  }
  function renderHistory() {
    const ready=historyReadiness();
    const monthRows=ready.months.map(m=>'<tr><td><b>'+esc(m.label)+'</b></td><td>'+m.count+' records</td><td>'+categories.length+' required types</td><td>'+(m.missing.length?'<span class=\"missing-text\">Missing: '+esc(m.missing.join(', '))+'</span>':'<span class=\"verified-tag\">COMPLETE</span>')+'</td></tr>').join('');
    const cats=categories.map(c=>'<option value=\"'+esc(c[0])+'\">'+esc(c[1])+'</option>').join('');
    const listed=data.history.slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,20).map(r=>'<tr><td>'+esc(r.date)+'</td><td>'+esc(categoriesById[r.category]||r.category)+'</td><td>'+esc(r.block||'—')+'</td><td>'+esc(r.metric||'—')+'</td><td>'+esc(r.value===''||r.value==null?'—':fmtNumber(r.value,2)+' '+(r.unit||''))+'</td><td>'+esc(r.details)+'</td></tr>').join('');
    return head('DATA INTAKE · INSTITUTION HISTORY','Six-month data setup','Upload or enter institution records. Readiness needs at least one reviewed record for every category in each of the last six completed calendar months.',button('Download blank CSV template','history-template','ghost')+button('Export records','history-export','ghost'))
      +'<section class=\"card history-banner\"><div class=\"history-progress\"><strong>'+Math.round(ready.ratio*100)+'%</strong><span>monthly category coverage</span></div><div><div class=\"eyebrow\">'+(ready.complete?'BROAD HISTORY COMPLETE':'OPTIONAL BROAD HISTORY')+'</div><h2>'+(ready.complete?'Six-month coverage is complete.':'Add history when the actual records are available.')+'</h2><p>The 11-category checklist is useful for whole-campus reporting, but is not a sign-in or app-use requirement. Per-metric trend cards need three distinct months of compatible measured values. No record is generated for you.</p></div></section>'
      +'<div class=\"content-grid\"><section class=\"card\"><div class=\"card-head\"><div><h2>Import CSV history</h2><p>Template columns: date, category, block, metric, value, unit, details, reference. UTF-8 CSV, up to 10 MB.</p></div></div><form class=\"upload-form\" data-form=\"history-import\"><label class=\"file-drop\"><input type=\"file\" name=\"historyFile\" accept=\".csv,text/csv\" required><span>Choose a filled CSV file</span><small>Categories: '+esc(categories.map(x=>x[0]).join(', '))+'</small></label><button class=\"button primary\" type=\"submit\">Validate and import</button></form><div class=\"trust-note\">Import is all-or-nothing: malformed rows or invalid dates are rejected before records are saved. Confirm no-movement and no-event months explicitly in the details column.</div></section><section class=\"card\"><div class=\"card-head\"><div><h2>Add one measured record</h2><p>Manual entry is useful for a missing monthly category.</p></div></div><form class=\"form-grid\" data-form=\"history-record\">'+field('Record date','date','date',dateInput(),'',true)+selectField('Category','category',categories,'electricity')+selectField('Campus block','block',blockOptions(true),'')+field('Metric / instrument','metric','text','','e.g. kWh, meter total, lab inspection',false)+field('Value','value','number','','Numeric when measured',false,'step=\"any\"')+field('Unit','unit','text','','kWh, kL, people, items…',false)+'<label class=\"field full-field\">Details<textarea name=\"details\" rows=\"2\" required placeholder=\"Enter the measured value or explicit monthly review / no-activity confirmation.\"></textarea></label>'+field('Reference','reference','text','','Log book, invoice, register…',false)+'<div class=\"form-actions full-field\"><button class=\"button primary\" type=\"submit\">Save actual record</button></div></form></section></div>'
      +'<section class=\"card section-space\"><div class=\"card-head\"><div><h2>Coverage by month</h2><p>Required categories for the six most recently completed months</p></div><span class=\"data-tag\">'+ready.records+' STORED ROWS</span></div><div class=\"table-wrap\"><table class=\"data-table\"><thead><tr><th>Month</th><th>Rows</th><th>Coverage target</th><th>Status</th></tr></thead><tbody>'+monthRows+'</tbody></table></div></section>'
      +'<section class=\"card section-space\"><div class=\"card-head\"><div><h2>Recent institution records</h2><p>Imported and manually entered records; no sample rows are mixed in.</p></div></div>'+(listed?'<div class=\"table-wrap\"><table class=\"data-table\"><thead><tr><th>Date</th><th>Category</th><th>Block</th><th>Metric</th><th>Value</th><th>Details</th></tr></thead><tbody>'+listed+'</tbody></table></div>':'<div class=\"empty-state\"><strong>No historical records</strong><p>Choose the blank template, fill it with your campus source records, and import it here.</p></div>')+'</section>'
      +'<section class=\"section-space\">'+forecastCards()+'<div class=\"content-grid section-space\">'+actualChartCard('Electricity use','electricity','Measured campus records by month.','#77e7bc')+actualChartCard('Water use','water','Measured campus records by month.','#89b4ff')+'</div></section>';
  }
  function renderCopilot() {
    const feedback=data.assistantFeedback||[];
    const msgs=data.messages.slice(-16).map(m=>{
      if(m.from==='user')return '<article class="copilot-message from-user"><span>YOU</span><p>'+esc(m.text)+(m.fileName?'<small class="attached-file">Attached · '+esc(m.fileName)+'</small>':'')+'</p></article>';
      const fb=feedback.find(x=>x.answerId===m.id)?.value||'',expanded=ui.explainOpen===m.id;
      const why=expanded?'<div class="answer-explanation"><b>Why this answer?</b><p>'+esc(m.sources?.length?'It was grounded in the cited records shown below. The assistant may summarize those records but cannot independently verify that they are accurate or current.':'No matching source record was found; this answer states a data gap or general workflow rule, not a campus-specific fact.')+'</p><b>What data may be missing?</b><p>'+(m.sources?.length?'Current readings, authorized inspection results, context such as weather/occupancy, and records that were never entered.':'A dated institution record, source reference, and relevant campus/block context.')+'</p></div>':'';
      const action=m.proposedAction?.type==='maintenance_ticket'?'<div class="agent-draft"><b>Reviewable work-order draft</b><p>'+esc(m.proposedAction.title||'Preventive follow-up')+'</p><small>'+esc(m.proposedAction.description||'')+'</small><button class="button small" data-action="draft-agent-action" data-id="'+esc(m.id)+'">Review and edit draft ↗</button></div>':'';
      return '<article class="copilot-message" data-message-id="'+esc(m.id)+'"><span>INFRAIQ · '+(cloudSession?'SECURE COPILOT':'EVIDENCE MODE')+'</span><p data-message-text>'+esc(m.text)+'</p>'+(m.sources?.length?'<small>Sources: '+esc(m.sources.join(' · '))+'</small>':'<small class="no-source">No campus source matched this answer.</small>')+action+why+'<div class="answer-controls"><button class="button tiny ghost" data-action="assistant-why" data-id="'+esc(m.id)+'">'+(expanded?'Hide explanation':'Why did INFRAIQ say this?')+'</button><button class="button tiny ghost" data-action="speak-message" data-id="'+esc(m.id)+'">Listen aloud 🔊</button><button class="button tiny '+(fb==='helpful'?'selected':'ghost')+'" data-action="assistant-feedback" data-value="helpful" data-id="'+esc(m.id)+'">Helpful</button><button class="button tiny '+(fb==='incorrect'?'selected':'ghost')+'" data-action="assistant-feedback" data-value="incorrect" data-id="'+esc(m.id)+'">Incorrect</button><button class="button tiny '+(fb==='review'?'selected':'ghost')+'" data-action="assistant-feedback" data-value="review" data-id="'+esc(m.id)+'">Needs review</button></div></article>';
    }).join('');
    const pending=ui.pendingDocument;
    return head('INFRAIQ · GROUNDED WORKSPACE ASSISTANT','Ask about your campus','Use voice, search evidence, attach an operations PDF or image, and request human-reviewable action drafts.',button('Clear conversation','clear-chat','ghost'))
      +'<div class="content-grid copilot-grid"><section class="card chat-card"><div class="chat-log">'+(msgs||'<div class="empty-state"><strong>Ask about a campus report or record</strong><p>Example: “What do we know about the transformer report?”</p></div>')+'</div><form class="chat-form" data-form="question" data-mode="chat"><textarea name="question" rows="2" required placeholder="Ask about incidents, maintenance, history, kitchen, or campus health…"></textarea><div class="chat-tools"><button class="button small ghost" type="button" data-action="voice-input">🎙 Speak</button><button class="button small ghost" type="button" data-action="choose-document" '+(cloudSession?'':'disabled')+'>📄 Attach PDF / image</button><button class="button small ghost" type="button" data-action="search-records">🔍 Search records</button><button class="button small ghost" type="button" data-action="prepare-agent" '+(cloudSession?'':'disabled')+'>⚡ Plan next action</button><input type="file" data-document-input accept="application/pdf,image/jpeg,image/png,image/webp" hidden></div><div class="document-chip" '+(pending?'':'hidden')+'><span>Attached document · <b data-document-name>'+esc(pending?.name||'')+'</b></span><button type="button" class="button tiny ghost" data-action="clear-document" aria-label="Remove attachment">Remove</button></div><div class="chat-send-row"><small>Cloud AI, PDF/image analysis and action planning need authenticated secure hosting.</small><button class="button primary" type="submit">Ask INFRAIQ ↗</button></div></form></section><aside class="card assistant-scope"><div class="eyebrow">EVIDENCE & SAFETY BOUNDARY</div><h2>Answers grounded in campus records</h2><ul><li>Hosted answers search records your authenticated role may access.</li><li>Possible causes are not confirmed diagnoses; safety-critical incidents need qualified on-site inspection.</li><li>Unknown onset and missing records stay explicit.</li><li>Trend baselines are estimates, not guarantees.</li><li>AI action plans prepare drafts; a campus person reviews and saves them.</li></ul><div class="trust-note">Uploaded files are sent for one-time analysis and are not stored by INFRAIQ. Review your AI provider’s data controls before sending sensitive documents.</div></aside></div>';
  }
  function renderEnvironment() {
    const location=[profile.city,profile.region].filter(Boolean).join(', ');
    const alerts=ui.environmentAlerts.map(item=>'<article class="environment-alert '+(item.headline_flag?'headline-flag':'')+'"><div class="environment-alert-top"><span class="data-tag">'+(item.headline_flag?'WARNING WORDING IN HEADLINE':'OFFICIAL ENVIRONMENT UPDATE')+'</span><time>'+esc(fmtDate(item.published_at||item.detected_at,true))+'</time></div><h3>'+esc(item.title)+'</h3>'+(item.summary?'<p>'+esc(item.summary)+'</p>':'')+'<div class="environment-alert-foot"><span>'+esc(item.source_name||'Official source')+' · '+esc(String(item.topic||'environment').replaceAll('_',' '))+'</span><a href="'+esc(item.url)+'" target="_blank" rel="noopener noreferrer">Read the original release ↗</a></div></article>').join('');
    const notificationLabel=(!('Notification'in window))?'Browser alerts unsupported':Notification.permission==='granted'?'Browser alerts enabled':Notification.permission==='denied'?'Allow alerts in browser settings':'Enable browser alerts';
    const feedState=ui.environmentError?'<div class="feed-status feed-error"><span class="live-dot"></span><div><b>'+esc(ui.environmentStatus)+'</b><small>'+esc(ui.environmentError)+'</small></div></div>':'<div class="feed-status"><span class="live-dot"></span><div><b>'+esc(ui.environmentStatus)+'</b><small>'+(ui.environmentLastSync?'Last checked '+esc(fmtDate(ui.environmentLastSync,true)):'No feed check recorded in this session')+'</small></div></div>';
    return head('CAMPUS STEWARDSHIP · OFFICIAL SOURCES','Environment & national news','Official AQI observations, location-aware forecast portals, and a shared environment-headline watch. Open the publisher to verify context before acting.', '')
      +'<section class="card environment-monitor"><div class="environment-monitor-copy"><div class="eyebrow">SHARED OFFICIAL HEADLINE WATCH</div><h2>Updates that reach the whole connected campus</h2><p>INFRAIQ checks the Government of India PIB releases feed every 15 minutes on supported hosting, screens headline text for environment, climate, air-quality, water, and extreme-weather terms, then shares new matches with signed-in campus members.</p><p class="small-note">This is an automated relevance screen, not a confirmation of a local hazard. It does not watch or transcribe live TV/video. Alerts appear in open connected sessions; browser alerts need permission. Review the original source and local advisories.</p>'+feedState+'</div><div class="environment-monitor-actions"><button class="button primary" data-action="refresh-environment-feed">Check official updates ↻</button><button class="button ghost" data-action="enable-environment-notifications">'+esc(notificationLabel)+'</button><span class="data-tag">'+(cloudSession?'SUPABASE SHARED FEED':'SIGN IN FOR SHARED UPDATES')+'</span></div></section>'
      +'<section class="card section-space"><div class="card-head"><div><div class="eyebrow">SCREENED RELEASES · LAST 60 DAYS</div><h2>Environment watch</h2><p>Headline matches from the official PIB feed, newest first. “Warning wording” is a text cue only and is not an official severity rating.</p></div><span class="data-tag">'+ui.environmentAlerts.length+' UPDATES</span></div>'+(alerts||'<div class="empty-state"><strong>No official environment headlines loaded</strong><p>'+(cloudSession?'Run a feed check or apply database migration 006 to activate shared updates. No sample alerts are shown.':'Sign in to a configured campus workspace to load the shared headline feed. No sample alerts are shown.')+'</p></div>')+'</section>'
      +'<div class="content-grid source-grid section-space"><section class="card source-card"><div class="eyebrow">CURRENT AIR QUALITY · CPCB</div><h2>Choose the nearest monitoring station</h2><p>Campus location: <b>'+esc(location||'not entered')+'</b>. These portals show official monitoring-network observations. Compare the station, pollutant, and timestamp with your campus location; a nearby city value is not a campus sensor.</p><a class="button primary" href="https://app.cpcbccr.com/AQIIndia" target="_blank" rel="noopener noreferrer">CPCB · all-India AQI dashboard ↗</a><a class="source-link" href="https://airquality.cpcb.gov.in/AQI_India/" target="_blank" rel="noopener noreferrer">CPCB National AQI station portal ↗</a><a class="source-link" href="https://app.cpcbccr.com/ccr" target="_blank" rel="noopener noreferrer">CPCB Central Control Room ↗</a>'+(location?'<a class="source-link" href="https://www.google.com/maps/search/CPCB+air+quality+monitoring+station+near+'+encodeURIComponent(location)+'" target="_blank" rel="noopener noreferrer">Find monitoring stations near campus ↗</a>':'<small>Add the campus city in Campus Profile to search nearby monitoring stations.</small>')+'</section><section class="card source-card"><div class="eyebrow">OFFICIAL AQI FORECASTS</div><h2>Forecast coverage depends on location</h2><p>Use a forecast portal that covers your region. Do not treat a weather forecast as an AQI forecast.</p><a class="button primary" href="https://safar.tropmet.res.in/" target="_blank" rel="noopener noreferrer">SAFAR · IITM air-quality forecast ↗</a><a class="source-link" href="https://ews.tropmet.res.in/" target="_blank" rel="noopener noreferrer">IITM air-quality early warning · Delhi ↗</a><a class="source-link" href="https://nwp.imd.gov.in/silam_imd.php" target="_blank" rel="noopener noreferrer">IMD air-quality forecast bulletins ↗</a><small>SAFAR coverage includes selected cities; the Delhi early-warning portal is Delhi-specific. Confirm that a forecast is available for your location.</small></section></div>'
      +'<div class="content-grid source-grid"><section class="card source-card"><div class="eyebrow">NATIONAL NEWS CHANNEL</div><h2>DD News · Prasar Bharati</h2><p>Follow the official national broadcaster for live news and published environment stories. INFRAIQ does not ingest or transcribe the video stream.</p><a class="button primary" href="https://www.youtube.com/@DDNewsOfficial/live" target="_blank" rel="noopener noreferrer">Watch DD News live ↗</a><a class="source-link" href="https://ddnews.gov.in/en/tag/environment/" target="_blank" rel="noopener noreferrer">DD News · environment headlines ↗</a><a class="source-link" href="https://www.pib.gov.in/ViewRss.aspx?lang=1&amp;reg=22" target="_blank" rel="noopener noreferrer">PIB official RSS source ↗</a></section><section class="card source-card"><div class="eyebrow">WEATHER & PUBLIC WARNINGS</div><h2>India Meteorological Department</h2><p>Check district warnings and official weather notices alongside the AQI forecast. These warnings cover weather hazards and are distinct from a measured AQI reading.</p><a class="button" href="https://mausam.imd.gov.in/" target="_blank" rel="noopener noreferrer">Open IMD warnings ↗</a><a class="source-link" href="https://mausam.imd.gov.in/" target="_blank" rel="noopener noreferrer">IMD local forecasts & alerts ↗</a></section></div>'
      +'<div class="trust-note section-space">AQI readings and forecasts are linked to official publishers and are not copied into INFRAIQ as campus measurements. The CPCB portal may be intermittently unavailable; use the all-India dashboard or Central Control Room while it recovers.</div>';
  }  function renderAudit() {
    const rows=Array.isArray(ui.audit)?ui.audit:[];
    const body=rows.map(x=>{
      const actor=data.crew.find(m=>m.userId===x.actor_id);
      return '<tr><td>'+fmtDate(x.occurred_at,true)+'</td><td><span class="status-tag">'+esc(x.action)+'</span></td><td>'+esc(x.record_kind)+' · '+esc(x.record_id)+'</td><td>'+esc((x.changed_fields||[]).join(', ')||'record')+'</td><td>'+esc(actor?.name||String(x.actor_id||'System').slice(0,12))+'</td></tr>';
    }).join('');
    return head('GOVERNANCE · AUDIT LOG','Campus change history','Append-only metadata for shared record changes. Sensitive field values are intentionally not copied into this log.')
      +(cloudSession?'<section class="card"><div class="card-head"><div><h2>Recent workspace changes</h2><p>Newest first · up to the latest 100 changes</p></div><span class="data-tag">'+rows.length+' ENTRIES</span></div>'+(rows.length?'<div class="table-wrap"><table class="data-table"><thead><tr><th>Time</th><th>Action</th><th>Record</th><th>Fields</th><th>Changed by</th></tr></thead><tbody>'+body+'</tbody></table></div>':'<div class="empty-state"><strong>No shared changes recorded yet</strong><p>New inserts, updates and deletes in the Supabase workspace will appear here.</p></div>')+'</section>':'<section class="card empty-state"><strong>Shared audit history needs Supabase</strong><p>The local demo does not claim to be an append-only audit system. Configure Supabase to record and review shared workspace changes.</p></section>');
  }
  function renderCloudSignup() {
    const shellStart='<main class="signup-shell"><section class="signup-art"><a class="brand" href="about.html">INFRA<span>IQ</span></a><div class="eyebrow">SHARED CAMPUS OPERATIONS · SECURE ACCESS</div><h1>Every campus fact,<br><em>from your own team.</em></h1><p>Separate staff accounts, role-based panels, live incident delivery, institution records, and an evidence-bound Copilot.</p><div class="signup-mark">IQ</div></section><section class="signup-panel"><div class="signup-card">';
    const shellEnd='</div></section></main>';
    if(ui.resetPassword)return shellStart+'<div class="eyebrow">ACCOUNT SECURITY</div><h2>Set a new password</h2><p>Choose a new password for your Supabase account.</p><form data-form="cloud-password">'+field('New password','password','password','','At least 10 characters',true,'minlength="10" autocomplete="new-password"')+field('Confirm password','confirmPassword','password','','Re-enter your password',true,'minlength="10" autocomplete="new-password"')+'<button class="button primary full-button" type="submit">Update password</button></form>'+shellEnd;
    if(ui.confirmationPending) return shellStart+'<div class="eyebrow">EMAIL CONFIRMATION</div><h2>Check your inbox</h2><p>Confirm '+esc(profile.email)+' with Supabase Auth, then return here. Your campus setup stays available in this browser while you complete verification.</p><div class="trust-note">After confirmation, INFRAIQ will continue with the invitation or campus setup. Email confirmation is controlled by your Supabase project’s Auth settings.</div><button class="button primary full-button" data-action="cloud-login">Continue to sign in ↗</button>'+shellEnd;
    if(ui.signupStep==='campus'&&cloudSession) {
      const form='<form class="form-grid" data-form="cloud-campus">'+field('College / institution','collegeName','text',profile.collegeName,'Institution name',true)+field('City','city','text',profile.city,'City',true)+field('State / region','region','text',profile.region,'State / region',true)+field('Campus address','address','text',profile.address,'Optional',false)+field('Campus size · m²','campusSize','number',profile.campusSize,'Optional',false,'min="0" step="any"')+field('Number of blocks','blockCount','number',profile.blockCount,'Optional; add exact profiles after setup',false,'min="0" step="1"')+field('Campus opens','opening','time',profile.opening||'08:00','',false)+field('Campus closes','closing','time',profile.closing||'18:00','',false)+field('Invitation code · if a campus administrator invited you','inviteCode','text',ui.inviteCode,'Optional for a new institution owner',false,'autocomplete="one-time-code"')+'<div class="form-actions full-field"><button class="button primary" type="submit">Continue to INFRAIQ ↗</button></div></form>';
      return shellStart+'<div class="eyebrow">CAMPUS PROFILE · 02 / 02</div><h2>Join or create a campus</h2><p>Enter a campus invitation code to join the existing institution with its assigned role. Leave it blank only if you are creating a new campus workspace as its first administrator.</p>'+form+(ui.error?'<p class="form-error">'+esc(ui.error)+'</p>':'')+'<div class="trust-note">Block counts, student/staff occupancy, labs, and instruments remain optional actual data. No values are guessed for missing fields.</div>'+shellEnd;
    }
    const login=ui.authMode==='login';
    const form='<form data-form="cloud-auth"><div class="eyebrow">'+(login?'SUPABASE AUTH · SIGN IN':'SUPABASE AUTH · CREATE ACCOUNT')+'</div><h2>'+(login?'Welcome back':'Create your account')+'</h2><p>'+(login?'Sign in to load your institution workspace and role.':'Use your work email. The first person creating a campus becomes its administrator; invited crew join using their invitation code.')+'</p>'
      +(login?'':field('Your name','personName','text',profile.personName,'Full name',true))
      +field('Work email','email','email',profile.email,'name@college.edu',true)
      +field('Password','password','password','','At least 10 characters',true,'minlength="10" autocomplete="'+(login?'current-password':'new-password')+'"')
      +(login?'':field('Campus invitation code · optional','inviteCode','text',ui.inviteCode,'Enter the code your administrator shared',false,'autocomplete="one-time-code"'))
      +(ui.error?'<p class="form-error">'+esc(ui.error)+'</p>':'')
      +'<button class="button primary full-button" type="submit">'+(login?'Sign in securely ↗':'Create secure account ↗')+'</button></form>'
      +'<button class="button ghost full-button" data-action="toggle-cloud-auth">'+(login?'Create a new account':'I already have an account')+'</button>'
      +'<div class="trust-note">'+(cloudSession?'Authenticated with Supabase.':'Shared accounts require a configured Supabase project. Passwords are handled by Supabase Auth, not stored by INFRAIQ.')+' If no Supabase settings are configured, the existing local demo is available below.</div>'
      +'<button class="button small ghost full-button" data-action="use-local-demo">Open local demo workspace</button>';
    return shellStart+form+(login?'<button class="button small ghost full-button" data-action="reset-password">Forgot password?</button>':'')+shellEnd;
  }
  function renderSignup() {
    if(cloudConfigured&&!ui.forceLocal)return renderCloudSignup();
    if (!profile.completed) {
      if (ui.signupStep === 'campus') return '<main class=\"signup-shell\"><section class=\"signup-art\"><a class=\"brand\" href=\"about.html\">INFRA<span>IQ</span></a><div class=\"eyebrow\">CAMPUS OPERATIONS · INTELLIGENCE</div><h1>Every campus fact,<br><em>from your own team.</em></h1><p>Build an operating picture from staff reports, verified records, kitchen entries and institution history.</p><div class=\"signup-mark\">IQ</div></section><section class=\"signup-panel\"><form class=\"signup-card\" data-form=\"signup-campus\"><div class=\"eyebrow\">CAMPUS PROFILE · 02 / 02</div><h2>Set up your institution</h2><p>Block occupancy and campus size are optional. No values will be guessed for blank fields.</p><div class=\"form-grid\">'+field('College / institution','collegeName','text',profile.collegeName,'Institution name',true)+field('City','city','text',profile.city,'City',true)+field('State / region','region','text',profile.region,'State / region',true)+field('Your position','role','text',profile.role,'',false).replace('<input','<select').replace('type=\"text\"','').replace('value=\"'+esc(profile.role)+'\"','').replace('></label>','>'+Object.entries(roles).map(x=>'<option value=\"'+x[0]+'\" '+(x[0]===profile.role?'selected':'')+'>'+esc(x[1].label)+'</option>').join('')+'</select></label>')+field('Campus address','address','text',profile.address,'Optional',false)+field('Number of blocks','blockCount','number',profile.blockCount,'Optional',false,'min=\"0\" step=\"1\"')+field('Campus area · m²','campusSize','number',profile.campusSize,'Optional',false,'min=\"0\" step=\"any\"')+field('Usual opening','opening','time',profile.opening||'08:00','',false)+field('Usual closing','closing','time',profile.closing||'18:00','',false)+'</div><div class=\"form-actions\"><button class=\"button\" type=\"button\" data-action=\"signup-back\">Back</button><button class=\"button primary\" type=\"submit\">Create local workspace ↗</button></div><div class=\"trust-note\">This demo stores identity and records in this browser. No password or shared server account is created.</div></form></section></main>';
      return '<main class=\"signup-shell\"><section class=\"signup-art\"><a class=\"brand\" href=\"about.html\">INFRA<span>IQ</span></a><div class=\"eyebrow\">CAMPUS OPERATIONS · INTELLIGENCE</div><h1>Every campus fact,<br><em>from your own team.</em></h1><p>Report an incident from any block. Give the administrator a structured response workflow without losing time walking across campus.</p><div class=\"signup-mark\">IQ</div></section><section class=\"signup-panel\"><form class=\"signup-card\" data-form=\"signup-identity\"><div class=\"eyebrow\">WELCOME · 01 / 02</div><h2>'+(profile.email?'Sign in to this browser':'Create your workspace')+'</h2><p>'+(profile.email?'Continue with the email saved for this local campus.':'Start with your name and institutional email.')+'</p>'+field('Your name','personName','text',profile.personName,'Full name',true)+field('Work email','email','email',profile.email,'name@college.edu',true)+(ui.error?'<p class=\"form-error\">'+esc(ui.error)+'</p>':'')+'<button class=\"button primary full-button\" type=\"submit\">Continue to campus setup ↗</button><div class=\"trust-note\">Local demo sign-in only. Multi-user accounts and notifications across devices need a secured backend.</div></form></section></main>';
    }
    return '<main class=\"signup-shell\"><section class=\"signup-art\"><a class=\"brand\" href=\"about.html\">INFRA<span>IQ</span></a><div class=\"eyebrow\">CAMPUS OPERATIONS · INTELLIGENCE</div><h1>Every campus fact,<br><em>from your own team.</em></h1><p>Enter your local INFRAIQ workspace.</p><div class=\"signup-mark\">IQ</div></section><section class=\"signup-panel\"><form class=\"signup-card\" data-form=\"login\"><div class=\"eyebrow\">LOCAL WORKSPACE SIGN-IN</div><h2>Welcome back'+(profile.personName?', '+esc(profile.personName.split(' ')[0]):'')+'</h2><p>Confirm the email associated with this browser profile.</p>'+field('Work email','email','email',profile.email,'name@college.edu',true)+(ui.error?'<p class=\"form-error\">'+esc(ui.error)+'</p>':'')+'<button class=\"button primary full-button\" type=\"submit\">Continue ↗</button><button class=\"button ghost full-button\" type=\"button\" data-action=\"edit-campus\">Edit campus profile</button><div class=\"trust-note\">This local sign-in does not verify identity or protect data with a password.</div></form></section></main>';
  }
  const pageDescriptions={command:'Campus operations overview for team-reported activity and measured records.',maintenance:'Review campus maintenance work orders and preventive equipment schedules.',health:'Evidence-grounded campus health report with recorded cues, gaps, and human-reviewed next steps.',staff:'Campus staff shifts, rapid reports, and block-level incident updates.',incidents:'Review, triage, assign, and track campus incident reports.',crew:'Campus roles, completed shifts, verified reports, and recognition.',kitchen:'Daily campus menus, food production, meals served, and measured waste.',equipment:'Campus asset register and actual preventive-maintenance dates.',campus:'Institution profile, buildings, location, occupancy, and operating hours.',history:'Optional six-month history, actual records, coverage, and measured trends.',intelligence:'Building and floor resource scenarios, manual readings, anomaly review, and source mix.',audit:'Campus record-change metadata for authorized administrators.',copilot:'INFRAIQ assistant for role-permitted campus records and reviewed recommendations.',environment:'Official India environmental and national-news sources.'};
  function updatePageMetadata(view) {
    const title=view==='command'?'Campus workspace':(nav.find(n=>n[0]===view)?.[1]||'Campus workspace');document.title=title+' | INFRAIQ';
    const description=document.querySelector('meta[name="description"]');if(description)description.content=pageDescriptions[view]||'INFRAIQ campus operations workspace.';
    const robots=document.querySelector('meta[name="robots"]');if(robots)robots.content='noindex,nofollow';
  }
  function appendPublicFooter() {
    const links=document.createElement('nav');links.className='public-footer';links.setAttribute('aria-label','Public information');links.innerHTML='<a href="about.html">About INFRAIQ</a><a href="faq.html">FAQ · draft</a><a href="privacy.html">Privacy · draft</a>'+(window.INFRAIQ_GA4_ID?'<button class="site-cookie-settings" type="button" data-consent-settings>Cookie settings</button>':'');ROOT.append(links);
  }
  function installFormHoneypots() {
    ROOT.querySelectorAll('form[data-form]').forEach(form=>{if(form.querySelector('[data-honeypot]'))return;const trap=document.createElement('div');trap.className='form-honeypot';trap.setAttribute('aria-hidden','true');trap.innerHTML='<label>Leave blank<input type="text" name="website_url" tabindex="-1" autocomplete="off"></label>';form.append(trap);});
  }
  function render() {
    if (!profile.completed || !profile.signedIn) {
      ROOT.innerHTML=renderSignup();
      addSignInStewardshipQuote();
      const showcaseButton=document.createElement('button');showcaseButton.type='button';showcaseButton.className='button ghost full-button showcase-launcher';
      showcaseButton.dataset.action=SHOWCASE_MODE?'exit-showcase':'open-showcase';showcaseButton.textContent=SHOWCASE_MODE?'Exit fictional showcase':'Preview the fictional demo campus';
      ROOT.querySelector('.signup-panel')?.append(showcaseButton);
      appendPublicFooter();installFormHoneypots();updatePageMetadata('login');return;
    }
    if(!profile.aiStartChoice){ROOT.innerHTML=renderAiStartChoice();addSignInStewardshipQuote();appendPublicFooter();updatePageMetadata('login');document.title='Choose Your Data Setup | INFRAIQ';return;}
    if (!rolePages[profile.role]) profile.role='admin';
    const available=navForRole();
    if (!available.some(x=>x[0]===ui.page)) ui.page='command';
    let page=({
      command:renderOverview, maintenance:renderMaintenance, health:renderHealth, staff:renderStaff, incidents:renderIncidents, crew:renderCrew,
      kitchen:renderKitchen, equipment:renderEquipment, campus:renderCampus, history:renderHistory, intelligence:renderIntelligence, audit:renderAudit, copilot:renderCopilot, environment:renderEnvironment
    })[ui.page]();
    if(cloudSession) {
      page=page.replaceAll('Reports are stored locally and appear in the administrator queue on this shared browser. Do not rely on this front-end demo for cross-device emergency dispatch.','Reports are saved to the shared campus database. Connected administrators receive the report live; enable browser alerts and keep this workspace online. Emergency response still follows your campus plan and local emergency services.')
        .replaceAll('Urgent reports are added immediately to the administrator’s open queue in this workspace.','Urgent reports are committed to the shared campus database and appear on connected administrator dashboards immediately.')
        .replaceAll('The current website stores data in this browser. Separate-device delivery, identity verification, and off-screen push alerts require a hosted shared backend.','This account is authenticated by Supabase. Shift records and incident delivery sync to the shared campus workspace.')
        .replaceAll('Campus administration and kitchen users share this browser workspace.','Campus administration and kitchen users share the Supabase institution workspace.')
        .replaceAll('Institution-entered register · local workspace','Institution-entered register · shared campus database')
        .replaceAll('Add to crew','Create secure invite')
        .replaceAll('XP is a recognition feature in this local demo, not payroll, formal evaluation, or a substitute for supervisor review.','Verified incident reports earn 10 XP once. XP recognizes validated reporting; it is not payroll or formal employment evaluation.')
        .replaceAll('Answers use institution records in this browser only.','Answers use institution records permitted for your authenticated role.')
        .replaceAll('This front-end has no hosted LLM. A production AI needs a secured backend, source permissions, audit logs and institution data governance.','The Vercel Node route streams answers grounded in role-permitted Supabase records. Provider keys stay server-side; AI advice and action drafts remain subject to campus review.')
        .replaceAll('stored locally and appear in the administrator queue','saved to Supabase and appear in the administrator queue');
      if(ui.page==='incidents'&&'Notification'in window&&Notification.permission!=='granted')page+='<section class="card section-space notification-setup"><div><b>Urgent report alerts</b><p>Enable browser notifications to see high-priority reports while this authenticated campus workspace is open.</p></div><button class="button small" data-action="enable-notifications">'+(Notification.permission==='denied'?'Review browser notification settings':'Enable notifications')+'</button></section>';
      if(ui.page==='crew') {
        if(ui.inviteResult)page+='<section class="card invite-result section-space"><div class="eyebrow">SECURE CREW INVITE · EXPIRES '+esc(fmtDate(ui.inviteResult.expires_at,true))+'</div><h2>Share this one-time campus code</h2><p>Send it privately to '+esc(ui.inviteResult.email)+' using your normal trusted channel. The code is tied to that email and expires automatically.</p><code>'+esc(ui.inviteResult.code)+'</code><button class="button small" data-action="copy-invite" data-code="'+esc(ui.inviteResult.code)+'">Copy invite code</button></section>';
        if(ui.invites?.length)page+='<section class="card section-space"><div class="card-head"><div><h2>Pending crew invitations</h2><p>Unused invitation codes are not shown again after creation.</p></div><span class="data-tag">'+ui.invites.length+' PENDING</span></div><div class="invite-list">'+ui.invites.map(x=>'<div class="metric-line"><span>'+esc(x.invited_name||x.invited_email)+' · '+esc(x.invited_email)+' · '+esc(roles[x.invited_role]?.label||x.invited_role)+(x.block?' · '+esc(x.block):'')+'</span><b>Expires '+esc(fmtDate(x.expires_at))+'</b></div>').join('')+'</div></section>';
      }
    }
    const roleOptions=Object.entries(roles).map(x=>'<option value=\"'+x[0]+'\" '+(x[0]===profile.role?'selected':'')+'>'+esc(x[1].label)+'</option>').join('');
    ROOT.innerHTML='<div class=\"app-shell\"><header class=\"topbar\"><a class=\"brand\" href=\"about.html\" data-action=\"go\" data-page=\"command\">INFRA<span>IQ</span></a><div class=\"top-campus\"><b>'+esc(profile.collegeName||'Institution workspace')+'</b><small>'+esc([profile.city,profile.region].filter(Boolean).join(' · '))+'</small></div><span class=\"top-spacer\"></span><span class=\"role-caption\">'+esc(profile.personName||'Workspace member')+'</span><label class=\"role-control\"><span>Preview role · local</span><select id=\"role-picker\" aria-label=\"Preview role · local preview\">'+roleOptions+'</select></label><button class=\"button small ghost\" data-action=\"sign-out\">Sign out</button></header><div class=\"app-layout\"><aside class=\"sidebar\"><div class=\"sidebar-campus\"><span class=\"campus-mark\">IQ</span><div><b>'+esc(profile.collegeName||'Campus')+'</b><small>'+esc(currentRole().label)+'</small></div></div><div class=\"nav-kicker\">YOUR WORKSPACE</div><nav>'+available.map(n=>'<button class=\"nav-link '+(ui.page===n[0]?'active':'')+'\" data-action=\"go\" data-page=\"'+n[0]+'\"><span>'+n[2]+'</span>'+esc(n[1])+(n[0]==='incidents'&&unresolvedCount()?'<i>'+unresolvedCount()+'</i>':'')+'</button>').join('')+'</nav><div class=\"sidebar-bottom\"><div class=\"offline-card\"><span class=\"live-dot\"></span><div><b>LOCAL CAMPUS WORKSPACE</b><small>Records stay in this browser</small></div></div><button class=\"button small ghost\" data-action=\"go\" data-page=\"history\">'+(historyReadiness().complete?'History ready':'Add optional history')+'</button><small class=\"sidebar-disclaimer\">Role switching previews panels; it does not authenticate this user.</small></div></aside><main class=\"main-content\">'+page+'<footer>INFRAIQ shows records supplied by your team. Incident causes require on-site confirmation. History trends need enough compatible records for that metric; synthetic scenario data is never a real campus reading.</footer></main></div><div class=\"toast\" id=\"toast\" role=\"status\" aria-live=\"polite\"></div></div>';
    updateEnvironmentAlertBadge();
    if(ui.focusAssetId){const focusId=ui.focusAssetId;ui.focusAssetId='';window.setTimeout(()=>{const row=document.getElementById('asset-row-'+CSS.escape(focusId));row?.scrollIntoView({behavior:'smooth',block:'center'});row?.classList.add('asset-row-focused');},60);}
    if(SHOWCASE_MODE){const badge=document.createElement('div');badge.className='showcase-topbar-tag';badge.innerHTML='<span>FICTIONAL SHOWCASE DATA</span><button class=\"button tiny ghost\" data-action=\"exit-showcase\">Exit demo</button>';ROOT.querySelector('.topbar')?.append(badge);}
    if(cloudSession) {
      const preview=ROOT.querySelector('.role-control');
      if(preview){const roleBadge=document.createElement('span');roleBadge.className='role-caption role-secure';roleBadge.textContent=currentRole().label+' · verified role';preview.replaceWith(roleBadge);}
      const connection=ROOT.querySelector('.offline-card');
      if(connection){connection.classList.add('cloud-online');connection.querySelector('b').textContent='SHARED CAMPUS WORKSPACE';connection.querySelector('small').textContent='Supabase · '+(ui.cloudState==='syncing'?'syncing…':ui.cloudState==='error'?'sync needs attention':'connected');}
      const note=ROOT.querySelector('.sidebar-disclaimer');if(note)note.textContent='Access is authenticated; role permissions are enforced by the database.';
    }
    appendPublicFooter();installFormHoneypots();updatePageMetadata(ui.page);
    startClockDisplay();
  }
  function startClockDisplay() {
    if (ui.clockInterval) return;
    ui.clockInterval=window.setInterval(()=>{
      const now=Date.now();
      const active=activeShiftFor();
      if(active&&active.sessionId===ui.sessionId&&document.visibilityState==='visible') {
        active.elapsedMs=(Number(active.elapsedMs)||0)+Math.min(45000,Math.max(0,now-ui.lastTick));
        try{localStorage.setItem(DATA_KEY,JSON.stringify(data));}catch{}
      }
      ui.lastTick=now;
      const target=document.getElementById('shift-clock');
      if (target) target.textContent=shiftTimeLabel();
      document.querySelectorAll('[data-reported-at]').forEach(el=>{el.textContent=Math.max(0,Math.floor((now-Number(el.dataset.reportedAt))/60000))+' min ago';});
      document.querySelectorAll('[data-response-deadline]').forEach(el=>{
        if(el.dataset.responseDone==='true'||!el.dataset.responseDeadline)return;
        const remain=Math.ceil((Number(el.dataset.responseDeadline)-now)/60000);
        el.textContent=remain>0?remain+' min remaining · '+new Intl.DateTimeFormat('en-IN',{hour:'2-digit',minute:'2-digit'}).format(Number(el.dataset.responseDeadline)):'OVERDUE · '+fmtDate(new Date(Number(el.dataset.responseDeadline)),true);
      });
    },30000);
  }
  function go(page) {
    const allowed=rolePages[profile.role]||rolePages.admin;
    if (!allowed.includes(page)) { toast('This panel is not included in the selected workspace role.'); return; }
    ui.page=page;if(page==='environment')markEnvironmentAlertsRead();render();
  }
  async function submitIncident(form) {
    const fd=new FormData(form), description=String(fd.get('description')||'').trim();
    if (!description) return;
    const category=String(fd.get('category')||'other'), observedAt=String(fd.get('observedAt')||new Date().toISOString());
    const item={id:id('incident'),title:String(fd.get('title')||'Campus issue').trim(),category,categoryLabel:form.querySelector('[name=\"category\"] option:checked')?.textContent||category,
      block:String(fd.get('block')||ui.reportBlock||''),severity:String(fd.get('severity')||'Normal'),description,
      actionTaken:String(fd.get('actionTaken')||'').trim(),observedAt,startedAt:String(fd.get('startedAt')||''),expectedMinutes:Math.max(0,Number(fd.get('expectedMinutes'))||0),createdAt:new Date().toISOString(),
      reporterEmail:personKey(),status:'Submitted',verified:false};
    item.triage=incidentTriage(item);
    const evidenceFile=form.querySelector('[name=\"incidentEvidence\"]')?.files?.[0];
    if(evidenceFile){
      const allowed=new Set(['image/jpeg','image/png','image/webp','image/heic','image/heif','application/pdf']).has(evidenceFile.type);
      if(!allowed||evidenceFile.size>8*1024*1024)item.attachmentIssue='Evidence must be an allowed image or PDF up to 8 MB.';
      else if(cloudSession&&profile.institutionId){
        const safeName=String(evidenceFile.name||'evidence').replace(/[^a-zA-Z0-9._-]/g,'_').slice(-100),path=profile.institutionId+'/'+item.id+'/'+id('evidence')+'_'+safeName;
        try{
          const {error}=await cloudClient.storage.from('infraiq-evidence').upload(path,evidenceFile,{cacheControl:'3600',upsert:false,contentType:evidenceFile.type});
          if(!error){item.evidencePath=path;item.evidenceName=evidenceFile.name;item.evidenceType=evidenceFile.type;}
          else item.attachmentIssue='Secure upload failed; the report was still sent.';
        }catch{item.attachmentIssue='Secure upload failed; the report was still sent.';}
      } else item.attachmentIssue='Secure shared file storage is not configured; the report was still sent.';
    }
    data.incidents.unshift(item);
    data.messages.unshift({from:'system',text:'New ' + item.severity.toLowerCase() + ' report from ' + reporterName(item.reporterEmail) + ': ' + item.title,createdAt:item.createdAt,incidentId:item.id});
    ui.reportBlock='';save();ui.page='incidents';render();
    const synced=cloudSession?await queueCloudSync():true;
    render();
    toast((!synced?'Report saved on this device, but could not reach the shared campus desk. Retry after reconnecting.':item.severity==='Urgent'?'URGENT REPORT SENT TO THE SHARED INCIDENT DESK':'Incident report sent to the campus desk.')+(item.attachmentIssue?' Attachment note: '+item.attachmentIssue:''));
  }
  function startShift() {
    if (activeShiftFor()) { toast('Your shift is already running.'); return; }
    ui.lastTick=Date.now();
    data.activeShift={id:id('shift'),email:personKey(),name:profile.personName,startedAt:new Date().toISOString(),elapsedMs:0,sessionId:ui.sessionId,block:currentMember()?.block||''};
    data.activeShifts.push(data.activeShift);
    save();render();toast('Shift clock started.');
  }
  async function endShift() {
    const active=activeShiftFor();if(!active) { toast('No active shift is running for this user.'); return; }
    const endedAt=new Date().toISOString();
    let elapsed=Math.max(Number(active.elapsedMs)||0,Date.now()-new Date(active.startedAt).getTime());
    if(active.sessionId===ui.sessionId&&document.visibilityState==='visible')elapsed=Math.max(Number(active.elapsedMs)||0,elapsed);
    const hours=elapsed/3600000;
    const shiftId=active.id;
    data.shifts.unshift({id:shiftId,email:personKey(),name:profile.personName,startedAt:active.startedAt,endedAt,hours:Math.max(0,hours),block:active.block});
    data.activeShifts=data.activeShifts.filter(x=>x.id!==shiftId);data.activeShift=null;save();render();
    if(cloudSession) {
      const synced=await queueCloudSync();
      if(!synced){toast('Shift ended on this device, but the shared timesheet did not sync. Reconnect and review with a campus leader.');return;}
      await loadCloudWorkspace(true);
      const saved=data.shifts.find(x=>x.id===shiftId);
      render();toast('Shift ended · '+fmtNumber(saved?.hours??hours,2)+' hours recorded by the shared campus clock.');return;
    }
    toast('Shift ended · '+fmtNumber(hours,2)+' hours recorded.');
  }
  async function verifyReport(reportId) {
    const item=data.incidents.find(x=>x.id===reportId);
    if (!item || item.verified || !isLeader()) return;
    if(cloudSession) {
      const {error}=await cloudClient.rpc('verify_infraiq_report',{p_institution_id:profile.institutionId,p_record_id:String(reportId)});
      if(error){toast('The database could not verify this report: '+error.message);return;}
      await loadCloudWorkspace(true);render();toast('Report verified. XP recorded in the campus ledger.');return;
    }
    item.verified=true;item.verifiedAt=new Date().toISOString();item.verifiedBy=personKey();
    const member=memberFor(item.reporterEmail);
    if (member) member.xp=(Number(member.xp)||0)+10;
    save();render();toast('Report verified. '+(member?'10 XP awarded to '+member.name+'.':'Reporter is not in the crew roster.'));
  }
  async function submitCrew(form) {
    if (!isLeader()) { toast('Only an administrator or dean can add crew members.'); return; }
    const fd=new FormData(form),email=String(fd.get('email')||'').trim().toLowerCase();
    if (data.crew.some(x=>String(x.email).toLowerCase()===email)) { toast('That email is already in the crew roster.'); return; }
    if(cloudSession) {
      const {data:invite,error}=await cloudClient.rpc('create_infraiq_invite',{p_email:email,p_name:String(fd.get('name')||'').trim(),p_role:String(fd.get('role')||'worker'),p_block:String(fd.get('block')||'')});
      if(error){toast('Could not create the invitation: '+error.message);return;}
      ui.inviteResult=invite;await loadCloudWorkspace(true);render();toast('Secure invitation created. Share its code privately with the invited crew member.');return;
    }
    data.crew.push({id:id('crew'),name:String(fd.get('name')||'').trim(),email,role:String(fd.get('role')||'worker'),block:String(fd.get('block')||''),xp:0,joinedAt:new Date().toISOString()});
    save();render();toast('Crew member added to this local workspace.');
  }
  function submitKitchen(form) {
    const fd=new FormData(form),date=String(fd.get('date')),prepared=Number(fd.get('preparedKg')),waste=Number(fd.get('wasteKg')),meals=Number(fd.get('meals'));
    if(!date||date>dateInput()){toast('Kitchen quantities must be entered after the service date, not projected in advance.');return;}
    if (![prepared,waste,meals].every(Number.isFinite)||prepared<0||waste<0||meals<0||waste>prepared) { toast('Check the measured quantities. Waste cannot exceed food prepared.'); return; }
    const weekday=new Intl.DateTimeFormat('en-IN',{weekday:'long'}).format(new Date(date+'T12:00:00'));
    const entry={id:id('kitchen'),date,weekday,menu:String(fd.get('menu')||'').trim(),preparedKg:prepared,wasteKg:waste,meals,note:String(fd.get('note')||'').trim(),createdBy:personKey(),updatedAt:new Date().toISOString()};
    const existing=data.kitchen.findIndex(x=>x.date===date);
    if (existing>=0) data.kitchen[existing]=entry; else data.kitchen.push(entry);
    save();render();toast('Kitchen record saved using the entered quantities.');
  }
  async function submitMaintenance(form) {
    const fd=new FormData(form),asset=data.equipment.find(x=>x.id===String(fd.get('assetId')||'')),dueDate=String(fd.get('dueDate')||'');
    if(dueDate&&!validDateOnly(dueDate)){toast('Enter a valid work order due date.');return;}
    const assignedTo=String(fd.get('assignedTo')||'').trim().toLowerCase();
    if(assignedTo&&!data.crew.some(x=>String(x.email||'').toLowerCase()===assignedTo)){toast('Choose a technician in this campus crew.');return;}
    const ticket={id:id('ticket'),title:String(fd.get('title')||'').trim(),assetId:asset?.id||'',assetName:asset?.name||'',block:String(fd.get('block')||asset?.block||''),priority:String(fd.get('priority')||'Normal'),status:'Open',dueDate,assignedTo,description:String(fd.get('description')||'').trim(),createdBy:personKey(),createdAt:new Date().toISOString()};
    data.maintenance.unshift(ticket);ui.maintenanceDraft=null;save();render();
    const synced=cloudSession?await queueCloudSync():true;
    render();toast(synced?'Maintenance work order created.': 'Work order saved here, but Supabase could not sync it.');
  }
  function submitBlock(form) {
    const fd=new FormData(form),name=String(fd.get('name')||'').trim();
    if (!name) return;
    if (data.blocks.some(x=>x.name.toLowerCase()===name.toLowerCase())) { toast('A block with that name already exists.'); return; }
    data.blocks.push({id:id('block'),name,area:String(fd.get('area')||''),students:String(fd.get('students')||''),faculty:String(fd.get('faculty')||''),workers:String(fd.get('workers')||''),labs:String(fd.get('labs')||''),instruments:String(fd.get('instruments')||''),opening:String(fd.get('opening')||''),closing:String(fd.get('closing')||'')});
    save();render();toast('Campus block added.');
  }
  async function saveCampus(form) {
    const fd=new FormData(form);
      for (const key of ['collegeName','city','region','address','latitude','longitude','campusSize','blockCount','opening','closing','mapsKey','electricityTariff','alertThresholdPct']) profile[key]=String(fd.get(key)||'').trim();
    persistLocal();
    if(cloudSession&&profile.institutionId) {
      const numeric=v=>String(v||'').trim()===''?null:Number(v);
      const {error}=await cloudClient.from('institutions').update({name:profile.collegeName,city:profile.city,region:profile.region,address:profile.address,latitude:numeric(profile.latitude),longitude:numeric(profile.longitude),campus_size:numeric(profile.campusSize),block_count:numeric(profile.blockCount),opening:profile.opening||null,closing:profile.closing||null,electricity_tariff:numeric(profile.electricityTariff),usage_alert_threshold_pct:Math.max(5,Math.min(200,Number(profile.alertThresholdPct)||25))}).eq('id',profile.institutionId);
      if(error){ui.cloudState='error';toast('Campus details are local only: '+error.message);}else{ui.cloudState='connected';toast('Campus profile saved to the shared workspace.');}
    } else toast('Campus profile saved in this browser.');
    render();
  }
  function parseCsv(text) {
    const rows=[];let row=[],cell='',quoted=false;
    for (let i=0;i<text.length;i++) {
      const ch=text[i];
      if (quoted) {
        if (ch==='\"'&&text[i+1]==='\"') { cell+='\"'; i++; }
        else if (ch==='\"') quoted=false;
        else cell+=ch;
      } else if (ch==='\"') quoted=true;
      else if (ch===',') { row.push(cell);cell=''; }
      else if (ch==='\n') { row.push(cell.replace(/\r$/,''));rows.push(row);row=[];cell=''; }
      else cell+=ch;
    }
    if (quoted) throw new Error('The CSV ends inside a quoted cell. Check the file and try again.');
    if (cell.length||row.length) { row.push(cell.replace(/\r$/,''));rows.push(row); }
    return rows.filter(r=>r.some(v=>String(v).trim()!==''));
  }
  async function importHistory(form) {
    const file=form.querySelector('[name=\"historyFile\"]')?.files?.[0];
    if (!file) { toast('Choose a CSV file to import.'); return; }
    if (file.size>10*1024*1024) { toast('CSV must be smaller than 10 MB.'); return; }
    try {
      const rows=parseCsv(await file.text());
      if (!rows.length) throw new Error('The CSV is empty.');
      const header=rows[0].map(x=>x.trim().toLowerCase());
      header[0]=header[0].replace(/^\uFEFF/,'');
      const required=['date','category','block','metric','value','unit','details','reference'];
      const indexes={};required.forEach(k=>indexes[k]=header.indexOf(k));
      const missing=required.filter(k=>indexes[k]<0);
      if (missing.length) throw new Error('CSV is missing columns: '+missing.join(', ')+'. Download the INFRAIQ template.');
      const allowed=new Set(categories.map(x=>x[0]));
      const imported=[];
      for (let i=1;i<rows.length;i++) {
        const raw=rows[i], get=k=>String(raw[indexes[k]]??'').trim();
        const date=get('date'),category=get('category').toLowerCase(),valueText=get('value'),details=get('details');
        if (!validDateOnly(date)) throw new Error('Row '+(i+1)+': date must be a real date in YYYY-MM-DD format.');
        if (date>dateInput()) throw new Error('Row '+(i+1)+': future dates are not accepted for historical records.');
        if (!allowed.has(category)) throw new Error('Row '+(i+1)+': unknown category \"'+category+'\".');
        if (!details) throw new Error('Row '+(i+1)+': add measured details or an explicit no-activity review.');
        let value=null;
        if (valueText!=='') { value=Number(valueText); if (!Number.isFinite(value)||value<0) throw new Error('Row '+(i+1)+': values must be non-negative numbers.'); }
        if (numericCategories.has(category)&&value===null) throw new Error('Row '+(i+1)+': '+category+' requires a numeric measured value; use 0 with a no-activity note if there was no activity.');
        if (numericCategories.has(category)&&!get('unit')) throw new Error('Row '+(i+1)+': '+category+' needs its measurement unit.');
        imported.push({id:id('history'),date,category,block:get('block'),metric:get('metric'),value,unit:get('unit'),details,reference:get('reference'),source:'institution-import',createdBy:personKey()});
      }
      if (!imported.length) throw new Error('No data rows found.');
      const key=r=>[r.date,r.category,String(r.block||'').trim().toLowerCase(),String(r.metric||'').trim().toLowerCase(),String(r.reference||'').trim().toLowerCase()].join('|');
      const incoming=new Map(imported.map(r=>[key(r),r])),existing=new Map(data.history.map((r,i)=>[key(r),i]));
      let inserted=0,updated=0;
      for(const [recordKey,r] of incoming){const i=existing.get(recordKey);if(i===undefined){existing.set(recordKey,data.history.length);data.history.push(r);inserted++;}else{r.id=data.history[i].id;data.history[i]=r;updated++;}}
      save();render();toast(inserted+' new records imported · '+updated+' matching rows updated. Coverage: '+Math.round(historyReadiness().ratio*100)+'%.');
    } catch (e) { toast(e.message||'CSV could not be imported.'); }
  }
  function submitHistoryRecord(form) {
    const fd=new FormData(form),category=String(fd.get('category')),text=String(fd.get('value')||'').trim(),date=String(fd.get('date')||'');
    let value=null;
    if (text!=='') { value=Number(text);if(!Number.isFinite(value)||value<0){toast('Value must be a non-negative number.');return;} }
    if(!validDateOnly(date)||date>dateInput()){toast('Enter a real record date no later than today.');return;}
    if (numericCategories.has(category)&&value===null) { toast('This category needs a numeric measured value; use 0 with a no-activity note if there was no activity.');return; }
    if (numericCategories.has(category)&&!String(fd.get('unit')||'').trim()) { toast('Enter the measurement unit for this numeric record.');return; }
    const details=String(fd.get('details')||'').trim();if(!details){toast('Describe the measured record or monthly review.');return;}
    data.history.push({id:id('history'),date,category,block:String(fd.get('block')||''),metric:String(fd.get('metric')||''),value,unit:String(fd.get('unit')||'').trim(),details,reference:String(fd.get('reference')||''),source:'manual-entry',createdBy:personKey()});
    save();render();toast('Institution record added. Coverage: '+Math.round(historyReadiness().ratio*100)+'%.');
  }
  function download(name, content, mime) {
    const blob=new Blob([content],{type:mime||'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function exportCsv(kind) {
    const quote=v=>'\"'+String(v==null?'':v).replaceAll('\"','\"\"')+'\"';
    let rows;
    if (kind==='history') rows=[['date','category','block','metric','value','unit','details','reference'],...data.history.map(x=>[x.date,x.category,x.block,x.metric,x.value,x.unit,x.details,x.reference])];
    if (kind==='crew') rows=[['name','email','role','block','reports','shift_hours','xp'],...data.crew.map(m=>[m.name,m.email,m.role,m.block,data.incidents.filter(x=>x.reporterEmail===m.email).length,data.shifts.filter(x=>x.email===m.email).reduce((s,x)=>s+Number(x.hours||0),0),m.xp])];
    if (kind==='kitchen') rows=[['date','weekday','menu','prepared_kg','meals','waste_kg','note'],...data.kitchen.map(x=>[x.date,x.weekday,x.menu,x.preparedKg,x.meals,x.wasteKg,x.note])];
    if (kind==='equipment') rows=[['name','type','serial','block','condition','quantity','created_at'],...data.equipment.map(x=>[x.name,x.type,x.serial,x.block,x.condition,x.quantity,x.createdAt])];
    if (kind==='incidents') rows=[['created_at','title','category','block','severity','status','reporter_email','description','possible_causes_unconfirmed','duration','potential_consequences','recommended_response'],...data.incidents.map(x=>[x.createdAt,x.title,x.category,x.block,x.severity,x.status,x.reporterEmail,x.description,x.triage?.causes,x.triage?.duration,x.triage?.consequences,x.triage?.response])];
    if (kind==='maintenance') rows=[['created_at','title','asset','block','priority','status','due_date','assigned_to','description','resolution_evidence','resolved_at'],...data.maintenance.map(x=>[x.createdAt,x.title,x.assetName,x.block,x.priority,x.status,x.dueDate,x.assignedTo,x.description,x.resolutionEvidence,x.resolvedAt])];
    if (kind==='evidence') rows=[['recorded_at','incident_id','title','category','block','priority','status','reporter','assigned_to','response_target_minutes','acknowledged_at','description','action_taken','possible_causes_unconfirmed','duration_evidence','response_playbook','resolution_evidence','resolved_at','attachment_name','verified','source_label'],...data.incidents.map(x=>[x.createdAt,x.id,x.title,x.category,x.block,x.severity,x.status,x.reporterEmail,x.assignedTo,x.expectedMinutes,x.acknowledgedAt,x.description,x.actionTaken,x.triage?.causes,x.triage?.duration,x.triage?.response,x.resolutionEvidence,x.resolvedAt,x.evidenceName,x.verified,x.reference||'Reporter-entered incident record'])];
    download('infraiq-'+kind+'.csv',rows.map(r=>r.map(quote).join(',')).join('\r\n'));
    toast('CSV export downloaded.');
  }
  async function ask(question,mode='chat',file=null) {
    const rawQuestion=String(question||'').trim(),q=rawQuestion.toLowerCase();if(!rawQuestion)return;
    file=file||ui.pendingDocument;
    if((mode==='document'||mode==='agent')&&!cloudSession){toast('This AI feature needs a signed-in campus account on the secured deployment.');return;}
    if(mode==='document'&&!file){toast('Attach a PDF or image before starting document analysis.');return;}
    let text='',sources=[];
    if (q.includes('incident')||q.includes('transformer')||q.includes('report')||q.includes('problem')||q.includes('duration')||q.includes('running')||q.includes('leak')) {
      const categoryNeedle=q.includes('transformer')||q.includes('electric')?'electrical':q.includes('leak')||q.includes('water')?'water':q.includes('lab')||q.includes('chemical')?'lab':q.includes('security')?'security':q.includes('fire')?'fire':q.includes('equipment')?'equipment':'';
      const xs=data.incidents.filter(x=>(!q.includes('my')||x.reporterEmail===personKey())&&(!categoryNeedle||x.category===categoryNeedle)).slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
      if(xs.length){const x=xs[0];text='Latest matching report: '+x.title+' at '+(x.block||'campus')+'. Status: '+x.status+'. First noticed '+fmtDate(x.observedAt,true)+'. '+x.triage.duration+' Possible causes remain unconfirmed. Recommended response: '+x.triage.response;sources=['Incident '+x.id];}
      else text='There are no matching campus reports in the records stored in this browser. Submit an observed incident before asking for a case-specific workflow.';
    } else if(q.includes('maintenance')||q.includes('work order')||q.includes('service due')||q.includes('ticket')) {
      const tickets=data.maintenance.slice().sort((a,b)=>String(a.dueDate||'9999').localeCompare(String(b.dueDate||'9999'))).filter(x=>!q.includes('my')||x.assignedTo===personKey()).slice(0,8);
      if(tickets.length){text='Campus maintenance records: '+tickets.map(x=>x.title+' · '+(x.block||'campus')+' · '+(x.assetName||'general')+' · '+(x.status||'Open')+' · '+(x.priority||'Normal')+' priority · due '+(x.dueDate?fmtDate(x.dueDate):'not scheduled')+' · assigned '+(x.assignedTo?reporterName(x.assignedTo):'unassigned')+(x.resolutionEvidence?' · completion evidence recorded':' · no completion evidence recorded')).join(' | ');sources=tickets.map(x=>'Work order '+x.id);}
      else text='There are no matching maintenance work orders. Add a ticket from the Maintenance desk; blank due dates and assignments are not estimated.';
    } else if(q.includes('food')||q.includes('kitchen')||q.includes('waste')||q.includes('menu')) {
      const last=data.kitchen.slice().sort((a,b)=>b.date.localeCompare(a.date))[0];
      if(last){text='Latest kitchen entry ('+fmtDate(last.date)+'): '+last.menu+'. Prepared '+fmtNumber(last.preparedKg,1)+' kg, '+fmtNumber(last.meals,0)+' meals served, and '+fmtNumber(last.wasteKg,1)+' kg recorded as waste.';sources=['Kitchen log '+last.date];}
      else text='No kitchen records are present. Kitchen staff can add a dated menu, prepared quantity, meals served, and measured waste.';
    } else if(q.includes('electric')||q.includes('energy')||q.includes('water')||q.includes('traffic')||q.includes('chemical')||q.includes('equipment')||q.includes('lab')) {
      const keys=q.includes('water')?['water']:q.includes('traffic')?['traffic']:q.includes('chemical')?['chemical_import','chemical_export']:q.includes('equipment')?['equipment_import','equipment_export']:q.includes('lab')?['lab_condition']:['electricity'];
      const found=data.history.filter(x=>keys.includes(x.category)).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
      if(q.includes('equipment')&&data.equipment.length){text='Equipment physically listed in the campus register: '+data.equipment.slice(0,8).map(x=>x.name+' ('+x.type+', '+x.quantity+' listed, '+x.condition+(x.block?' · '+x.block:'' )+')').join('; ')+'. Check the dated equipment import/export history for movement records.';sources=data.equipment.slice(0,8).map(x=>'Asset '+x.id);}
      else if(found.length){text='Recent institution records: '+found.map(x=>fmtDate(x.date)+' · '+(categoriesById[x.category]||x.category)+' · '+(x.value==null?x.details:fmtNumber(x.value,2)+' '+x.unit+' · '+x.details)).join(' | ');sources=found.map(x=>'Record '+x.id);}
      else text='No measured campus records match that question. Enter or import an institution record first; I will not supply a baseline for missing data.';
    } else if(q.includes('shift')||q.includes('hours')||q.includes('crew')||q.includes('worker')) {
      const own=data.shifts.filter(x=>x.email===personKey()),active=activeShiftFor();text='Your account has '+own.length+' completed clocked shift(s) totaling '+fmtNumber(own.reduce((s,x)=>s+Number(x.hours||0),0),2)+' recorded hours. '+(active?'A shift is currently active since '+fmtDate(active.startedAt,true)+'.':'No active shift is running.');sources=own.map(x=>'Shift '+fmtDate(x.startedAt));
    } else if(q.includes('holiday')||q.includes('occasion')) {
      const category=q.includes('holiday')?'holiday':'occasion',records=data.history.filter(x=>x.category===category).sort((a,b)=>a.date.localeCompare(b.date));
      if(records.length){text=(category==='holiday'?'Holiday / closure':'Occasion / event')+' records: '+records.map(x=>fmtDate(x.date)+' · '+(x.block?x.block+' · ':'')+x.details).join(' | ');sources=records.map(x=>'Record '+x.id);}
      else text='No '+(category==='holiday'?'holiday or closure':'occasion or event')+' has been entered. I cannot infer a campus calendar from an empty record set.';
    } else if(q.includes('six month')||q.includes('history')||q.includes('forecast')) {
      const r=historyReadiness();text='Six-month coverage is '+Math.round(r.ratio*100)+'% ('+r.records+' imported or manually entered rows). '+(r.complete?'The monthly category check is complete; numeric projections are based on institution records.':'Forecasts remain locked until every required category is present in each of six completed months.');sources=r.months.map(x=>x.label+(x.missing.length?' missing '+x.missing.length+' categories':' complete'));
    } else if(q.includes('block')||q.includes('student')||q.includes('faculty')||q.includes('instrument')) {
      if(data.blocks.length){text='Campus block records: '+data.blocks.map(b=>b.name+': '+(b.students||'student count not entered')+' students, '+(b.faculty||'faculty count not entered')+' faculty, '+(b.workers||'worker count not entered')+' workers, '+(b.labs||'lab count not entered')+' labs, '+(b.instruments||'instrument count not entered')+' instruments; hours '+(b.opening||'unknown')+'–'+(b.closing||'unknown')).join(' | ');sources=data.blocks.map(b=>'Block '+b.name);}
      else text='No campus block or occupancy details have been entered. Add the actual counts under Campus Profile; blank values are intentionally not estimated.';
    } else if(q.includes('open')||q.includes('close')||q.includes('location')||q.includes('campus')) {
      text=profile.collegeName+' is in '+[profile.city,profile.region].filter(Boolean).join(', ')+'. Usual campus hours: '+(profile.opening||'unknown')+' to '+(profile.closing||'unknown')+'. '+data.blocks.length+' campus blocks are recorded.';sources=['Campus profile'];
    } else text='I could not find verified information for that question in this browser’s campus records. Try asking about an incident report, shift hours, kitchen log, campus schedule, block, or imported history.';

    const history=data.messages.filter(m=>m.from==='user'||m.from==='assistant').slice(-10).map(m=>({role:m.from,content:String(m.text||'').slice(0,1200)}));
    data.messages.push({from:'user',text:rawQuestion||'Analyze the attached campus document.',fileName:file?.name||'',createdAt:new Date().toISOString()});
    const assistant={id:id('answer'),from:'assistant',text:cloudSession?(mode==='agent'?'Preparing a reviewable action draft…':'Connecting to the secure INFRAIQ assistant…'):text,sources:cloudSession?[]:sources,createdAt:new Date().toISOString(),proposedAction:null};
    data.messages.push(assistant);if(data.messages.length>60)data.messages=data.messages.slice(-60);
    save();render();document.querySelector('.chat-log')?.scrollTo({top:999999,behavior:'smooth'});
    if(!cloudSession)return;
    ui.copilotState='Streaming secure AI response…';save();
    try {
      const result=await callSecureAssistant(mode,rawQuestion,file,history,delta=>{
        if(mode==='agent')return;
        assistant.text+=delta;
        const live=document.querySelector('[data-message-id="'+CSS.escape(assistant.id)+'"] [data-message-text]');if(live)live.textContent=assistant.text;
      });
      assistant.text=result.answer||assistant.text;assistant.sources=result.sources||[];assistant.model=result.model||'';assistant.proposedAction=result.proposedAction||null;
      if(mode==='document')ui.pendingDocument=null;
      ui.copilotState='Available · '+(assistant.model||'secure AI route');
    } catch(error) {
      ui.copilotState='Unavailable';assistant.text=error.message||'The secure assistant is temporarily unavailable. Campus data was not changed.';assistant.sources=[];assistant.proposedAction=null;
    }
    save();render();document.querySelector('.chat-log')?.scrollTo({top:999999,behavior:'smooth'});
  }

  async function callSecureAssistant(mode,question,file,history,onDelta) {
    const sessionResult=await cloudClient.auth.getSession(),token=sessionResult?.data?.session?.access_token||cloudSession?.access_token;
    if(sessionResult?.error||!token)throw new Error('Your sign-in expired. Sign in again before using the secure assistant.');
    const route=String(window.INFRAIQ_SUPABASE_CONFIG?.aiApiRoute||'/api/assistant');
    let response;
    try {
      response=await fetch(route,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token},body:JSON.stringify({mode,question,history,institutionId:profile.institutionId,file:file?{name:file.name,mimeType:file.mimeType,dataBase64:file.dataBase64}:null})});
    } catch(error) {
      if(mode==='document'||mode==='agent')throw new Error('The Vercel AI route is unavailable. Deploy the secured /api/assistant route to enable this feature.');
      return callLegacyCopilot(mode,question);
    }
    if([404,503].includes(response.status)&&mode!=='document'&&mode!=='agent')return callLegacyCopilot(mode,question);
    if(!response.ok){let payload={};try{payload=await response.json();}catch{}throw new Error(payload.error||'The secure AI request failed. Your campus records were not changed.');}
    if(!String(response.headers.get('content-type')||'').includes('text/event-stream')){
      let payload={};try{payload=await response.json();}catch{}throw new Error(payload.error||'The AI route did not return a stream.');
    }
    const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',answer='',meta={},streamError='';
    const consume=raw=>{
      for(const line of raw.split('\n')){
        if(!line.startsWith('data:'))continue;let item;try{item=JSON.parse(line.slice(5).trim());}catch{continue;}
        if(item.type==='delta'&&typeof item.delta==='string'){answer+=item.delta;onDelta?.(item.delta);}
        else if(item.type==='meta'){meta=item;if(item.answer){answer=item.answer;}}
        else if(item.type==='error')streamError=item.error||'The AI stream stopped unexpectedly.';
      }
    };
    while(true){const part=await reader.read();if(part.done)break;buffer+=decoder.decode(part.value,{stream:true}).replace(/\r\n/g,'\n');let split;while((split=buffer.indexOf('\n\n'))>=0){const frame=buffer.slice(0,split);buffer=buffer.slice(split+2);consume(frame);}}
    if(buffer)consume(buffer);
    if(streamError)throw new Error(streamError);
    if(!answer.trim())throw new Error('The secure AI route returned an empty answer. Please retry.');
    return {answer:answer.trim(),sources:meta.sources||[],proposedAction:meta.proposedAction||null,model:meta.model||''};
  }

  async function callLegacyCopilot(mode,question) {
    if(mode==='document'||mode==='agent')throw new Error('Deploy the Vercel AI route to enable this feature.');
    const request=mode==='campus_report'?'Create a campus-wide health and operations report from the permitted campus evidence. Separate favorable recorded cues, issues to investigate, missing evidence, cautious estimates, and human-approved next steps. Do not certify safety or compliance.':question;
    const {data:result,error}=await cloudClient.functions.invoke(cloud.functionName||'campus-copilot',{body:{question:String(request||'Review my campus records with their uncertainty and source IDs.')}});
    if(error||!result?.answer)throw new Error('Neither the Vercel AI route nor the Supabase Copilot returned an answer. Check deployment configuration.');
    return {answer:result.answer,sources:result.sources||[],model:result.model||'Supabase Copilot',proposedAction:null};
  }

  async function generateHealthReport() {
    if(ui.healthReportLoading)return;
    if(!cloudSession){toast('Sign in to an authenticated campus workspace to generate the AI health report.');return;}
    const history=data.messages.filter(m=>m.from==='user'||m.from==='assistant').slice(-10).map(m=>({role:m.from,content:String(m.text||'').slice(0,1200)}));
    ui.healthReportLoading=true;ui.healthReportDraft='';render();
    try {
      const result=await callSecureAssistant('campus_report','Review all available campus data. Provide favorable recorded cues, items to investigate, evidence gaps, cautious estimates only where dates and comparable data support them, and prioritized human-reviewed recommendations.',null,history,delta=>{ui.healthReportDraft+=delta;const live=document.getElementById('campus-ai-report-stream');if(live)live.textContent=ui.healthReportDraft;});
      const createdAt=new Date().toISOString();
      data.messages.push({from:'user',text:'Generate an evidence-grounded all-campus health report.',createdAt,context:'campus_report'});
      const saved={id:id('report'),from:'assistant',text:result.answer,sources:result.sources||[],model:result.model||'',createdAt,context:'campus_report'};
      data.messages.push(saved);if(data.messages.length>60)data.messages=data.messages.slice(-60);
      ui.healthReport=saved;ui.copilotState='Available · '+(result.model||'secure AI route');save();
    } catch(error) {toast(error.message||'AI campus report is unavailable.');}
    finally {ui.healthReportLoading=false;ui.healthReportDraft='';render();}
  }

  function startVoiceInput(buttonNode) {
    if(ui.voiceRecognition){ui.voiceRecognition.stop();return;}
    const Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!Speech){toast('Voice input is not available in this browser. Try the latest Chrome or Edge.');return;}
    const field=ROOT.querySelector('form[data-form="question"] [name="question"]');if(!field)return;
    const recognition=new Speech();recognition.lang='en-IN';recognition.interimResults=false;recognition.maxAlternatives=1;ui.voiceRecognition=recognition;
    if(buttonNode){buttonNode.textContent='Listening… · Stop';buttonNode.classList.add('selected');}
    recognition.onresult=event=>{const spoken=String(event.results?.[0]?.[0]?.transcript||'').trim();if(spoken){field.value=(field.value.trim()?field.value.trim()+' ':'')+spoken;field.focus();}};
    recognition.onerror=()=>toast('Voice capture stopped. You can type or try the microphone again.');
    recognition.onend=()=>{ui.voiceRecognition=null;if(buttonNode?.isConnected){buttonNode.textContent='🎙 Speak';buttonNode.classList.remove('selected');}};
    try{recognition.start();}catch{ui.voiceRecognition=null;toast('Voice capture could not start. Check microphone permission.');}
  }

  function speakMessage(messageId) {
    const message=data.messages.find(x=>x.id===messageId);if(!message?.text)return;
    if(!('speechSynthesis'in window)||!window.SpeechSynthesisUtterance){toast('Spoken responses are not supported in this browser.');return;}
    window.speechSynthesis.cancel();const speech=new SpeechSynthesisUtterance(message.text);speech.lang='en-IN';speech.rate=1;window.speechSynthesis.speak(speech);
  }
  function clickAction(action, node) {
    if (action==='go') go(node.dataset.page);
    else if(action==='choose-ai-start'){profile.aiStartChoice=node.dataset.choice==='six_months'?'six_months':'start_now';ui.page=profile.aiStartChoice==='six_months'?'history':'command';save();render();if(profile.aiStartChoice==='six_months')toast('Six-month history is optional and editable. Add actual records when ready.');}
    else if(action==='export-simulation'){const run=latestSimulation();if(!run){toast('Generate a scenario before exporting.');return;}const rows=[['synthetic','date','time','day_type','season','building','floor','occupancy','temperature_c','hvac_fraction','lighting_fraction','energy_kwh_6h','water_l_6h','grid_kwh','solar_kwh','battery_kwh','municipal_water_l','groundwater_l','rainwater_l','anomaly'],...run.rows.map(x=>['TRUE',x.date,x.time,x.dayType,x.season,x.block,x.floor,x.occupancy,x.temperature,x.hvac,x.lighting,x.energy,x.water,x.grid,x.solar,x.battery,x.waterSources.municipal,x.waterSources.groundwater,x.waterSources.rainwater,x.anomaly])];download('INFRAIQ-SYNTHETIC-'+run.id+'.csv',rows.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n'),'text/csv;charset=utf-8');}
    else if(action==='open-scheduled-asset'){ui.page='equipment';ui.focusAssetId=node.dataset.id||'';render();}
    else if(action==='draft-asset-work-order'){
      const asset=data.equipment.find(x=>x.id===node.dataset.id);if(!asset)return;
      ui.maintenanceDraft={type:'maintenance_ticket',title:'Preventive service · '+asset.name,description:'Review the asset condition and complete the scheduled preventive inspection. Record the actual inspection findings and work performed before resolving the order.',priority:'Normal',dueDate:asset.maintenanceDue||dateInput(),assetId:asset.id,block:asset.block||''};go('maintenance');
    }
    else if(action==='clear-maintenance-draft'){ui.maintenanceDraft=null;render();}
    else if(action==='generate-health-report')generateHealthReport();
    else if(action==='voice-input')startVoiceInput(node);
    else if(action==='choose-document')ROOT.querySelector('[data-document-input]')?.click();
    else if(action==='search-records'){const form=ROOT.querySelector('form[data-form="question"]');if(form){form.dataset.mode=ui.pendingDocument?'document':'search';form.requestSubmit();}}
    else if(action==='prepare-agent'){const form=ROOT.querySelector('form[data-form="question"]');if(form){form.dataset.mode='agent';form.requestSubmit();}}
    else if(action==='draft-agent-action'){
      const message=data.messages.find(x=>x.id===node.dataset.id),draft=message?.proposedAction;
      if(!draft){toast('There is no valid work order draft to review.');return;}
      ui.maintenanceDraft={...draft,type:'maintenance_ticket'};go('maintenance');
    }
    else if(action==='clear-document'){ui.pendingDocument=null;const chip=ROOT.querySelector('.document-chip');if(chip)chip.hidden=true;const input=ROOT.querySelector('[data-document-input]');if(input)input.value='';}
    else if(action==='speak-message')speakMessage(node.dataset.id);
    else if(action==='open-showcase'){localStorage.setItem(SHOWCASE_MODE_KEY,'true');location.reload();}
    else if(action==='exit-showcase'){localStorage.setItem(SHOWCASE_MODE_KEY,'false');location.reload();}
    else if(action==='select-block'){ui.selectedBlock=node.dataset.id;render();}
    else if(action==='report-from-block'){ui.reportBlock=node.dataset.block||'';go('staff');}
    else if(action==='copy-block-link'){
      const url=new URL(location.href);url.searchParams.set('block',node.dataset.block||'');
      if(!navigator.clipboard?.writeText){toast('Copy access is unavailable in this browser. Use this page URL and add ?block=Block%20name');return;}
      navigator.clipboard.writeText(url.href).then(()=>toast('Block-specific incident shortcut copied. Anyone opening it still needs the proper campus sign-in.')).catch(()=>toast('Browser blocked clipboard access.'));
    }
    else if(action==='print-report'){
      const print=()=>{document.body.classList.add('printing-campus-report');window.print();window.setTimeout(()=>document.body.classList.remove('printing-campus-report'),800);};
      if(ui.page==='health')print();else{ui.page='health';render();window.setTimeout(print,180);}
    }
    else if(action==='evidence-export')exportCsv('evidence');
    else if(action==='maintenance-export')exportCsv('maintenance');
    else if(action==='open-evidence'){
      if(!cloudSession||!node.dataset.path){toast('Private evidence requires your signed-in campus account.');return;}
      const target=window.open('about:blank','_blank');if(target)target.opener=null;
      cloudClient.storage.from('infraiq-evidence').createSignedUrl(node.dataset.path,300).then(({data:result,error})=>{
        if(error||!result?.signedUrl){if(target)target.close();toast('Evidence access failed: '+(error?.message||'file unavailable'));return;}
        if(target)target.location.href=result.signedUrl;else toast('Pop-up blocked. Reopen the evidence button and allow this site to open a tab.');
      });
    }
    else if(action==='assistant-why'){ui.explainOpen=ui.explainOpen===node.dataset.id?'':node.dataset.id;render();}
    else if(action==='assistant-feedback'){
      const answerId=node.dataset.id,value=node.dataset.value,rows=data.assistantFeedback||[],i=rows.findIndex(x=>x.answerId===answerId);
      if(i>=0)rows[i]={answerId,value,createdAt:new Date().toISOString(),by:personKey()};else rows.push({answerId,value,createdAt:new Date().toISOString(),by:personKey()});
      data.assistantFeedback=rows;save();render();toast(value==='review'?'Flagged for campus human review.':'Feedback recorded for campus review.');
    }
    else if (action==='sign-out') {
      profile.signedIn=false;
      if(cloudSession){cloudClient.auth.signOut();cloudSession=null;cloudMembership=null;if(cloudChannel){cloudClient.removeChannel(cloudChannel);cloudChannel=null;}if(ui.environmentChannel){cloudClient.removeChannel(ui.environmentChannel);ui.environmentChannel=null;}if(ui.environmentPollTimer){clearInterval(ui.environmentPollTimer);ui.environmentPollTimer=null;}ui.authMode='login';ui.forceLocal=false;ui.cloudState='offline';persistLocal();render();}
      else {save();render();}
    }
    else if (action==='edit-campus') { profile.completed=false;profile.signedIn=false;ui.signupStep='campus';render(); }
    else if (action==='signup-back') { ui.signupStep='identity';render(); }
    else if (action==='toggle-cloud-auth') { ui.authMode=ui.authMode==='login'?'signup':'login';ui.error='';ui.confirmationPending=false;render(); }
    else if (action==='cloud-login') { ui.authMode='login';ui.confirmationPending=false;ui.error='';render(); }
    else if (action==='reset-password') {
      const email=String(ROOT.querySelector('[name="email"]')?.value||profile.email||'').trim().toLowerCase();
      if(!email){toast('Enter your work email first.');return;}
      cloudClient.auth.resetPasswordForEmail(email,{redirectTo:location.href.split('#')[0]}).then(({error})=>toast(error?'Could not send the reset email: '+error.message:'Password reset instructions sent if the account exists.'));
    }
    else if (action==='use-local-demo') { ui.forceLocal=true;ui.error='';ui.confirmationPending=false;render(); }
    else if (action==='enable-notifications') {
      if(!('Notification'in window)){toast('This browser does not support desktop notifications.');return;}
      Notification.requestPermission().then(result=>{toast(result==='granted'?'Desktop alerts are enabled for urgent reports and new environment updates in this open browser.':'Notification permission was not granted. Keep INFRAIQ open to see live updates.');render();});
    }
    else if(action==='enable-environment-notifications') {
      if(!('Notification'in window)){toast('This browser does not support desktop notifications.');return;}
      Notification.requestPermission().then(result=>{toast(result==='granted'?'Environment desktop alerts are enabled while INFRAIQ is open.':'Notification permission was not granted. Keep the environment panel open for updates.');render();});
    }
    else if(action==='refresh-environment-feed')refreshEnvironmentFeed();
    else if (action==='copy-invite') { const code=String(node.dataset.code||'');if(!navigator.clipboard?.writeText){toast('Clipboard access is unavailable; select and copy the invitation code manually.');return;}navigator.clipboard.writeText(code).then(()=>toast('Invitation code copied. Share it privately with the invited email address.')).catch(()=>toast('Copy was blocked; select and copy the invitation code manually.')); }
    else if (action==='clock-in') startShift();
    else if (action==='clock-out') endShift();
    else if (action==='verify') verifyReport(node.dataset.id);
    else if (action==='rotate-chart') { ui.rotation=(ui.rotation+24)%360;render(); }
    else if (action==='history-template') historyTemplate();
    else if (action==='history-export') exportCsv('history');
    else if (action==='incident-export') exportCsv('incidents');
    else if (action==='crew-export') exportCsv('crew');
    else if (action==='kitchen-export') exportCsv('kitchen');
    else if (action==='clear-chat') { data.messages=[];ui.explainOpen='';save();render(); }
    else if (action==='remove-block') { data.blocks=data.blocks.filter(x=>x.id!==node.dataset.id);save();render();toast('Campus block removed.'); }
    else if (action==='remove-equipment') { data.equipment=data.equipment.filter(x=>x.id!==node.dataset.id);save();render();toast('Asset removed from the local register.'); }
    else if (action==='save-campus') document.querySelector('[data-form="campus"]')?.requestSubmit();
    else if (action==='equipment-export') exportCsv('equipment');
  }
  async function submitCloudAuth(form) {
    const fd=new FormData(form),email=String(fd.get('email')||'').trim().toLowerCase(),password=String(fd.get('password')||'');
    ui.error='';ui.cloudState='connecting';
    if(ui.authMode==='login') {
      const {data:result,error}=await cloudClient.auth.signInWithPassword({email,password});
      if(error){ui.error=error.message;ui.cloudState='error';render();return;}
      await activateCloudSession(result.session);return;
    }
    const personName=String(fd.get('personName')||'').trim(),inviteCode=String(fd.get('inviteCode')||'').trim();
    profile.personName=personName;profile.email=email;ui.inviteCode=inviteCode;
    const draft={personName,email,inviteCode};
    try{localStorage.setItem(CLOUD_DRAFT_KEY,JSON.stringify(draft));}catch{}
    const {data:result,error}=await cloudClient.auth.signUp({email,password,options:{data:{full_name:personName},emailRedirectTo:location.href.split('#')[0]}});
    if(error){ui.error=error.message;ui.cloudState='error';render();return;}
    if(result.session){await activateCloudSession(result.session);return;}
    ui.confirmationPending=true;ui.cloudState='awaiting-confirmation';render();
  }
  async function submitCloudPassword(form) {
    const fd=new FormData(form),password=String(fd.get('password')||''),confirm=String(fd.get('confirmPassword')||'');
    if(password.length<10||password!==confirm){ui.error='Use at least 10 characters and make both passwords match.';render();return;}
    const {error}=await cloudClient.auth.updateUser({password});
    if(error){ui.error=error.message;render();return;}
    ui.resetPassword=false;ui.error='';await activateCloudSession(cloudSession);
  }
  async function submitCloudCampus(form) {
    const fd=new FormData(form),inviteCode=String(fd.get('inviteCode')||'').trim();
    const campus={collegeName:String(fd.get('collegeName')||'').trim(),city:String(fd.get('city')||'').trim(),region:String(fd.get('region')||'').trim(),address:String(fd.get('address')||'').trim(),campusSize:String(fd.get('campusSize')||'').trim(),blockCount:String(fd.get('blockCount')||'').trim(),opening:String(fd.get('opening')||'08:00'),closing:String(fd.get('closing')||'18:00')};
    Object.assign(profile,campus);ui.error='';ui.cloudState='connecting';
    const draft={personName:profile.personName,email:profile.email,inviteCode,...campus};try{localStorage.setItem(CLOUD_DRAFT_KEY,JSON.stringify(draft));}catch{}
    if(inviteCode) {
      const {data:claimed,error}=await cloudClient.rpc('claim_infraiq_invite',{p_code:inviteCode,p_full_name:profile.personName});
      if(error){ui.error=error.message;ui.cloudState='error';render();return;}
      profile.institutionId=claimed.institution_id;profile.role=claimed.role;profile.completed=true;profile.signedIn=true;ui.page='command';
    } else {
      const numeric=v=>v===''?null:Number(v);
      const {data:institutionId,error}=await cloudClient.rpc('create_infraiq_institution',{p_name:campus.collegeName,p_city:campus.city,p_region:campus.region,p_address:campus.address,p_campus_size:numeric(campus.campusSize),p_block_count:numeric(campus.blockCount),p_opening:campus.opening,p_closing:campus.closing,p_full_name:profile.personName});
      if(error){ui.error=error.message;ui.cloudState='error';render();return;}
      profile.institutionId=institutionId;profile.role='admin';profile.completed=true;profile.signedIn=true;ui.page='history';
    }
    localStorage.removeItem(CLOUD_DRAFT_KEY);ui.signupStep='identity';
    const loaded=await loadCloudWorkspace();
    if(loaded){ui.page=inviteCode?'command':'history';render();toast(inviteCode?'Invitation accepted. Your assigned role and campus workspace are loaded.':'Shared campus workspace created. Enter institution history before forecasts unlock.');subscribeCloud();}
  }
  ROOT.addEventListener('click', e => {
    const node=e.target.closest('[data-action]');if(node){if(node.tagName==='A')e.preventDefault();clickAction(node.dataset.action,node);}
  });
  ROOT.addEventListener('change', e => {
    if(e.target.matches('[data-asset-maintenance-id]')){
      const asset=data.equipment.find(x=>x.id===e.target.dataset.assetMaintenanceId),value=String(e.target.value||'');
      if(!asset||!canManage()){toast('Only an authorized campus manager can update asset schedules.');render();return;}
      if(value&&!validDateOnly(value)){toast('Enter a valid maintenance date.');render();return;}
      asset.maintenanceDue=value;asset.maintenanceUpdatedAt=new Date().toISOString();save();render();toast(value?'Asset preventive date saved.':'Asset preventive date cleared.');return;
    }
    if(e.target.matches('[data-document-input]')){
      const file=e.target.files?.[0];if(!file)return;
      if(file.size>3*1024*1024){e.target.value='';toast('Choose a PDF or image under 3 MB.');return;}
      if(!['application/pdf','image/jpeg','image/png','image/webp'].includes(file.type)){e.target.value='';toast('Choose a PDF, JPG, PNG, or WebP file.');return;}
      file.arrayBuffer().then(buffer=>{
        const bytes=new Uint8Array(buffer);let binary='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)binary+=String.fromCharCode(...bytes.subarray(i,i+step));
        ui.pendingDocument={name:file.name,mimeType:file.type,dataBase64:btoa(binary)};
        const chip=ROOT.querySelector('.document-chip');if(chip){chip.hidden=false;chip.querySelector('[data-document-name]').textContent=file.name;}
      }).catch(()=>toast('The file could not be read in this browser.'));
      return;
    }
    if(e.target.id==='role-picker'&&!cloudSession) {
      profile.role=e.target.value;save();ui.page='command';render();toast('Showing the '+currentRole().label+' panel.');
    }
    if(e.target.matches('[data-status-id]')) {
      const item=data.incidents.find(x=>x.id===e.target.dataset.statusId);
      if(item&&(canManage()||item.assignedTo===personKey())){
        const next=e.target.value,details=e.target.closest('.incident-detail'),evidence=details?.querySelector('[data-resolution-id=\"'+item.id+'\"]')?.value.trim()||item.resolutionEvidence||'';
        if(next==='Resolved'&&!evidence){toast('Add inspection or resolution evidence before resolving this incident.');render();return;}
        item.status=next;item.updatedAt=new Date().toISOString();
        if(next==='Acknowledged'&&!item.acknowledgedAt){item.acknowledgedAt=new Date().toISOString();item.acknowledgedBy=personKey();}
        if(next==='Resolved'){item.resolutionEvidence=evidence;item.resolvedAt=new Date().toISOString();item.resolvedBy=personKey();}
        save();render();toast(next==='Resolved'?'Incident resolved with recorded evidence.':next==='Acknowledged'?'Incident acknowledged by '+reporterName(personKey())+'.':'Incident status updated.');
      }
    }
    if(e.target.matches('[data-assignee-id]')) {
      const item=data.incidents.find(x=>x.id===e.target.dataset.assigneeId);
      if(item&&canManage()){item.assignedTo=e.target.value;item.assignedBy=personKey();item.assignedAt=new Date().toISOString();save();render();toast(e.target.value?'Incident assigned to '+reporterName(e.target.value)+'.':'Incident is unassigned.');}
    }
    if(e.target.matches('[data-ticket-status-id]')){
      const ticket=data.maintenance.find(x=>x.id===e.target.dataset.ticketStatusId);
      if(ticket&&(canManage()||ticket.assignedTo===personKey())){
        const next=e.target.value,card=e.target.closest('.maintenance-ticket'),evidence=card?.querySelector('[data-ticket-evidence-id=\"'+ticket.id+'\"]')?.value.trim()||ticket.resolutionEvidence||'';
        if(next==='Resolved'&&!evidence){toast('Add maintenance inspection evidence before resolving this ticket.');render();return;}
        ticket.status=next;ticket.updatedAt=new Date().toISOString();
        if(next==='Resolved'){ticket.resolutionEvidence=evidence;ticket.resolvedAt=new Date().toISOString();ticket.resolvedBy=personKey();}
        save();render();toast('Maintenance ticket updated.');
      }
    }
    if(e.target.matches('[data-ticket-assignee-id]')){
      const ticket=data.maintenance.find(x=>x.id===e.target.dataset.ticketAssigneeId);
      if(ticket&&canManage()){ticket.assignedTo=e.target.value;ticket.assignedBy=personKey();ticket.assignedAt=new Date().toISOString();save();render();toast('Maintenance technician assignment saved.');}
    }
  });
  ROOT.addEventListener('submit', async e => {
    const form=e.target.closest('form[data-form]');if(!form)return;e.preventDefault();
    const kind=form.dataset.form;
    if(kind==='cloud-auth') { await submitCloudAuth(form);return; }
    if(kind==='cloud-campus') { await submitCloudCampus(form);return; }
    if(kind==='cloud-password') { await submitCloudPassword(form);return; }
    if(form.querySelector('[name="website_url"]')?.value.trim())return;
    if(kind==='simulation'){generateScenario(form);return;}
    if(kind==='resource-source'){saveResourceMix(form);return;}
    if(kind==='signup-identity') {
      const fd=new FormData(form);profile.personName=String(fd.get('personName')||'').trim();profile.email=String(fd.get('email')||'').trim().toLowerCase();ui.error='';ui.signupStep='campus';render();return;
    }
    if(kind==='signup-campus') {
      const fd=new FormData(form);
      for(const key of ['collegeName','city','region','address','blockCount','campusSize','opening','closing','role'])profile[key]=String(fd.get(key)||'').trim();
      profile.completed=true;profile.signedIn=true;ensureCrewMember();save();ui.page='command';render();toast('Workspace created. Choose six-month data or start with regular records.');return;
    }
    if(kind==='login') {
      const email=String(new FormData(form).get('email')||'').trim().toLowerCase();
      const member=memberFor(email);
      if(email!==String(profile.email||'').toLowerCase()&&!member){ui.error='That email is not part of this browser’s campus roster. Ask an administrator to add the crew member.';render();return;}
      if(member){profile.personName=member.name;profile.email=member.email;profile.role=member.role;}
      profile.signedIn=true;ui.error='';ensureCrewMember();save();ui.page='command';render();return;
    }
    if(kind==='incident') await submitIncident(form);
    else if(kind==='crew') await submitCrew(form);
    else if(kind==='kitchen') submitKitchen(form);
    else if(kind==='maintenance') await submitMaintenance(form);
    else if(kind==='equipment') {
      const fd=new FormData(form),quantity=Number(fd.get('quantity'));
      if(!Number.isInteger(quantity)||quantity<1){toast('Quantity must be a positive whole number.');return;}
      data.equipment.push({id:id('asset'),name:String(fd.get('name')||'').trim(),type:String(fd.get('type')||'').trim(),serial:String(fd.get('serial')||'').trim(),block:String(fd.get('block')||''),condition:String(fd.get('condition')||'Unknown'),quantity,maintenanceDue:String(fd.get('maintenanceDue')||''),createdAt:new Date().toISOString()});
      save();render();toast('Equipment added to the actual asset register.');
    }
    else if(kind==='block') submitBlock(form);
    else if(kind==='campus') await saveCampus(form);
    else if(kind==='history-import') await importHistory(form);
    else if(kind==='history-record') submitHistoryRecord(form);
    else if(kind==='resource-observation') saveResourceObservation(form);
    else if(kind==='question') { const selectedMode=form.dataset.mode||'chat',mode=ui.pendingDocument&&selectedMode==='chat'?'document':selectedMode;form.dataset.mode='chat';await ask(new FormData(form).get('question'),mode,ui.pendingDocument); }
  });
  if (typeof BroadcastChannel!=='undefined') {
    try {
      channel=new BroadcastChannel('infraiq-campus-workspace');
      channel.onmessage=event=>{if(event.data?.type==='workspace-update'){Object.assign(data,read(DATA_KEY,data));render();}};
    } catch {}
  }
  window.addEventListener('storage',e=>{
    if(e.key===DATA_KEY){Object.assign(data,read(DATA_KEY,data));render();}
    if(e.key===PROFILE_KEY){Object.assign(profile,read(PROFILE_KEY,profile));render();}
  });
  if (profile.completed && profile.signedIn) ensureCrewMember();
  render();
  if(cloudConfigured&&!SHOWCASE_MODE)initializeCloud();
})();
