# Assumptions and limits

- Supabase mode is enabled only after the project URL and public key are filled in and the included migration is applied. This deliverable does not include a Supabase project, secrets, deployed Edge Function, or live account.
- Local demo data is isolated to one browser profile. Local email/role flow is a preview, not secure sign-in; role previews must not be treated as access controls.
- Online accounts join one institution through an email-bound, one-time invitation. The first account that creates an institution receives the administrator role.
- Campus footprint, per-block occupancy, labs, instruments, equipment, kitchen quantities, historic measurements, events and closures are actual-input fields. Blank fields stay blank; the application does not generate starter values.
- History readiness requires a real record for every category/month pair across the six most recently completed calendar months. A numeric zero needs a written register-review explanation.
- Incident triage suggests possible causes and consequences from a rules checklist. Onset duration is unknown unless the reporter supplies evidence. The Copilot is advisory, may make mistakes, and does not diagnose, dispatch, verify, or control operations.
- XP is granted once for an administrator/dean-verified report and reflects validated reporting, not raw submission volume. It is not compensation or a formal employee assessment.
- Shift hours span clock-in to clock-out. Cloud mode stamps and computes duration on the database server, and staff cannot edit or delete completed records. A supervisor should review it; it is not payroll-grade attendance.
- Online Realtime requires an open, connected app session. Browser notifications need permission; this bundle has no email, SMS, or offline push sender.
- The Supabase audit table records metadata and changed field names only. It is not a complete immutable compliance archive with payload snapshots.
- Map embed keys are visible in the browser and must be restricted by referrer and API. Map search links need no key.
- CPCB/DD News/PIB links give access to source websites. The scheduled backend screens PIB release headlines only; it does not ingest a national broadcast stream or prove an environmental issue affects a campus. AQI readings remain on the source portal and should be checked against the nearest station and timestamp.
- The projection is a simple baseline calculated from entered values after a coverage gate. It is not a calibrated engineering model and is not suitable for automatic equipment control.
- Hosted Copilot context is read according to RLS and sent to the configured OpenAI API. Configure server secrets, review service/provider retention settings, and avoid sensitive student, health, security, access-control, or chemical details unless institution policy permits it.
