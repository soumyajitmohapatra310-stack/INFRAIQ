# INFRAIQ launch checklist

This standalone guide captures the 15 items in the supplied launch checklist, documents which pieces are implemented in the site or backend, and lists owner follow-ups. It does not claim that a remote deployment has passed.

## Prerequisites to provide

- A connected hosting project and real custom domain.
- Google Search Console account access and DNS verification permission.
- A GA4 property and Measurement ID only if the institution approves optional analytics.
- Final organization/legal name, privacy contact, retention periods, subprocessors and data locations, and the institution's approved privacy/legal review.
- Five to eight real visitor questions if the draft FAQ is not suitable.
- An approved share image, 1200 × 630 pixels. The current placeholder is clearly labeled.
- Real customer quotes/reviews and written permission if they are to be published. None are invented or included as review schema.
- A list of data the institution collects and its retention/access policy.

## Round A — Google can find you

1. **Custom 404 page.** `404.html` provides a branded not-found page with links to the product overview and app. Vercel recognizes the file as the site's 404. After deployment, request a made-up path and verify the HTTP response status is 404, not 200.
2. **Unique page titles.** Public pages each have a distinct title, with the brand at the end where appropriate. The authenticated app updates `document.title` for its panels and remains noindex.
3. **Meta descriptions.** Public pages have individual plain-language descriptions. In-app panel descriptions update with the current panel. Re-read final copy before indexing.
6. **Internal links.** Public pages link to the app, FAQ, privacy notice, and overview. `npm run check:site` checks local HTML file links. Recheck navigation in the deployed site.
7. **Sitemap.** `npm run build` creates `sitemap.xml` using `SITE_URL`. It lists only the approved public overview by default. Do not add FAQ/privacy drafts or authenticated routes before review.
8. **robots.txt.** The build creates a domain-specific robots file, allows the public overview, disallows API/schema paths, and references the generated sitemap. It is not a security boundary. Inspect it after deployment and confirm there is no blanket `Disallow: /`.

## Round B — Share previews and images

4. **Open Graph and Twitter preview.** Each HTML page has preview tags. The placeholder is `assets/infraiq-social-placeholder.png`, exactly 1200 × 630. Replace with approved artwork and update its title/description/alt if the content changes. One shared card is used until you provide page-specific artwork. Social platforms may cache old cards; test with their preview debuggers or a fresh URL.
5. **Alt text.** The current app has no meaningful inline photos. The social card has an explicit alt description. Every future meaningful `<img>` needs short, specific `alt`; decorative images should use `alt=""`. The build check catches missing social image alt metadata and validates the image dimensions.

## Round C — Forms, tracking, and privacy

10. **Spam protection and validation.** App forms receive an offscreen honeypot. With migrations 004 and 005 applied, authenticated Supabase record writes have a database-side 120 writes-per-user-per-minute limit, tenant/role RLS, payload and field-size checks, numeric/date checks, and record-specific required-field validation. Workspace institutions also have column-level database constraints. Local-only mode has no server protection. There is no public lead form; do not add CAPTCHA unless a public form is introduced and attracts spam. Any future public form needs a server-side handler with per-field validation and rate limits.
11. **Thank-you route.** `thank-you.html` is noindex and excluded from the sitemap. It is a template only; no public form currently redirects there. Wire it only after a server confirms successful submission. Existing in-app operational forms keep their current confirmations.
12. **GA4 consent.** `analytics-config.js` contains an empty ID. If GA4 is approved, set the real `G-...` ID. `cookie-consent.js` shows an Accept/Reject banner to all visitors and loads Google Analytics only after acceptance; rejection keeps it off. Cookie settings lets a visitor reopen the choice. No IP-based country detection is used.
13. **Privacy notice.** `privacy.html` is a noindex draft describing local browser storage, Supabase/Auth, Vercel, optional OpenAI processing, Google Maps, browser speech recognition, and consent-gated Analytics. Add the organization name/contact, retention periods, provider/data locations, legal basis/purposes, request process, and approved final text. Obtain institution review before indexing.

## Round D — Trust

9. **HTTPS and mixed content.** Static page assets use relative paths or HTTPS. Vercel supplies domain TLS and its HTTP-to-HTTPS behavior after domain connection; the config adds HSTS and basic security headers. After connecting the domain, test `http://` redirect, inspect DevTools for mixed-content warnings, and confirm the certificate before launch. Other hosts need their own HTTPS redirect configuration.
14. **FAQ.** `faq.html` has draft factual questions based on the app's current data, sensor, and AI behavior. Review the wording or replace it with real visitor questions. It is noindex until approval. No FAQ structured-data schema is added.
15. **Reviews.** The About page contains a clearly labeled placeholder, not a customer quote. Publish only verified material you supply with permission. No rating, reviewer identity, fabricated result, or review schema is included.

## After launch — four manual steps

1. Verify the real domain in Google Search Console (DNS verification is recommended when available).
2. Submit `https://YOUR-DOMAIN/sitemap.xml` in Search Console.
3. Inspect `https://YOUR-DOMAIN/about.html` in URL Inspection and request indexing after reviewing its content.
4. In GA4 Realtime, check an opted-in test visit. A rejected visit should not load the GA script or appear as a tracked page view.

## Local verification

From the `outputs/infraiq` folder run `node scripts/build-site.js --check` (or `npm run check:site`). For deployment, set `SITE_URL` to the actual bare HTTPS origin and run `npm run build`; the generated sitemap and robots file are not valid for production until this real origin is supplied. After deployment, manually verify HTTP status, HTTPS redirect, Search Console, GA4 consent behavior, and the public social preview. Those require the real host and account access.
