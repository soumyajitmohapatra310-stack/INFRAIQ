# Data and workflow methodology

## Six-month intake

The blank CSV template lists all eleven categories for each of the six most recently completed calendar months. It is an optional broad-history intake users can choose after sign-in or complete later. For October 2026, that means April–September 2026. The active month is not used as a completed history month.

Each month needs at least one row for all 11 categories: electricity, water, lab condition, equipment import, equipment export, chemical import, chemical export, traffic, entry/exit, occasion, and holiday. The coverage check does not claim that a single row is enough for a high-quality prediction. It is not required to start using the website or to view an individual trend. Daily or event-level source data is preferable.

Date format is YYYY-MM-DD. Each row needs a category, a real nonfuture date, and explanatory details. Numeric values with units are mandatory for utilities, movement quantities, traffic, and entry/exit records. Use a measured zero plus an explicit review note for a checked no-activity month. Imports are validated before any row is appended.

## Charts and projections

Charts use only records in the institution history or measured kitchen log. An empty chart remains empty. A chart refuses to combine differing units.

Whole-campus coverage is an optional broad-history checklist, not a gate on using the website. Individual history trends for electricity, water, and traffic become available when at least three distinct months have compatible numeric values. Monthly observations are summarized as arithmetic means and the next-month trend is a least-squares linear fit to at most six observations. Its interval is the projected value plus or minus 1.28 times residual standard deviation, clipped at zero for the lower limit. This remains a simple actual-history baseline, not a calibrated engineering forecast.

## Synthetic resource scenarios and offline models

Resource Intelligence creates fictional six-hour intervals across selected buildings and floors, with time-of-day occupancy, weekday/weekend, seasonal temperature, HVAC/lighting load, solar/battery output, and municipal/groundwater/rainwater shares. Optional fault injections create known after-hours energy or water spikes. These records carry a synthetic marker, are stored in a separate `simulation_run` workspace kind, and are excluded from assistant evidence search and measured-history charts.

The scenario evaluator fits a CPU-only multivariable least-squares regression from the first 80% of generated intervals using occupancy, temperature, HVAC fraction, lighting fraction, and solar output. It reports MAE, RMSE, and MAPE on the later held-out synthetic intervals. These are scenario validation scores only, not evidence of real-campus performance. A deterministic rule screen flags injected faults and extreme generated interval values. The modeled low-occupancy savings are an illustrative scenario; they are not observed savings or a service-quality guarantee.

Offline complaint triage uses a small local Naive Bayes text classifier based on generic example phrases. It classifies, groups, and suggests responsible teams but never assigns staff or changes incident status. Check its labels against the original report.

Actual grid, solar, battery, municipal water, groundwater, and rainwater entries are separate dated source-mix records. Blank source values mean unknown; they are not filled as zero. These source records do not create readings for the history ledger.

Measured interval observations can also be entered by date, time, building, floor, energy, water, temperature, occupancy, and operating hours. No live sensor is connected; these are manual values or user-provided sensor exports. A high-energy or water review cue appears only after six earlier readings exist for the same building, floor, and hour. The rule compares against the median and median absolute deviation; it flags a possible unusual reading for human review and does not diagnose a leak or equipment failure.

Pie charts aggregate the most recent seven actual kitchen entries as prepared minus recorded waste and recorded waste. The user can rotate the 3D-style SVG. No sample amounts are supplied.

## Incident response workflow

The report stores the reporter’s description, selected issue type, block, urgency, first observed time, optional onset and immediate action. The triage checklist then:

1. Repeats the observed problem.
2. Lists category-specific possible causes as unconfirmed.
3. Shows an elapsed interval only when a reporter entered an onset time; otherwise it says that duration is unknown and suggests which records to check.
4. Describes potential consequences conditionally.
5. Gives a conservative response checklist with safety and authorized-role boundaries.

The checklist is deterministic JavaScript and remains available in both modes. In configured Supabase mode, the role-filtered Copilot can add evidence-grounded context from permitted institution records. Neither mode queries a facility sensor or proves an unreported fault.

## Recognition

Crew report totals are shown by day and overall. A report earns 10 XP only after an administrator or dean verifies it. Supabase mode stores this once on the member record; local-demo XP is isolated to the browser. Rank names are derived from XP thresholds of 100 points per level. This rewards verified contribution, not unverified volume as accuracy.

## Online AI retrieval

The Vercel Node route checks the current Supabase user and active campus membership, then reads through PostgreSQL row-level security using that user's token. It scans up to 1,000 recent records, groups history by month/category/block/metric, and selects operational records by question relevance. When it reaches the scan cap it marks the context as potentially incomplete. The route streams answers and uses the existing database-backed per-user request quota. It never uses a service-role credential and exposes no database write or dispatch tool. The authenticated Supabase Edge Function remains an optional text-answer fallback.

The campus health report combines the deterministic record-based readiness cues with an AI summary. The summary may describe estimates only from dated, comparable records and must disclose its evidence and limits. Blank data stays unknown. Uploaded image/PDF content is sent to the configured model for one-time analysis, is size/type-validated, and is not persisted in the INFRAIQ database. AI-generated maintenance details are drafts; the signed-in user must review the existing form and submit the work order.
