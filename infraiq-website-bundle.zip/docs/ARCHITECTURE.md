# Architecture

## Browser application

`index.html` loads `styles.css`, the Supabase v2 browser SDK, `supabase-config.js`, `supabase-client.js`, and `app.js`. The interface has no build step. When cloud settings are empty, the app uses its browser-local demo and the existing panels remain usable. Local records live in versioned localStorage keys; this mode does not provide authentication or cross-device sharing.

When configured, Supabase Auth controls sessions and the `institution_members` row supplies the user's role. The browser role picker is removed in authenticated mode. A one-time invite RPC binds the requested role and block to a verified email, while the first account creating a campus becomes its administrator.

## Database and permissions

`supabase/migrations/001_infraiq_campus.sql` creates institutions, profiles, unique memberships, invitation records, workspace records, audit metadata, and AI quota rows. `workspace_records` stores the existing app's JSON-shaped operational entities by type. PostgreSQL row-level security (RLS) checks active membership, role, record kind, and record owner on every browser data query or mutation. Security-definer RPCs create institutions, issue/claim invites, verify an incident and award XP exactly once, and consume the hosted-assistant quota.

Realtime listens to permitted changes in shared records, memberships, and the campus profile. It updates open connected sessions; it is not an offline notification service. The append-only audit trigger writes action, actor, record identity, timestamp, and changed field names. It does not copy the record payload or field values.

## Record groups

- Institution profile: location, optional campus size/block count, and operating hours.
- Blocks: entered occupancy, area, labs, instruments, and per-block hours.
- Equipment: current register, distinct from dated historical movement records.
- Maintenance: work orders plus editable equipment-register service dates. The preventive schedule includes overdue, next-30-day, and later dates and links back to the correct asset row.
- Crew: authenticated profile, assigned role/block, verified-report XP, and membership time.
- Incidents: reporter-owned submission, response status/assignment, structured triage, and leader verification.
- Shifts: active clock and completed hours owned by the staff account. Online clock-in/out timestamps and duration are stamped by the database; staff cannot directly edit or delete completed shifts.
- Kitchen: dated menu, preparation quantity, meals served, and measured waste.
- History: manual/imported source entries for the eleven required categories.

Role access is defined in SQL policies and should be reviewed for the institution's privacy rules before use with real campus data. The assistant reads records through the same RLS-scoped authenticated client; it never uses a service-role key.

## Assistant and forecasts

The Vercel Node route at `api/assistant.js` validates the same-origin request, Supabase access token, active membership, request shape, file type/size, and database-backed per-user quota. It uses the caller's JWT and the Supabase publishable key for REST reads, so database RLS remains in force; it never uses a service-role credential. The route streams the OpenAI Responses API, keeps the provider key in server environment variables, and supports chat, campus evidence search, all-campus analysis, PDF/image interpretation, and schema-constrained maintenance drafts. Uploaded documents are request-only and are not persisted by INFRAIQ. The Supabase Edge Function remains as a text chat/report fallback when the Vercel endpoint is absent. Browser conversation history is kept in the browser profile, not synced as a separate campus record.

Prompts cite retrieved evidence and separate observations, calculations, estimates, hypotheses, and missing data. The model has no direct database write, dispatch, report-verification, or equipment-control tool. A maintenance draft only opens the existing form prefilled with a verified campus asset; a person edits and submits it. AI output remains advisory and is not an engineering or compliance certification. The assistant does not request provider-side response storage; confirm retention controls against campus policy.

Voice entry uses browser speech recognition; speech output uses the browser speech synthesis engine. These depend on browser support, microphone permission, and that browser's speech service rather than a custom real-time voice model.

After sign-in, users choose whether to enter six months of campus history or start with regular records. The six-month coverage checklist remains available as a broad-history reference, but it is optional. Individual electricity, water, and traffic trend cards need three distinct months of compatible actual measurements; absent inputs produce an empty state. These remain transparent baselines, not trained or calibrated engineering models. Resource Intelligence separately offers a configurable synthetic scenario and held-out CPU regression evaluation; synthetic intervals never count as campus measurements or assistant evidence. Actual interval observations may be entered manually or imported by the user from their sensors; a robust high-spike review needs six earlier readings at the same building, floor, and hour.

## External sources

Campus location can be searched in Google Maps; an optional embedded map needs a restricted Maps Embed API key. The environment panel links to CPCB measurements and official forecast portals; it never substitutes campus data. `/api/environment-monitor` polls the PIB RSS release feed on the Vercel schedule, filters titles and summaries using fixed environmental keywords, and stores public headline metadata in a read-only-to-members Supabase table. Realtime inserts alert connected authenticated sessions. This does not monitor video, infer campus impact, or provide closed-browser push.

See [`../supabase/SETUP.md`](../supabase/SETUP.md) for deployment and secret configuration.
