# Suggested walkthrough

The local demo is for reviewing the UI with browser-only records. To demonstrate real shared roles, first complete `../supabase/SETUP.md` and create an institution owner plus separate invited accounts.

1. Enter a name and work email, create a workspace, and provide the institution name/location. Leave optional size and block values blank if unknown.
2. Open **Campus profile** and add known blocks, opening times, actual headcounts, labs, instruments, and map location.
3. Open **Six-month data**, download the blank CSV, and fill it from real registers. Import the file and review month/category coverage.
4. Add crew roles through one-time email-bound invitations in online mode. Local mode can preview a role but does not authenticate it.
5. As a worker or security staff member, clock in and send an incident from a campus block. Leave onset blank if nobody knows when it began.
6. As a leader, open the incident queue, review reported facts and unconfirmed hypotheses, assign a responsible person, update status, and verify only after review.
7. Inspect the crew page for hours, reports, and verified XP. XP is awarded after review, not for unverified report volume.
8. Add actual dated kitchen menu/production/served/waste data. Rotate the measured-data pie chart.
9. Add real equipment and dated history for energy, water, lab conditions, equipment and chemical movements, traffic, entry/exit, events, and holidays.
10. Open **Resource intelligence** and run a clearly labeled synthetic scenario. Change the building/floor/season settings, inspect HVAC and source mix, and compare the held-out scenario score and injected anomaly. Do not present its sample readings as campus data.
11. Add actual dated grid/solar/battery or municipal/groundwater/rainwater source records. Blank source values remain unknown.
12. Inspect each individual history trend once it has numeric values in at least three distinct months; six-month coverage across all eleven categories is optional broad-history context.
13. Ask the local assistant about records in demo mode; or, in configured online mode, ask Copilot to cite a report, shift, block, kitchen entry, or monthly history. The synthetic scenario is excluded from evidence.
14. In online mode, open **Audit log** as administrator/dean and review action metadata. Use a second signed-in browser session to see Realtime report updates.

The walkthrough uses actual records entered by the operator; no sample measurements are bundled.
