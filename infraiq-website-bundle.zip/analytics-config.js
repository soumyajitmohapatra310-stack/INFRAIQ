/* Add the real GA4 Measurement ID only when the institution has approved analytics. */
window.INFRAIQ_GA4_ID = '';
