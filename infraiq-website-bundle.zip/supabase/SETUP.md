# Supabase deployment and configuration

This guide connects the included front end to a real Supabase project. The application remains in local-demo mode until you configure the project URL and public key. No account credentials or provider secrets are included in this website bundle.

## 1. Create the Supabase project

Create a project in Supabase and keep its database password safe. In **Project Settings → API**, copy the Project URL and the publishable key (or legacy anon key). Do not copy the `service_role` key into any website file.

## 2. Apply the database migration

From a terminal in this `infraiq` folder, either link and push the migration:

```powershell
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Or paste and run migrations `001_infraiq_campus.sql` through `006_environment_monitoring.sql` in order in the Supabase SQL Editor. The second migration adds maintenance tickets, the optional electricity tariff field, and private incident-evidence policies. The third adds role-scoped synthetic scenarios, actual resource-source totals, and manually entered actual interval observations. The fourth adds a private, database-side write counter and resource-reading validation. The fifth validates shared-record payload size, field lengths, dates, quantities, and required fields by record type before applying the write limit. The sixth adds a read-only, Realtime-enabled table for official environment headline metadata; only the server route can write it. For an existing deployment, apply all migrations in order before using matching controls. Do not skip them: the app relies on server-side tenant and role policies.

## 3. Set the public browser configuration

Edit `supabase-config.js`:

```js
window.INFRAIQ_SUPABASE_CONFIG = {
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  publishableKey: 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY',
  copilotFunction: 'campus-copilot'
};
```

The public key is expected to be visible to browser visitors; row-level security protects the records. Never put a `service_role` key or OpenAI key in this file. Use HTTPS for deployment.

## 4. Configure Supabase Auth URLs

In **Authentication → URL Configuration**, add the local site URL and deployed website URL to allowed redirect URLs. For example:

```text
http://localhost:8000/**
https://your-campus.example/**
```

Set the Site URL to the deployed website. Choose whether email confirmation is required; if enabled, add the redirect destinations used by your email templates. Supabase Auth handles passwords and password reset. The application does not store passwords.

## 5. Deploy the authenticated AI function

Create an OpenAI API key in your organization and set it as a Supabase Edge Function secret. Use a model identifier available to your OpenAI API project; the current default in the function is `gpt-5.1` and can be overridden with `OPENAI_MODEL`.

```powershell
supabase secrets set OPENAI_API_KEY="YOUR_OPENAI_API_KEY" OPENAI_MODEL="gpt-5.1" APP_ORIGINS="http://localhost:8000,https://your-campus.example"
supabase functions deploy campus-copilot
```

Replace the example website origins with the exact origins that will host the site. Keep this allow-list narrow. Supabase injects the project URL and public API key into Edge Functions. The function verifies the signed-in user, checks active campus membership and the per-user request quota, reads only records allowed by RLS, and calls the OpenAI Responses API from the server. The app does not send the model key to the browser. The prompt treats record text as untrusted evidence and the function requests non-stored responses (`store: false`).

If your Supabase CLI/project uses a different secret setup flow, configure the same three function variables (`OPENAI_API_KEY`, `OPENAI_MODEL`, `APP_ORIGINS`) in the Supabase dashboard. Check Edge Function logs after deployment; they should never include the key itself.

## 5A. Deploy the streamed Node.js AI route on Vercel

The website now includes `api/assistant.js`, a same-origin Vercel Node.js function. It supports streamed chat, AI campus reports, campus-record search, reviewable work-order drafts, and one-time PDF/image analysis. It verifies the Supabase access token and active institution membership, queries records with the user's RLS token, and consumes the database-backed per-user Copilot quota. It does not use a service-role key or persist uploaded documents.

1. Push the `infraiq` folder to GitHub, then import that repository into Vercel. If it remains nested in the project repository, set Vercel's Root Directory to `outputs/infraiq`. The function requires Node.js 20 or newer.
2. Add these Environment Variables in the Vercel project settings for Preview and Production:

   ```text
   OPENAI_API_KEY=<secret OpenAI API key>
   OPENAI_MODEL=gpt-5.1
   SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
   SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
   APP_ORIGINS=https://your-campus-domain.example
   SUPABASE_SERVICE_ROLE_KEY=<server-only Supabase service role key>
   CRON_SECRET=<long random secret used by Vercel Cron>
   ```

   A legacy Supabase anon key may be used as `SUPABASE_ANON_KEY`. The AI route does not need a service-role key, but the separate environment monitor uses `SUPABASE_SERVICE_ROLE_KEY` and `CRON_SECRET` on the server only. Never place either in browser configuration.
3. Confirm migrations 001 through 006 are applied, Supabase Auth allows the Vercel site URL, and `APP_ORIGINS` exactly lists the site origin. Redeploy after changing environment variables.
4. The front end calls `/api/assistant`. The route has request validation, a 3 MB PDF/image limit, streamed responses, provider timeouts, and per-user database rate limiting. Chat and campus reports can fall back to the Supabase Edge Function when the Vercel route is not available. File analysis and AI action drafts need Vercel.

The app stores the last conversation turns in the same browser profile. Supabase is used for authenticated campus evidence and quotas; uploaded files are not added to campus records. The browser microphone uses supported Web Speech recognition and spoken answers use browser text-to-speech; support varies by browser and permission settings.

### Scheduled environment headline watch

`vercel.json` schedules `GET /api/environment-monitor` every 15 minutes. This requires a Vercel Pro or Enterprise plan; Hobby only supports one cron run per day. Vercel Cron sends the configured `CRON_SECRET` as a bearer token. An active signed-in campus member can also request a manual refresh from **Environment & news**. The route polls the official PIB RSS feed, screens release title and summary text for air quality, climate, water, environment, and extreme-weather terms, and stores only matched headline metadata. It deduplicates by source URL and removes records older than 60 days.

New rows appear in connected authenticated browser sessions through Supabase Realtime and remain listed as unread when users next sign in. Browser notifications require each person's permission and an open INFRAIQ session. This does not send SMS, email, or closed-browser push alerts; it does not monitor or transcribe TV/video. Headline keyword matches are contextual notices, not official hazard severity or proof of campus impact. Always open the linked publisher and consult local alerts.

## 6. Run the website

For the browser-only local demo, from the `infraiq` folder:

```powershell
python -m http.server 8000
```

Open `http://localhost:8000`. This static server does not run `/api/assistant`; chat may use the configured Supabase Edge Function, while document analysis and action planning require the Vercel route.

For local use of the full hosted feature set, copy `.env.example` to `.env.local`, enter the server-only Vercel variables there, configure `supabase-config.js`, then run `npx vercel dev` from the `infraiq` folder. Open the local URL printed by Vercel. The first account to create the campus becomes administrator. Subsequent users need an invitation created by an administrator or dean. Invite codes are one-time, email-bound, expire after seven days, and are shown once; share them privately through your institution’s approved channel. This bundle does not send invite emails.

## What is live after setup

- Email/password Auth and role-bound campus membership.
- Shared incident, shift, block, equipment, kitchen, and history records with database RLS.
- Shared maintenance work orders, tenant-protected image/PDF evidence, resource records, and server-side form write limits after migrations 001 through 005.
- Streamed OpenAI Responses API chat, campus health analysis, record search, image/PDF review, and human-reviewed work-order drafts after Vercel environment configuration.
- Realtime updates to open authenticated sessions. Browser desktop alerts need explicit permission and the website must stay open and connected.
- Admin/dean audit page containing change metadata without payload values.
- Leader-verified report XP, stored once in the campus membership row.
- Role-filtered hosted Copilot requests, limited to 20 calls per account per minute.
- Official PIB environment headline screening on a 15-minute Vercel schedule (Pro/Enterprise) with shared Supabase alerts after migration 006. CPCB, SAFAR, IITM, and IMD links in Environment & news open their publishers; the app does not invent AQI values or claim city coverage outside those portals.

The bundle does not configure SMS/WhatsApp dispatch, closed-browser push alerts, payroll attendance, automatic sensor collection, QR image generation, or continuous TV/video monitoring. The headline watcher needs migration 006, the server-only secrets, a deployed Vercel function, and Vercel Pro/Enterprise for 15-minute runs. Browser updates require an open session; source-feed outages can delay updates. The browser voice controls use browser speech services rather than a custom low-latency Realtime voice agent. AI work-order suggestions are drafts and require a person to review and submit them. The weekday traffic view uses only dated records; hourly counts are not collected. The campus schematic is not a surveyed route plan.

## Operational checklist

- Keep OpenAI and any privileged Supabase keys in server-side secrets only.
- Restrict `APP_ORIGINS` and use HTTPS in production.
- Verify RLS behavior with test accounts for each staff role before entering real institutional records.
- Configure backups, retention, access reviews, and billing limits in the Supabase/OpenAI projects.
- Use non-sensitive test data before opening the app to campus staff.
- Treat model answers and simple forecasts as advisory; use campus safety procedures and qualified staff for decisions.
