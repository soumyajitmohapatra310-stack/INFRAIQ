-- Public-source environmental headline metadata, shared with signed-in campus members.
-- Only the scheduled server route uses the service-role key to write. Never place it in browser code.
create table if not exists public.environment_alerts (
  id uuid primary key default gen_random_uuid(),
  source_id text not null unique check (char_length(source_id) between 1 and 700),
  source_name text not null check (char_length(source_name) between 1 and 160),
  title text not null check (char_length(title) between 1 and 300),
  summary text not null default '' check (char_length(summary) <= 480),
  url text not null check (url ~ '^https://(www\.)?pib\.gov\.in/'),
  topic text not null check (topic in ('air_quality','extreme_weather','climate','water','environment')),
  headline_flag boolean not null default false,
  published_at timestamptz,
  detected_at timestamptz not null default now()
);

create index if not exists environment_alerts_detected_at_idx
  on public.environment_alerts (detected_at desc);
create index if not exists environment_alerts_published_at_idx
  on public.environment_alerts (published_at desc nulls last);

alter table public.environment_alerts enable row level security;
revoke all on public.environment_alerts from anon, authenticated;
grant select on public.environment_alerts to authenticated;

drop policy if exists "Authenticated campus users can read public-source environment alerts" on public.environment_alerts;
create policy "Authenticated campus users can read public-source environment alerts"
  on public.environment_alerts for select to authenticated
  using (exists (
    select 1 from public.institution_members m
    where m.user_id = (select auth.uid()) and m.is_active
  ));

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'environment_alerts'
     ) then
    alter publication supabase_realtime add table public.environment_alerts;
  end if;
end $$;
