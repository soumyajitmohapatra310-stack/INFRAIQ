-- Server-side validation for every shared workspace record write.
-- Keeps the tenant/role rules and per-member write quota installed by migrations 001-004.

create or replace function public.guard_workspace_record_write()
returns trigger language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare
  v_user uuid := (select auth.uid());
  v_count integer;
  v_cutoff timestamptz := clock_timestamp() - interval '60 seconds';
  v_date_text text;
  v_record_date date;
  v_field record;
  v_value text;
begin
  if jsonb_typeof(new.payload) is distinct from 'object' then
    raise exception 'Workspace record payload must be a JSON object';
  end if;
  if octet_length(new.payload::text) > 4000000 then
    raise exception 'Workspace record payload exceeds the server limits';
  end if;
  select count(*) into v_count from jsonb_object_keys(new.payload);
  if v_count > 200 then raise exception 'Workspace record has too many fields'; end if;
  if nullif(btrim(coalesce(new.payload->>'website_url','')), '') is not null then
    raise exception 'Form verification failed';
  end if;

  for v_field in select key, value from jsonb_each(new.payload) loop
    if jsonb_typeof(v_field.value) = 'string' and length(v_field.value #>> '{}') > 12000 then
      raise exception 'A form field exceeds the 12,000 character limit';
    end if;
    if v_field.key in (
      'energyKwh','waterKl','temperatureC','occupancy','hvacHours','lightingHours',
      'gridKwh','solarKwh','batteryKwh','municipalKl','groundwaterKl','rainwaterKl',
      'preparedKg','wasteKg','meals','quantity','students','faculty','workers','labs',
      'instruments','area','campusSize','blockCount','latitude','longitude','hours',
      'value','expectedMinutes','xp','electricityTariff','alternativeTariff','floor'
    ) and v_field.value <> 'null'::jsonb then
      v_value := v_field.value #>> '{}';
      if v_value is not null and v_value <> '' then
        if v_field.key in ('temperatureC','latitude','longitude') then
          if v_value !~ '^-?[0-9]+(\.[0-9]+)?$' then raise exception 'A numeric form field is invalid'; end if;
        elsif v_value !~ '^[0-9]+(\.[0-9]+)?$' then
          raise exception 'A numeric form field is invalid';
        elsif v_value::numeric < 0 then
          raise exception 'Measurements and quantities cannot be negative';
        end if;
      end if;
    end if;
  end loop;

  if new.kind in ('institution_history','resource_source','resource_observation','kitchen') then
    v_date_text := coalesce(new.payload->>'date','');
    if v_date_text !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Enter a valid record date'; end if;
    begin
      v_record_date := v_date_text::date;
    exception when others then
      raise exception 'Enter a real calendar date';
    end;
    if v_record_date > current_date then raise exception 'Record dates cannot be in the future'; end if;
  end if;

  if new.kind = 'institution_history' then
    if coalesce(new.payload->>'category','') not in (
      'electricity','water','lab_condition','equipment_import','equipment_export',
      'chemical_import','chemical_export','traffic','entry_exit','occasion','holiday'
    ) or nullif(btrim(coalesce(new.payload->>'details','')),'') is null then
      raise exception 'History records need a supported category and details';
    end if;
    if new.payload->>'category' in ('electricity','water','traffic','equipment_import','equipment_export','chemical_import','chemical_export','entry_exit')
      and (nullif(new.payload->>'value','') is null or nullif(btrim(coalesce(new.payload->>'unit','')),'') is null) then
      raise exception 'Measured history needs a numeric value and unit';
    end if;
  elsif new.kind = 'equipment' then
    if nullif(btrim(coalesce(new.payload->>'name','')),'') is null
      or nullif(btrim(coalesce(new.payload->>'type','')),'') is null
      or coalesce(new.payload->>'quantity','') !~ '^[1-9][0-9]*$' then
      raise exception 'Equipment needs a name, type, and positive whole-number quantity';
    end if;
    if nullif(new.payload->>'maintenanceDue','') is not null then
      if new.payload->>'maintenanceDue' !~ '^\d{4}-\d{2}-\d{2}$' then raise exception 'Enter a valid preventive-maintenance date'; end if;
      begin
        perform (new.payload->>'maintenanceDue')::date;
      exception when others then
        raise exception 'Enter a real preventive-maintenance date';
      end;
    end if;
  elsif new.kind = 'block' then
    if nullif(btrim(coalesce(new.payload->>'name','')),'') is null then raise exception 'Campus blocks need a name'; end if;
  elsif new.kind = 'incident' then
    if nullif(btrim(coalesce(new.payload->>'title','')),'') is null
      or nullif(btrim(coalesce(new.payload->>'description','')),'') is null then
      raise exception 'Incident reports need a title and description';
    end if;
  elsif new.kind = 'maintenance_ticket' then
    if nullif(btrim(coalesce(new.payload->>'title','')),'') is null then raise exception 'Maintenance work orders need a title'; end if;
  elsif new.kind = 'kitchen' then
    if nullif(new.payload->>'preparedKg','') is null or nullif(new.payload->>'wasteKg','') is null or nullif(new.payload->>'meals','') is null then
      raise exception 'Kitchen records need prepared, waste, and meals-served measurements';
    end if;
    if (new.payload->>'wasteKg')::numeric > (new.payload->>'preparedKg')::numeric then
      raise exception 'Kitchen waste cannot exceed prepared food';
    end if;
  elsif new.kind = 'resource_source' then
    if not (new.payload ?| array['gridKwh','solarKwh','batteryKwh','municipalKl','groundwaterKl','rainwaterKl'])
      or not exists (
        select 1 from jsonb_each(new.payload) as f(key,value)
        where f.key in ('gridKwh','solarKwh','batteryKwh','municipalKl','groundwaterKl','rainwaterKl')
          and f.value <> 'null'::jsonb and coalesce(f.value #>> '{}','') <> ''
      ) then
      raise exception 'Source records need at least one measured electricity or water value';
    end if;
  elsif new.kind = 'resource_observation' then
    if coalesce(new.payload->>'time','') !~ '^([01]\d|2[0-3]):[0-5]\d$'
      or coalesce(new.payload->>'block','') !~ '^[^<>]{1,120}$'
      or coalesce(new.payload->>'floor','') !~ '^\d{1,2}$'
      or (nullif(new.payload->>'energyKwh','') is null and nullif(new.payload->>'waterKl','') is null) then
      raise exception 'Resource observations need a valid time, building, floor, and energy or water reading';
    end if;
    if (new.payload->>'floor')::integer not between 1 and 99 then raise exception 'Floor number must be between 1 and 99'; end if;
    if (nullif(new.payload->>'hvacHours','') is not null and (new.payload->>'hvacHours')::numeric > 24)
      or (nullif(new.payload->>'lightingHours','') is not null and (new.payload->>'lightingHours')::numeric > 24) then
      raise exception 'Equipment runtime must be at most 24 hours';
    end if;
  elsif new.kind = 'simulation_run' then
    if coalesce((new.payload->>'synthetic')::boolean,false) is not true
      or jsonb_typeof(new.payload->'rows') is distinct from 'array' then
      raise exception 'Scenario runs must be labeled synthetic and contain an interval list';
    end if;
    if jsonb_array_length(new.payload->'rows') not between 1 and 12000 then
      raise exception 'Scenario interval list is outside the allowed size';
    end if;
  end if;

  if v_user is null then return new; end if;
  insert into public.workspace_write_quotas(institution_id,user_id,window_started_at,write_count)
    values(new.institution_id,v_user,clock_timestamp(),1)
    on conflict(institution_id,user_id) do update set
      window_started_at=case when workspace_write_quotas.window_started_at < v_cutoff then clock_timestamp() else workspace_write_quotas.window_started_at end,
      write_count=case when workspace_write_quotas.window_started_at < v_cutoff then 1 else workspace_write_quotas.write_count+1 end
    returning write_count into v_count;
  if v_count > 120 then raise exception 'Campus record write limit reached. Wait one minute and try again.'; end if;
  return new;
end;
$$;

comment on function public.guard_workspace_record_write() is 'Server-side workspace form validation and authenticated per-member write limiting.';
