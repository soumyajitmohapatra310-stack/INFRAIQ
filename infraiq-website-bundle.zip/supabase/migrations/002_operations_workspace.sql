-- Add the operation modules without removing or changing existing record kinds.
alter table public.institutions
  add column if not exists electricity_tariff numeric
  check (electricity_tariff is null or electricity_tariff >= 0);
alter table public.institutions
  add column if not exists usage_alert_threshold_pct integer not null default 25
  check (usage_alert_threshold_pct between 5 and 200);

alter table public.workspace_records
  drop constraint if exists workspace_records_kind_check;
alter table public.workspace_records
  add constraint workspace_records_kind_check
  check (kind in ('block','equipment','incident','maintenance_ticket','active_shift','completed_shift','kitchen','institution_history'));

create or replace function public.infraiq_can_read_record(p_institution_id uuid, p_kind text, p_owner_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind in ('incident','maintenance_ticket') then true
    when p_kind in ('active_shift','completed_shift') then p_owner_id = (select auth.uid())
    when p_kind = 'block' then true
    when p_kind in ('equipment','institution_history') then public.infraiq_role(p_institution_id) in ('environmental','warden')
    when p_kind = 'kitchen' then public.infraiq_role(p_institution_id) = 'kitchen'
    else false
  end;
$$;

create or replace function public.infraiq_can_insert_record(p_institution_id uuid, p_kind text)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind in ('incident','maintenance_ticket','active_shift') then true
    when p_kind = 'completed_shift' then public.infraiq_role(p_institution_id) in ('admin','dean')
    when p_kind = 'kitchen' then public.infraiq_role(p_institution_id) in ('admin','dean','kitchen')
    when p_kind in ('block','equipment','institution_history') then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    else false
  end;
$$;

create or replace function public.infraiq_can_update_record(
  p_institution_id uuid, p_kind text, p_owner_id uuid, p_payload jsonb
) returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind in ('incident','maintenance_ticket') and p_payload->>'assignedTo' = (
      select lower(p.work_email) from public.profiles p where p.user_id = (select auth.uid())
    ) then true
    when p_kind in ('active_shift','completed_shift') and p_owner_id = (select auth.uid()) then true
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind = 'incident' and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind in ('block','equipment','institution_history','maintenance_ticket') and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind = 'kitchen' and public.infraiq_role(p_institution_id) = 'kitchen' then true
    else false
  end;
$$;

create or replace function public.infraiq_can_delete_record(p_institution_id uuid, p_kind text, p_owner_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind in ('block','equipment','institution_history') and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind = 'kitchen' and public.infraiq_role(p_institution_id) = 'kitchen' then true
    else false
  end;
$$;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('infraiq-evidence','infraiq-evidence',false,8388608,array['image/jpeg','image/png','image/webp','image/heic','image/heif','application/pdf'])
on conflict (id) do update set public=false,file_size_limit=8388608,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists infraiq_evidence_tenant_read on storage.objects;
create policy infraiq_evidence_tenant_read on storage.objects for select to authenticated
using (bucket_id='infraiq-evidence' and exists (
  select 1 from public.institution_members m
  where m.institution_id::text=(storage.foldername(name))[1] and m.user_id=(select auth.uid()) and m.is_active
));
drop policy if exists infraiq_evidence_tenant_upload on storage.objects;
create policy infraiq_evidence_tenant_upload on storage.objects for insert to authenticated
with check (bucket_id='infraiq-evidence' and exists (
  select 1 from public.institution_members m
  where m.institution_id::text=(storage.foldername(name))[1] and m.user_id=(select auth.uid()) and m.is_active
));
