-- Separate simulated scenario runs from actual measured resource-source records.
-- All remain tenant-scoped. Any active member may read and create these records;
-- a member may update/delete only their own simulations, while source ledger
-- corrections remain limited to campus leadership and operations managers.

alter table public.workspace_records
  drop constraint if exists workspace_records_kind_check;
alter table public.workspace_records
  add constraint workspace_records_kind_check
  check (kind in ('block','equipment','incident','maintenance_ticket','active_shift','completed_shift','kitchen','institution_history','simulation_run','resource_source','resource_observation'));

create or replace function public.infraiq_can_read_record(p_institution_id uuid, p_kind text, p_owner_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind in ('simulation_run','resource_source','resource_observation') then true
    when p_kind = 'incident' then true
    when p_kind = 'maintenance_ticket' then true
    when p_kind in ('active_shift','completed_shift') then p_owner_id = (select auth.uid())
    when p_kind = 'block' then true
    when p_kind in ('equipment','institution_history') then public.infraiq_role(p_institution_id) in ('environmental','warden')
    when p_kind = 'kitchen' then public.infraiq_role(p_institution_id) = 'kitchen'
    else false
  end;
$$;

create or replace function public.infraiq_can_insert_record(p_institution_id uuid, p_kind text)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind in ('simulation_run','resource_source','resource_observation') then true
    when p_kind in ('incident','maintenance_ticket','active_shift') then true
    when p_kind = 'completed_shift' then public.infraiq_role(p_institution_id) in ('admin','dean')
    when p_kind = 'kitchen' then public.infraiq_role(p_institution_id) in ('admin','dean','kitchen')
    when p_kind in ('block','equipment','institution_history') then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    else false
  end;
$$;

create or replace function public.infraiq_can_update_record(
  p_institution_id uuid, p_kind text, p_owner_id uuid, p_payload jsonb
) returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind = 'simulation_run' then p_owner_id = (select auth.uid())
    when p_kind = 'resource_source' then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    when p_kind = 'resource_observation' then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    when p_kind in ('incident','maintenance_ticket') and p_payload->>'assignedTo' = (
      select lower(p.work_email) from public.profiles p where p.user_id = (select auth.uid())
    ) then true
    when p_kind in ('active_shift','completed_shift') and p_owner_id = (select auth.uid()) then true
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind = 'incident' and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind in ('block','equipment','institution_history','maintenance_ticket') and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind = 'kitchen' and public.infraiq_role(p_institution_id) = 'kitchen' then true
    else false
  end;
$$;

create or replace function public.infraiq_can_delete_record(p_institution_id uuid, p_kind text, p_owner_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind = 'simulation_run' then p_owner_id = (select auth.uid())
    when p_kind = 'resource_source' then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    when p_kind = 'resource_observation' then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind in ('block','equipment','institution_history') and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind = 'kitchen' and public.infraiq_role(p_institution_id) = 'kitchen' then true
    else false
  end;
$$;

comment on function public.infraiq_can_read_record(uuid,text,uuid) is 'Role-aware tenant access for campus records including separate synthetic scenarios, resource-source records, and actual interval observations.';
