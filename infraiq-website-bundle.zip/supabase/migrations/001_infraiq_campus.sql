-- INFRAIQ multi-tenant campus workspace
-- Run in the Supabase SQL Editor or with `supabase db push`.
-- No service-role key is used by the browser. All exposed data tables use RLS.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.institutions (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) between 2 and 180),
  city text not null check (length(btrim(city)) between 1 and 120),
  region text not null check (length(btrim(region)) between 1 and 120),
  address text not null default '',
  latitude double precision check (latitude is null or latitude between -90 and 90),
  longitude double precision check (longitude is null or longitude between -180 and 180),
  campus_size numeric check (campus_size is null or campus_size >= 0),
  block_count integer check (block_count is null or block_count >= 0),
  electricity_tariff numeric check (electricity_tariff is null or electricity_tariff >= 0),
  usage_alert_threshold_pct integer not null default 25 check (usage_alert_threshold_pct between 5 and 200),
  opening time,
  closing time,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  work_email text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.institution_members (
  institution_id uuid not null references public.institutions(id) on delete cascade,
  user_id uuid not null references public.profiles(user_id) on delete cascade,
  role text not null check (role in ('admin','environmental','dean','warden','security','worker','kitchen')),
  block text not null default '',
  info_xp integer not null default 0 check (info_xp >= 0),
  is_active boolean not null default true,
  joined_at timestamptz not null default now(),
  primary key (institution_id, user_id),
  unique (user_id)
);

create table if not exists public.workspace_invites (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  invited_email text not null,
  invited_name text not null default '',
  invited_role text not null check (invited_role in ('admin','environmental','dean','warden','security','worker','kitchen')),
  block text not null default '',
  code_hash text not null unique,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '7 days'),
  claimed_at timestamptz,
  claimed_by uuid references auth.users(id),
  constraint workspace_invites_email_normalized check (invited_email = lower(btrim(invited_email)))
);
create index if not exists workspace_invites_pending_idx
  on public.workspace_invites (institution_id, invited_email) where claimed_at is null;

create table if not exists public.workspace_records (
  institution_id uuid not null references public.institutions(id) on delete cascade,
  id text not null check (length(id) between 1 and 160),
  kind text not null check (kind in ('block','equipment','incident','maintenance_ticket','active_shift','completed_shift','kitchen','institution_history')),
  owner_id uuid not null references auth.users(id),
  payload jsonb not null default '{}'::jsonb check (jsonb_typeof(payload) = 'object'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (institution_id, id),
  constraint one_open_shift_per_member unique (institution_id, owner_id, kind)
    deferrable initially immediate
);
create index if not exists workspace_records_kind_time_idx
  on public.workspace_records (institution_id, kind, created_at desc);
create index if not exists workspace_records_owner_idx
  on public.workspace_records (institution_id, owner_id, kind);

create table if not exists public.workspace_audit_log (
  id uuid primary key default gen_random_uuid(),
  institution_id uuid not null references public.institutions(id) on delete cascade,
  record_id text not null,
  record_kind text not null,
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  actor_id uuid references auth.users(id) on delete set null,
  changed_fields text[] not null default '{}',
  occurred_at timestamptz not null default now()
);
create index if not exists workspace_audit_time_idx on public.workspace_audit_log(institution_id,occurred_at desc);

-- One active shift per worker; the uniqueness rule above is enforced only for open shifts.
alter table public.workspace_records drop constraint if exists one_open_shift_per_member;
create unique index if not exists one_open_shift_per_member
  on public.workspace_records (institution_id, owner_id)
  where kind = 'active_shift';

create table if not exists public.copilot_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  minute_bucket timestamptz not null,
  request_count integer not null default 0,
  primary key (user_id, minute_bucket)
);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = public, pg_temp as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists institutions_touch_updated_at on public.institutions;
create trigger institutions_touch_updated_at before update on public.institutions
for each row execute function public.touch_updated_at();
drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles
for each row execute function public.touch_updated_at();

create or replace function public.handle_new_auth_user()
returns trigger language plpgsql security definer set search_path = public, auth, pg_temp as $$
begin
  insert into public.profiles(user_id, full_name, work_email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(lower(new.email),''))
  on conflict (user_id) do update set
    full_name = case when excluded.full_name = '' then public.profiles.full_name else excluded.full_name end,
    work_email = excluded.work_email;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_infraiq on auth.users;
create trigger on_auth_user_created_infraiq after insert on auth.users
for each row execute function public.handle_new_auth_user();

create or replace function public.infraiq_is_member(p_institution_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select exists (
    select 1 from public.institution_members m
    where m.institution_id = p_institution_id and m.user_id = (select auth.uid()) and m.is_active
  );
$$;

create or replace function public.infraiq_role(p_institution_id uuid)
returns text language sql stable security definer set search_path = public, auth, pg_temp as $$
  select m.role from public.institution_members m
  where m.institution_id = p_institution_id and m.user_id = (select auth.uid()) and m.is_active
  limit 1;
$$;

create or replace function public.infraiq_can_manage(p_institution_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select coalesce(public.infraiq_role(p_institution_id) in ('admin','dean'), false);
$$;

create or replace function public.infraiq_can_read_record(p_institution_id uuid, p_kind text, p_owner_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind = 'incident' then true
    when p_kind = 'maintenance_ticket' then true
    when p_kind in ('active_shift','completed_shift') then p_owner_id = (select auth.uid())
    when p_kind = 'block' then true
    when p_kind in ('equipment','institution_history') then public.infraiq_role(p_institution_id) in ('environmental','warden')
    when p_kind = 'kitchen' then public.infraiq_role(p_institution_id) = 'kitchen'
    else false
  end;
$$;

create or replace function public.infraiq_can_insert_record(p_institution_id uuid, p_kind text)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind = 'incident' then true
    when p_kind = 'maintenance_ticket' then true
    when p_kind = 'active_shift' then true
    when p_kind = 'completed_shift' then public.infraiq_role(p_institution_id) in ('admin','dean')
    when p_kind = 'kitchen' then public.infraiq_role(p_institution_id) in ('admin','dean','kitchen')
    when p_kind in ('block','equipment','institution_history') then public.infraiq_role(p_institution_id) in ('admin','dean','environmental','warden')
    else false
  end;
$$;

create or replace function public.infraiq_can_update_record(
  p_institution_id uuid, p_kind text, p_owner_id uuid, p_payload jsonb
) returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when p_kind in ('incident','maintenance_ticket') and p_payload->>'assignedTo' = (
      select lower(p.work_email) from public.profiles p where p.user_id = (select auth.uid())
    ) then true
    when p_kind in ('active_shift','completed_shift') and p_owner_id = (select auth.uid()) then true
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind = 'incident' and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind in ('block','equipment','institution_history','maintenance_ticket') and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind = 'kitchen' and public.infraiq_role(p_institution_id) = 'kitchen' then true
    else false
  end;
$$;

create or replace function public.infraiq_can_delete_record(p_institution_id uuid, p_kind text, p_owner_id uuid)
returns boolean language sql stable security definer set search_path = public, auth, pg_temp as $$
  select case
    when not public.infraiq_is_member(p_institution_id) then false
    when public.infraiq_role(p_institution_id) in ('admin','dean') then true
    when p_kind in ('block','equipment','institution_history') and public.infraiq_role(p_institution_id) in ('environmental','warden') then true
    when p_kind = 'kitchen' and public.infraiq_role(p_institution_id) = 'kitchen' then true
    else false
  end;
$$;

create or replace function public.enforce_workspace_record()
returns trigger language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare v_shift_start timestamptz; v_shift_end timestamptz;
begin
  if tg_op = 'INSERT' then
    new.owner_id := (select auth.uid());
    new.created_at := now();
    if new.kind = 'incident' then
      new.payload := jsonb_set(new.payload, '{reporterEmail}', to_jsonb(coalesce(auth.jwt()->>'email','')), true);
      new.payload := jsonb_set(new.payload, '{status}', '"Submitted"'::jsonb, true);
      new.payload := jsonb_set(new.payload, '{verified}', 'false'::jsonb, true);
      new.payload := new.payload - 'verifiedAt' - 'verifiedBy' - 'xp';
    end if;
    if new.kind = 'active_shift' then
      new.payload := jsonb_set(new.payload, '{startedAt}', to_jsonb(clock_timestamp()::text), true);
    elsif new.kind = 'completed_shift' and not public.infraiq_can_manage(new.institution_id) then
      raise exception 'Staff must complete a shift that was started in the campus workspace';
    end if;
  else
    new.owner_id := old.owner_id;
    new.created_at := old.created_at;
    if old.kind = 'active_shift' and new.kind not in ('active_shift','completed_shift') and not public.infraiq_can_manage(new.institution_id) then
      raise exception 'A running shift cannot be changed into another record type';
    end if;
    if old.kind = 'completed_shift' and not public.infraiq_can_manage(new.institution_id)
      and (new.kind is distinct from old.kind or new.payload is distinct from old.payload) then
      raise exception 'Completed shift records require leader correction';
    end if;
    if old.kind = 'active_shift' and new.kind = 'active_shift' and not public.infraiq_can_manage(new.institution_id) then
      new.payload := jsonb_set(new.payload, '{startedAt}', old.payload->'startedAt', true);
    end if;
    if old.kind = 'active_shift' and new.kind = 'completed_shift' and not public.infraiq_can_manage(new.institution_id) then
      v_shift_start := nullif(old.payload->>'startedAt','')::timestamptz;
      if v_shift_start is null then raise exception 'The shift start time is unavailable'; end if;
      v_shift_end := clock_timestamp();
      new.payload := jsonb_set(new.payload, '{startedAt}', to_jsonb(v_shift_start::text), true);
      new.payload := jsonb_set(new.payload, '{endedAt}', to_jsonb(v_shift_end::text), true);
      new.payload := jsonb_set(new.payload, '{hours}', to_jsonb(greatest(0::numeric, extract(epoch from (v_shift_end-v_shift_start))/3600)), true);
      new.payload := new.payload - 'elapsedMs';
    end if;
    if new.kind = 'incident' and old.kind = 'incident' then
      new.payload := jsonb_set(new.payload, '{reporterEmail}', old.payload->'reporterEmail', true);
      if not public.infraiq_can_manage(new.institution_id) then
        new.payload := jsonb_set(new.payload, '{verified}', coalesce(old.payload->'verified','false'::jsonb), true);
        if old.payload ? 'verifiedAt' then new.payload := jsonb_set(new.payload, '{verifiedAt}', old.payload->'verifiedAt', true); end if;
        if old.payload ? 'verifiedBy' then new.payload := jsonb_set(new.payload, '{verifiedBy}', old.payload->'verifiedBy', true); end if;
      end if;
    end if;
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists workspace_records_enforce on public.workspace_records;
create trigger workspace_records_enforce before insert or update on public.workspace_records
for each row execute function public.enforce_workspace_record();

create or replace function public.audit_workspace_record()
returns trigger language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare v_institution uuid; v_record text; v_kind text; v_fields text[] := '{}'; v_action text := tg_op;
begin
  if tg_op='DELETE' then
    v_institution:=old.institution_id;v_record:=old.id;v_kind:=old.kind;
  else
    v_institution:=new.institution_id;v_record:=new.id;v_kind:=new.kind;
  end if;
  if tg_op='INSERT' then
    select coalesce(array_agg(field order by field),'{}'::text[]) into v_fields
      from jsonb_object_keys(new.payload) as fields(field);
  elsif tg_op='UPDATE' then
    select coalesce(array_agg(changes.field order by changes.field),'{}'::text[]) into v_fields
      from (
        select coalesce(n.field,o.field) as field
        from jsonb_each(coalesce(new.payload,'{}'::jsonb)) as n(field,value)
        full outer join jsonb_each(coalesce(old.payload,'{}'::jsonb)) as o(field,value) using(field)
        where n.value is distinct from o.value
      ) as changes;
    if old.kind is distinct from new.kind then v_fields:=array_prepend('kind',v_fields); end if;
  else
    select coalesce(array_agg(field order by field),'{}'::text[]) into v_fields
      from jsonb_object_keys(old.payload) as fields(field);
    v_fields:=array_prepend('record',v_fields);
  end if;
  insert into public.workspace_audit_log(institution_id,record_id,record_kind,action,actor_id,changed_fields)
  values(v_institution,v_record,v_kind,v_action,(select auth.uid()),v_fields);
  if tg_op='DELETE' then return old; else return new; end if;
end;
$$;
drop trigger if exists workspace_records_audit on public.workspace_records;
create trigger workspace_records_audit after insert or update or delete on public.workspace_records
for each row execute function public.audit_workspace_record();

create or replace function public.create_infraiq_institution(
  p_name text, p_city text, p_region text, p_address text default '',
  p_campus_size numeric default null, p_block_count integer default null,
  p_opening time default '08:00', p_closing time default '18:00', p_full_name text default ''
) returns uuid language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare v_user uuid := (select auth.uid()); v_id uuid;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if exists (select 1 from public.institution_members where user_id=v_user and is_active) then
    raise exception 'This account already belongs to a campus workspace';
  end if;
  if length(btrim(coalesce(p_name,''))) < 2 or length(btrim(coalesce(p_city,''))) < 1 or length(btrim(coalesce(p_region,''))) < 1 then
    raise exception 'Institution name, city, and region are required';
  end if;
  insert into public.institutions(name,city,region,address,campus_size,block_count,opening,closing,created_by)
  values (btrim(p_name),btrim(p_city),btrim(p_region),coalesce(p_address,''),p_campus_size,p_block_count,p_opening,p_closing,v_user)
  returning id into v_id;
  insert into public.profiles(user_id,full_name,work_email)
  values (v_user,coalesce(nullif(btrim(p_full_name),''),''),coalesce(lower(auth.jwt()->>'email'),''))
  on conflict (user_id) do update set full_name=excluded.full_name,work_email=excluded.work_email;
  insert into public.institution_members(institution_id,user_id,role) values(v_id,v_user,'admin');
  return v_id;
end;
$$;

create or replace function public.create_infraiq_invite(
  p_email text, p_name text, p_role text, p_block text default ''
) returns jsonb language plpgsql security definer set search_path = public, auth, extensions, pg_temp as $$
declare v_institution uuid; v_code text; v_invite uuid;
begin
  select institution_id into v_institution from public.institution_members
  where user_id=(select auth.uid()) and is_active limit 1;
  if v_institution is null or not public.infraiq_can_manage(v_institution) then raise exception 'Only an institution administrator or dean can invite crew'; end if;
  if lower(btrim(coalesce(p_email,''))) !~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' then raise exception 'Enter a valid work email'; end if;
  if p_role not in ('admin','environmental','dean','warden','security','worker','kitchen') then raise exception 'Invalid campus role'; end if;
  delete from public.workspace_invites where institution_id=v_institution and invited_email=lower(btrim(p_email)) and claimed_at is null;
  v_code := encode(extensions.gen_random_bytes(24),'hex');
  insert into public.workspace_invites(institution_id,invited_email,invited_name,invited_role,block,code_hash,created_by)
  values(v_institution,lower(btrim(p_email)),btrim(coalesce(p_name,'')),p_role,coalesce(p_block,''),encode(extensions.digest(v_code,'sha256'),'hex'),(select auth.uid()))
  returning id into v_invite;
  return jsonb_build_object('invite_id',v_invite,'email',lower(btrim(p_email)),'role',p_role,'code',v_code,'expires_at',now()+interval '7 days');
end;
$$;

create or replace function public.claim_infraiq_invite(p_code text, p_full_name text default '')
returns jsonb language plpgsql security definer set search_path = public, auth, extensions, pg_temp as $$
declare v_user uuid := (select auth.uid()); v_email text := lower(coalesce(auth.jwt()->>'email','')); v_invite public.workspace_invites%rowtype;
begin
  if v_user is null or v_email = '' then raise exception 'Sign in with your invited email first'; end if;
  select * into v_invite from public.workspace_invites
  where code_hash=encode(extensions.digest(coalesce(p_code,''),'sha256'),'hex')
    and invited_email=v_email and claimed_at is null and expires_at>now()
  for update;
  if not found then raise exception 'Invitation is invalid, expired, already used, or for another email'; end if;
  if exists (select 1 from public.institution_members where user_id=v_user and is_active) then raise exception 'This account already belongs to an institution'; end if;
  insert into public.profiles(user_id,full_name,work_email)
  values(v_user,coalesce(nullif(btrim(p_full_name),''),v_invite.invited_name),v_email)
  on conflict (user_id) do update set full_name=coalesce(nullif(excluded.full_name,''),public.profiles.full_name),work_email=excluded.work_email;
  insert into public.institution_members(institution_id,user_id,role,block)
  values(v_invite.institution_id,v_user,v_invite.invited_role,v_invite.block);
  update public.workspace_invites set claimed_at=now(),claimed_by=v_user where id=v_invite.id;
  return jsonb_build_object('institution_id',v_invite.institution_id,'role',v_invite.invited_role,'block',v_invite.block);
end;
$$;

create or replace function public.verify_infraiq_report(p_institution_id uuid, p_record_id text)
returns jsonb language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare v_record public.workspace_records%rowtype; v_xp integer := 10;
begin
  if not public.infraiq_can_manage(p_institution_id) then raise exception 'Leader permission required to verify reports'; end if;
  select * into v_record from public.workspace_records
  where institution_id=p_institution_id and id=p_record_id and kind='incident' for update;
  if not found then raise exception 'Incident report not found'; end if;
  if coalesce((v_record.payload->>'verified')::boolean,false) then
    return jsonb_build_object('already_verified',true,'xp_awarded',0);
  end if;
  update public.workspace_records set payload=jsonb_set(
    jsonb_set(jsonb_set(v_record.payload,'{verified}','true'::jsonb,true),'{verifiedAt}',to_jsonb(now()::text),true),
    '{verifiedBy}',to_jsonb(coalesce(auth.jwt()->>'email','')),true)
  where institution_id=p_institution_id and id=p_record_id;
  update public.institution_members set info_xp=info_xp+v_xp
  where institution_id=p_institution_id and user_id=v_record.owner_id;
  return jsonb_build_object('already_verified',false,'xp_awarded',v_xp,'member_id',v_record.owner_id);
end;
$$;

create or replace function public.consume_infraiq_copilot_quota()
returns boolean language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare v_user uuid := (select auth.uid()); v_bucket timestamptz := date_trunc('minute',now()); v_count integer;
begin
  if v_user is null then return false; end if;
  delete from public.copilot_usage where minute_bucket < now()-interval '2 days';
  insert into public.copilot_usage(user_id,minute_bucket,request_count) values(v_user,v_bucket,1)
  on conflict (user_id,minute_bucket) do update set request_count=public.copilot_usage.request_count+1
  where public.copilot_usage.request_count < 20
  returning request_count into v_count;
  return v_count is not null;
end;
$$;

-- Least-privilege table access, followed by explicit RLS policies.
alter table public.institutions enable row level security;
alter table public.profiles enable row level security;
alter table public.institution_members enable row level security;
alter table public.workspace_invites enable row level security;
alter table public.workspace_records enable row level security;
alter table public.workspace_audit_log enable row level security;
alter table public.copilot_usage enable row level security;

revoke all on public.institutions,public.profiles,public.institution_members,public.workspace_invites,public.workspace_records,public.workspace_audit_log,public.copilot_usage from anon, authenticated;
grant select on public.institutions,public.profiles,public.institution_members,public.workspace_records,public.workspace_audit_log to authenticated;
grant update (name,city,region,address,latitude,longitude,campus_size,block_count,opening,closing) on public.institutions to authenticated;
grant update (full_name) on public.profiles to authenticated;
grant insert,update,delete on public.workspace_records to authenticated;
grant select on public.workspace_invites to authenticated;

drop policy if exists institution_member_read on public.institutions;
create policy institution_member_read on public.institutions for select to authenticated using (public.infraiq_is_member(id));
drop policy if exists institution_leader_update on public.institutions;
create policy institution_leader_update on public.institutions for update to authenticated using (public.infraiq_can_manage(id)) with check (public.infraiq_can_manage(id));

drop policy if exists profile_self_or_coworker_read on public.profiles;
create policy profile_self_or_coworker_read on public.profiles for select to authenticated using (
  user_id=(select auth.uid()) or exists (
    select 1 from public.institution_members me join public.institution_members coworker using(institution_id)
    where me.user_id=(select auth.uid()) and me.is_active and coworker.user_id=profiles.user_id and coworker.is_active
  )
);
drop policy if exists profile_self_update on public.profiles;
create policy profile_self_update on public.profiles for update to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));

drop policy if exists members_same_workspace_read on public.institution_members;
create policy members_same_workspace_read on public.institution_members for select to authenticated using (
  user_id=(select auth.uid()) or public.infraiq_is_member(institution_id)
);

drop policy if exists invites_leader_read on public.workspace_invites;
create policy invites_leader_read on public.workspace_invites for select to authenticated using (public.infraiq_can_manage(institution_id));

drop policy if exists workspace_records_scoped_read on public.workspace_records;
create policy workspace_records_scoped_read on public.workspace_records for select to authenticated
using (public.infraiq_can_read_record(institution_id,kind,owner_id));
drop policy if exists workspace_records_scoped_insert on public.workspace_records;
create policy workspace_records_scoped_insert on public.workspace_records for insert to authenticated
with check (owner_id=(select auth.uid()) and public.infraiq_can_insert_record(institution_id,kind));
drop policy if exists workspace_records_scoped_update on public.workspace_records;
create policy workspace_records_scoped_update on public.workspace_records for update to authenticated
using (public.infraiq_can_update_record(institution_id,kind,owner_id,payload))
with check (public.infraiq_can_update_record(institution_id,kind,owner_id,payload));
drop policy if exists workspace_records_scoped_delete on public.workspace_records;
create policy workspace_records_scoped_delete on public.workspace_records for delete to authenticated
using (public.infraiq_can_delete_record(institution_id,kind,owner_id));

-- Private incident evidence: tenant ID is the first object-key folder.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('infraiq-evidence','infraiq-evidence',false,8388608,array['image/jpeg','image/png','image/webp','image/heic','image/heif','application/pdf'])
on conflict (id) do update set public=false,file_size_limit=8388608,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists infraiq_evidence_tenant_read on storage.objects;
create policy infraiq_evidence_tenant_read on storage.objects for select to authenticated
using (bucket_id='infraiq-evidence' and exists (
  select 1 from public.institution_members m
  where m.institution_id::text=(storage.foldername(name))[1] and m.user_id=(select auth.uid()) and m.is_active
));
drop policy if exists infraiq_evidence_tenant_upload on storage.objects;
create policy infraiq_evidence_tenant_upload on storage.objects for insert to authenticated
with check (bucket_id='infraiq-evidence' and exists (
  select 1 from public.institution_members m
  where m.institution_id::text=(storage.foldername(name))[1] and m.user_id=(select auth.uid()) and m.is_active
));
drop policy if exists audit_leader_read on public.workspace_audit_log;
create policy audit_leader_read on public.workspace_audit_log for select to authenticated
using (public.infraiq_can_manage(institution_id));

-- No direct access to AI quota rows. Only the authenticated quota RPC may change them.
revoke all on function public.infraiq_is_member(uuid) from public, anon;
revoke all on function public.infraiq_role(uuid) from public, anon;
revoke all on function public.infraiq_can_manage(uuid) from public, anon;
revoke all on function public.infraiq_can_read_record(uuid,text,uuid) from public, anon;
revoke all on function public.infraiq_can_insert_record(uuid,text) from public, anon;
revoke all on function public.infraiq_can_update_record(uuid,text,uuid,jsonb) from public, anon;
revoke all on function public.infraiq_can_delete_record(uuid,text,uuid) from public, anon;
revoke all on function public.create_infraiq_institution(text,text,text,text,numeric,integer,time,time,text) from public, anon;
revoke all on function public.create_infraiq_invite(text,text,text,text) from public, anon;
revoke all on function public.claim_infraiq_invite(text,text) from public, anon;
revoke all on function public.verify_infraiq_report(uuid,text) from public, anon;
revoke all on function public.consume_infraiq_copilot_quota() from public, anon;
grant execute on function public.infraiq_is_member(uuid),public.infraiq_role(uuid),public.infraiq_can_manage(uuid) to authenticated;
grant execute on function public.infraiq_can_read_record(uuid,text,uuid),public.infraiq_can_insert_record(uuid,text),public.infraiq_can_update_record(uuid,text,uuid,jsonb),public.infraiq_can_delete_record(uuid,text,uuid) to authenticated;
grant execute on function public.create_infraiq_institution(text,text,text,text,numeric,integer,time,time,text) to authenticated;
grant execute on function public.create_infraiq_invite(text,text,text,text),public.claim_infraiq_invite(text,text),public.verify_infraiq_report(uuid,text),public.consume_infraiq_copilot_quota() to authenticated;

-- Enable Realtime notifications for cross-device incident reports and shared records.
do $$ begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime') then
    if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='workspace_records') then
      execute 'alter publication supabase_realtime add table public.workspace_records';
    end if;
    if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='institution_members') then
      execute 'alter publication supabase_realtime add table public.institution_members';
    end if;
    if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='institutions') then
      execute 'alter publication supabase_realtime add table public.institutions';
    end if;
  end if;
end $$;

comment on table public.workspace_records is 'Tenant-scoped operational records. Access is enforced by membership and role-aware RLS policies.';
comment on table public.institution_members is 'One authenticated account per campus workspace; role permissions are checked in PostgreSQL, not trusted from the UI.';
comment on table public.workspace_audit_log is 'Append-only record change metadata. Payloads and sensitive field values are deliberately omitted.';
comment on function public.consume_infraiq_copilot_quota() is 'Per-user limit of 20 hosted Copilot requests per minute.';
