-- Database-side request limits for authenticated workspace form writes.
-- This protects shared Supabase records; local browser-demo mode is not secure.

create table if not exists public.workspace_write_quotas (
  institution_id uuid not null references public.institutions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  window_started_at timestamptz not null default now(),
  write_count integer not null default 0 check (write_count >= 0),
  primary key (institution_id,user_id)
);
alter table public.workspace_write_quotas enable row level security;
revoke all on public.workspace_write_quotas from anon, authenticated;

create or replace function public.guard_workspace_record_write()
returns trigger language plpgsql security definer set search_path = public, auth, pg_temp as $$
declare
  v_user uuid := (select auth.uid());
  v_count integer;
  v_cutoff timestamptz := clock_timestamp() - interval '60 seconds';
  v_observation_date date;
begin
  if jsonb_typeof(new.payload) is distinct from 'object' then
    raise exception 'Workspace record payload must be a JSON object';
  end if;
  if octet_length(new.payload::text) > 4000000 then
    raise exception 'Workspace record payload exceeds the 4 MB limit';
  end if;

  if new.kind = 'resource_observation' then
    if coalesce(new.payload->>'date','') !~ '^\d{4}-\d{2}-\d{2}$'
      or coalesce(new.payload->>'time','') !~ '^([01]\d|2[0-3]):[0-5]\d$'
      or coalesce(new.payload->>'block','') !~ '^[^<>]{1,120}$'
      or coalesce(new.payload->>'floor','') !~ '^\d{1,2}$'
      or (new.payload->>'energyKwh' is null and new.payload->>'waterKl' is null) then
      raise exception 'Actual resource observation is missing valid date, time, block, floor, or energy/water readings';
    end if;
    if (new.payload->>'floor')::integer not between 1 and 99 then
      raise exception 'Floor number must be between 1 and 99';
    end if;
    begin
      v_observation_date := (new.payload->>'date')::date;
    exception when others then
      raise exception 'Observation date must be a real calendar date';
    end;
    if v_observation_date > current_date then
      raise exception 'Resource observation date cannot be in the future';
    end if;
    if exists (
      select 1 from jsonb_each_text(new.payload) as field(key,value)
      where field.key in ('energyKwh','waterKl','temperatureC','occupancy','hvacHours','lightingHours')
        and field.value <> ''
        and case
          when field.key = 'temperatureC' then field.value !~ '^-?\d+(\.\d+)?$'
          when field.value ~ '^\d+(\.\d+)?$' then field.value::numeric < 0
          else true
        end
    ) then
      raise exception 'Resource observation measurements must be non-negative numbers';
    end if;
    if (new.payload->>'hvacHours')::numeric > 24 or (new.payload->>'lightingHours')::numeric > 24 then
      raise exception 'Equipment runtime must be at most 24 hours';
    end if;
  end if;

  if v_user is null then return new; end if;
  insert into public.workspace_write_quotas(institution_id,user_id,window_started_at,write_count)
    values(new.institution_id,v_user,clock_timestamp(),1)
    on conflict(institution_id,user_id) do update set
      window_started_at=case when workspace_write_quotas.window_started_at < v_cutoff then clock_timestamp() else workspace_write_quotas.window_started_at end,
      write_count=case when workspace_write_quotas.window_started_at < v_cutoff then 1 else workspace_write_quotas.write_count+1 end
    returning write_count into v_count;
  if v_count > 120 then
    raise exception 'Campus record write limit reached. Wait one minute and try again.';
  end if;
  return new;
end;
$$;

drop trigger if exists workspace_records_rate_limit on public.workspace_records;
create trigger workspace_records_rate_limit before insert or update on public.workspace_records
for each row execute function public.guard_workspace_record_write();

comment on table public.workspace_write_quotas is 'Private server-side per-member counter for authenticated workspace record writes; no client access.';
