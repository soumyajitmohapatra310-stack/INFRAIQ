# INFRAIQ — Campus Operations Workspace

INFRAIQ combines staff incident reporting, role-specific panels, shifts and recognition, campus/building records, kitchen logs, six-month history, measured-data charts, and a campus-aware assistant. Additions include a clickable operations schematic, explainable readiness score, response timers and evidence, editable preventive dates with complete schedule visibility, AI-supported campus health reports, voice controls, streamed secure AI, document/image analysis, record search, and human-reviewed action drafts. Existing operations pages and the local evidence fallback remain available.

## Run the local demo

For the local-only demo, open `index.html` in a modern browser, or serve this folder:

```powershell
python -m http.server 8000
```

Then open `http://localhost:8000`. Local demo records remain in this browser profile. Role switching is a preview, not authentication. This static server does not run `/api/assistant`, Supabase Auth, document analysis, or action planning.

To run the hosted features locally, configure Supabase in `supabase-config.js`, copy `.env.example` to `.env.local` and fill its server-only secrets, then use `npx vercel dev` from this folder. Do not open the live app with `file://` or expose `.env.local` in browser code.

## Enable the shared website

Follow [`supabase/SETUP.md`](supabase/SETUP.md) to create the Supabase project, apply all database migrations, configure Auth, and add server-side AI and environment-monitor secrets to Vercel (or Supabase for the legacy chat fallback). Until those settings and secrets are supplied, this copy stays in local/demo mode; its backend scaffolding does not connect to a real database by itself.

Online mode uses Supabase Auth, institution memberships, PostgreSQL row-level security, invitation codes, shared records, metadata-only audit history, Realtime updates, and a server-side OpenAI Responses API call. The browser contains only the Supabase publishable/anon key. Never put a `service_role` or OpenAI secret in browser files. The secure AI function needs an OpenAI API key and a valid API model configured in Supabase secrets.

## Deploy the production AI route on Vercel

The bundle includes a same-origin Node.js serverless route at `api/assistant.js`. It streams Responses API output, verifies the Supabase user and active campus membership, reads campus evidence under that user's RLS token, applies the existing per-user database quota, validates requests and short-lived PDF/image inputs, and never writes AI-created changes to campus records. Import the GitHub repository into Vercel and set the project Root Directory to `outputs/infraiq` (or the directory containing this README if you publish this folder as the repository root). Use Node.js 20 or newer.

Set these values in the Vercel project's server-side Environment Variables:

```text
OPENAI_API_KEY=<secret OpenAI API key>
OPENAI_MODEL=gpt-5.1
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
APP_ORIGINS=https://your-campus-domain.example
```

Use the matching Supabase project's publishable key; a legacy anon key can be supplied as `SUPABASE_ANON_KEY`. Never use a Supabase secret/service-role key in browser configuration. Apply migrations `001` through `006`, configure Supabase Auth's allowed URLs, connect the Vercel project to GitHub, add the environment variables for each deployment environment, and deploy. Also set `SITE_URL` to the final HTTPS origin so the build creates the sitemap and robots file for the correct domain. The API is same-origin at `/api/assistant`. Chat, record search, campus reports, image/PDF analysis, and action drafts use this route. If the Vercel route is missing, plain chat and reports can fall back to the authenticated Supabase Edge Function; document analysis and action drafts require the Node route.

The authenticated `/api/environment-monitor` route screens official PIB releases and shares new environment-related headline matches through Supabase Realtime. Set `SUPABASE_SERVICE_ROLE_KEY` and a strong random `CRON_SECRET` as Vercel server-only variables; never add either to browser configuration. `vercel.json` schedules the check every 15 minutes. Vercel Pro or Enterprise is required for that frequency; Vercel Hobby permits only one scheduled run per day. A signed-in user can also manually refresh the feed. Apply migration `006_environment_monitoring.sql` before enabling it.

The microphone uses browser speech recognition and spoken answers use browser text-to-speech. Browser support and microphone permission vary. Files are limited to 3 MB and sent for one-time model analysis; INFRAIQ does not save them. Vercel Functions have a 4.5 MB request-size ceiling, so keep this upload cap. Conversation history remains in the user's browser profile; campus records and request quotas use Supabase. The assistant can search evidence and prepare a maintenance draft, but a person must review and submit each change.

Realtime updates reach authenticated clients while the site is open and connected. Browser notifications require a user permission grant and an open session. This bundle does not send email, SMS, or push notifications while the site is closed.

## Public launch pages and deployment checklist

The additive public pages are `about.html`, `faq.html`, `privacy.html`, `thank-you.html`, and `404.html`. The root `index.html` remains the campus workspace and is marked noindex. FAQ and privacy pages are marked noindex while their drafts need your review. The public overview is the only route in the generated sitemap by default; update `scripts/build-site.js` after you approve additional public pages.

Before a Vercel deployment, set `SITE_URL` in Project Environment Variables to your bare HTTPS origin, such as `https://campus.your-real-domain.in`, then run `npm run check:site` locally and deploy. The build validates unique page titles, descriptions, local links, social alt text, the 404 page, and the 1200 × 630 share card, and then creates `sitemap.xml` and `robots.txt`. Do not use an example or placeholder domain. Run `npm run build` only after setting the real `SITE_URL`.

Replace `assets/infraiq-social-placeholder.png` with approved share art at exactly 1200 × 630 pixels. Update the `og:image:alt` and `twitter:image:alt` descriptions if the image changes. Current app views update the browser title and meta description but stay noindex because they are authenticated workspace panels, not public pages.

`analytics-config.js` has no Measurement ID by default. Add your real `G-...` ID only after approval. Google Analytics is loaded only after an explicit Accept action; Reject keeps it off, and Cookie settings lets a visitor change their choice. The consent banner is shown to all visitors when GA4 is configured, so there is no IP-based visitor-country lookup.

The privacy notice is a draft based on the current code paths. Fill in the legal organization name, privacy contact, retention periods, subprocessors/data locations, and applicable rights process; obtain your institution's review before removing `noindex`. The FAQ has factual draft answers that also need review. No FAQ schema or review schema is added. The About page contains only an explicit testimonial placeholder—paste real, verified material only after written permission.

Workspace forms include a honeypot; authenticated database writes are limited to 120 per user per minute, and Supabase validates shared-record payloads and checks role and institution. The local demo is not authenticated. There is no public inquiry/contact form; the noindex thank-you page is a template and existing operational forms keep their in-app confirmations. Do not add a CAPTCHA unless a real public form receives spam, and route any future public form through a server-side validated, rate-limited handler.

For HTTPS, connect the real domain in Vercel and wait for its certificate and redirect configuration. Check `http://your-domain` redirects to HTTPS, scan browser DevTools for mixed-content warnings, and confirm the custom `404.html` returns an actual HTTP 404. Then verify the domain in Google Search Console, submit `/sitemap.xml`, inspect the public About page, and use GA4 Realtime to confirm only an opted-in visit appears. These steps require your domain and Google accounts and cannot be completed from this local bundle.

## Initial institution setup

1. Create an account and confirm its work email if email confirmation is enabled in Supabase. After sign-in, choose either six-month history entry or start directly with regular records. The choice can be revisited through Six-month data; it does not train a model by itself.
2. The first account that creates an institution becomes its administrator. Other users join only through a one-time invite code bound to their invited email and role. The fictional showcase is stored separately from the real campus workspace.
3. Add optional campus size, block count, individual block occupancy, labs, instruments, and opening/closing times from actual institution records. Blank fields remain blank.
4. Open **Six-month data** and download the blank CSV template. It contains 66 empty month/category rows for the six most recently completed months, never fabricated sample values.
5. Import or manually enter institution records. The existing 11-category checklist stays available as a broad history reference. Individual metric trends need at least three distinct measured months; Resource Intelligence simulation works without history.
6. Add crew by issuing secure invitations. Staff use **My shift & reports** for shift clocks and rapid incident reports. Administrators and deans verify reports before the contributor receives 10 XP.
7. Kitchen staff enter the date, menu, prepared food, meals served, and measured waste. Leaders can review shared kitchen records.

The history page shows missing months/categories. Blank data is not estimated. Charts show empty states without measurements. Existing whole-campus coverage is shown separately; each history trend becomes available only after three distinct months with compatible numeric records for that metric.

## Main panels

- **Overview:** clickable campus schematic, explainable reported-operations index, incidents, measured food waste, usage alerts, actual history, comparisons, and six-month readiness.
- **My shift & reports / Incident desk:** shift clock, block-specific report shortcut, response target and live timer, assignment, evidence-labeled triage, acknowledgement, resolution evidence, and optional private photo/PDF uploads in online mode.
- **Maintenance:** asset due dates, technician assignments, priority and status workflow, completion evidence, and CSV export.
- **Campus health reports:** source-grounded AI review of available campus evidence, transparent record-based cues, missing-data warnings, cautious estimates, and printable report.
- **Crew & recognition:** role roster, daily/total submissions, completed hours, invitations, and quality-gated XP.
- **Kitchen & food:** day-wise menus, measured preparation, served meals and waste, with an actual-data pie chart.
- **Equipment register / Campus profile:** assets, blocks, optional headcount/lab data, location and Google Maps links/embed.
- **Six-month data:** CSV and manual records for electricity, water, lab conditions, equipment and chemical imports/exports, traffic, entry/exit, occasions, and holidays.
- **Audit log:** leadership view of append-only change metadata in Supabase mode. Payload values are not copied into the audit table.
- **INFRAIQ assistant:** local evidence rules in demo mode; hosted, authenticated, role-filtered answers in online mode. It can prepare a maintenance work-order draft for a person to review; it cannot change equipment, verify an incident, or dispatch people.
- **AI tools:** streamed chat and evidence search, uploaded PDF/image analysis, record-based recommendations, and human-reviewable work-order drafts. No model key is delivered to the browser.
- **Explainability:** source references, a “why” and missing-data explanation, and feedback flags stored on the current device. Feedback does not train the model or alter institution records.
- **Environment & news:** CPCB national observations and all-India AQI dashboard, official IITM/IMD AQI forecast links, DD News live stream, and a shared PIB headline watch. PIB headlines are keyword-screened every 15 minutes on supported Vercel plans; this does not monitor or transcribe the DD News video stream and is not a location-specific warning system. New rows reach signed-in members in open sessions through Supabase Realtime. Desktop alerts require permission and an open browser session; users see unread updates when they next sign in.
- **Resource intelligence:** configurable synthetic building/floor energy and water scenarios, season/time/day variation, HVAC/lighting and renewable/water-source modeling, injected anomaly examples, CPU regression evaluation, offline complaint classification, actual source-mix entry, and measured interval readings with a robust spike-review cue after six comparable historical points. Synthetic runs are explicitly labeled and stored separately from measured history; no live sensor is connected.

## CSV format and coverage

Header:

```text
date,category,block,metric,value,unit,details,reference
```

Allowed categories:

```text
electricity, water, lab_condition, equipment_import, equipment_export,
chemical_import, chemical_export, traffic, entry_exit, occasion, holiday
```

Numeric measurements require a value and unit. If a required month had no activity, enter a real zero and a note describing which register was reviewed. Lab conditions, occasions, and holidays use dated written records. Every row needs a real date and details; future dates are rejected. Coverage requires at least one record per category/month pair. Daily measurements improve analysis; 66 monthly review entries are the minimum gate, not a claim that daily patterns are known.

## Boundaries

- Local mode is a single browser-profile demo with no password authentication, remote backup, or server-side access control.
- Hosted AI, file/image analysis, AI action drafts, and cross-device data require the Supabase and Vercel environment described above; the browser-only local demo does not make provider calls.
- Online permissions are enforced by database policies and authenticated roles. An administrator/dean invitation code must be shared privately with the matching invited email.
- Instant emergency updates apply to connected, open sessions. Follow the institution’s emergency plan and local emergency services for real incidents.
- The assistant reports what records establish, cites evidence, identifies unknown duration, and treats possible causes as hypotheses. Its output remains advisory and should be checked by qualified staff.
- XP recognizes leader-verified incident submissions; it is not payroll, formal performance review, or a safety certification.
- Photo/PDF uploads require the private Supabase Storage bucket and migration. The local demo disables file upload.
- The weekday traffic display compares only dated records. The current history schema does not collect hourly counts. The campus schematic is not a surveyed map or emergency route plan.
- SMS/WhatsApp dispatch, closed-browser push, QR image generation, and automatic sensors are not included. The environment watcher screens PIB RSS headline text, not broadcast video, and does not establish that an issue affects the campus. AQI and forecast links open the official source and are not imported measurements.
- Shift hours are measured between clock-in and clock-out. In cloud mode, timestamps and duration are computed on the database server, and staff cannot edit or delete completed entries. A supervisor should still review these records; they are not payroll-grade attendance.
- The projection is a transparent simple baseline, not a trained or calibrated engineering forecast. Never use it for unattended controls.
- Google Maps links work without an API key. An embedded map requires a Maps Embed key restricted to the deployed domain and required API.
- AQI links open official sources; the app does not import campus AQI sensor readings. The separate PIB headline watcher screens government release text but does not ingest or transcribe a broadcast feed.
- Do not enter sensitive student, health, access-control, or security details. Check your institution’s retention, access, and AI-data policies before putting operational records into a hosted service.

## Project files

- `index.html`, `styles.css`, `app.js`: website.
- `supabase-config.js`, `supabase-client.js`: public browser setup.
- `supabase/migrations/001_infraiq_campus.sql` through `006_environment_monitoring.sql`: database, RLS, operations tickets, private evidence storage, resource intelligence, database-side field validation and write limits, and the read-only shared environment-alert feed.
- `supabase/functions/campus-copilot/`: authenticated server-side AI gateway.
- `api/assistant.js`: Vercel Node route for streamed, authenticated multimodal AI.
- `vercel.json`, `package.json`, `.env.example`: serverless runtime settings and environment-variable template (no real secrets).
- `supabase/SETUP.md`: deployment/configuration walkthrough.
- `scripts/build-site.js`: deployment sitemap/robots generation and prelaunch link/metadata/share-image checks.
- `docs/`: requirements, design boundaries, assumptions, and the detailed 15-item launch checklist.
