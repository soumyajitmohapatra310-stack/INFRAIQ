'use strict';

const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const checkOnly = process.argv.includes('--check');
const htmlFiles = ['index.html','about.html','faq.html','privacy.html','thank-you.html','404.html'];
const publishedRoutes = ['about.html']; // Keep draft/noindex and authenticated pages out of the sitemap.
const fail = message => { console.error(`INFRAIQ build: ${message}`); process.exitCode = 1; };

function checkSite() {
  const titles = new Set();
  for (const file of htmlFiles) {
    const full = path.join(root, file);
    if (!fs.existsSync(full)) { fail(`missing ${file}`); continue; }
    const html = fs.readFileSync(full, 'utf8');
    const title = html.match(/<title>([^<]+)<\/title>/i)?.[1]?.trim();
    const description = html.match(/<meta\s+name="description"\s+content="([^"]+)"/i)?.[1]?.trim();
    if (!title) fail(`${file} needs a unique title`);
    else if (titles.has(title)) fail(`duplicate title: ${title}`);
    else titles.add(title);
    if (!description || description.length < 40) fail(`${file} needs a useful meta description`);
    if (!/<meta\s+property="og:image:alt"/i.test(html)) fail(`${file} needs descriptive social-image alt text`);
    if (/\b(?:src|href)=["']http:\/\//i.test(html)) fail(`${file} contains an insecure HTTP asset or link`);
    const refs = [...html.matchAll(/\b(?:src|href)=["']([^"']+)["']/gi)].map(match => match[1]);
    for (const ref of refs) {
      if (!ref || ref.startsWith('#') || ref.startsWith('__SITE_URL__') || ref.startsWith('https://') || ref.startsWith('mailto:') || ref.startsWith('tel:') || ref.startsWith('data:')) continue;
      const pathname = decodeURIComponent(ref.split(/[?#]/)[0]);
      if (!pathname) continue;
      const resolved = path.resolve(root, pathname.replace(/^\//, ''));
      if (!resolved.startsWith(root + path.sep) && resolved !== root) { fail(`${file} links outside the project: ${ref}`); continue; }
      if (!fs.existsSync(resolved)) fail(`${file} has a broken local link: ${ref}`);
    }
  }
  const sharePath = path.join(root,'assets','infraiq-social-placeholder.png');
  if (!fs.existsSync(sharePath)) fail('missing share-card placeholder PNG');
  else {
    const png = fs.readFileSync(sharePath);
    if (png.length < 24 || png.subarray(1,4).toString() !== 'PNG' || png.readUInt32BE(16) !== 1200 || png.readUInt32BE(20) !== 630) fail('share card must be a PNG at 1200 x 630');
  }
  const css = fs.readFileSync(path.join(root,'site.css'),'utf8') + fs.readFileSync(path.join(root,'styles.css'),'utf8');
  const app = fs.readFileSync(path.join(root,'app.js'),'utf8');
  if (/url\(\s*["']?http:\/\//i.test(css)) fail('CSS contains an insecure HTTP asset');
  if (/\b(?:src|href)\s*=\s*["']http:\/\//i.test(app)) fail('app.js contains an insecure HTTP asset or link');
  for (const source of [...htmlFiles.map(file=>fs.readFileSync(path.join(root,file),'utf8')),app]) {
    for (const match of source.matchAll(/<img\b[^>]*>/gi)) {
      if (!/\balt\s*=\s*["'][^"']*["']/i.test(match[0])) fail(`image is missing alt text: ${match[0].slice(0,100)}`);
    }
  }
  return !process.exitCode;
}

if (!checkSite()) process.exit(1);
if (checkOnly) { console.log(`INFRAIQ build check passed for ${htmlFiles.length} HTML pages and the 1200 x 630 share card.`); process.exit(0); }

const siteUrl = String(process.env.SITE_URL || '').trim().replace(/\/+$/, '');
let parsed;
try { parsed = new URL(siteUrl); } catch { fail('set SITE_URL to the deployed HTTPS origin, for example https://campus.example'); process.exit(1); }
if (parsed.protocol !== 'https:' || parsed.origin !== siteUrl) { fail('SITE_URL must be a bare HTTPS origin without a path'); process.exit(1); }

for (const file of htmlFiles) {
  const full = path.join(root,file);
  fs.writeFileSync(full,fs.readFileSync(full,'utf8').replaceAll('__SITE_URL__',siteUrl));
}
const routes = publishedRoutes.map(file => `  <url>\n    <loc>${siteUrl}/${file}</loc>\n    <changefreq>monthly</changefreq>\n    <priority>1.0</priority>\n  </url>`).join('\n');
fs.writeFileSync(path.join(root,'sitemap.xml'),`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${routes}\n</urlset>\n`);
fs.writeFileSync(path.join(root,'robots.txt'),`User-agent: *\nAllow: /about.html\nDisallow: /api/\nDisallow: /supabase/\nSitemap: ${siteUrl}/sitemap.xml\n`);
console.log(`INFRAIQ site assets generated for ${siteUrl}. Public sitemap routes: ${publishedRoutes.join(', ')}.`);
