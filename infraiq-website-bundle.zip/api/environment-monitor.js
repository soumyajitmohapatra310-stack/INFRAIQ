'use strict';

const PIB_FEED = 'https://pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=22';
const FEED_SOURCE = 'Press Information Bureau · Government of India';
const MAX_FEED_BYTES = 2 * 1024 * 1024;
const MAX_ITEMS = 35;
const TOPIC_RULES = [
  ['air_quality', /\b(aqi|air quality|air pollution|smog|particulate|pm2?\.5|pm10|emission|pollutant)\b/i],
  ['extreme_weather', /\b(cyclone|cyclonic|flood|flash flood|heatwave|heat wave|cold wave|drought|cloudburst|extreme weather|red alert|orange alert|weather warning|heavy rainfall)\b/i],
  ['climate', /\b(climate change|climate|global warming|greenhouse gas|carbon neutral|net zero|adaptation|mitigation)\b/i],
  ['water', /\b(water scarcity|water conservation|water quality|groundwater|drought|river pollution|flood)\b/i],
  ['environment', /\b(environment|environmental|forest|wildlife|biodiversity|wetland|waste management|plastic pollution|conservation|sustainability)\b/i]
];
const NOTICE_WORDS = /\b(alert|warning|advisory|evacuat|emergency|severe|extreme|record high|flood|cyclone|heatwave|heat wave|drought)\b/i;

function reply(res, status, payload) {
  res.status(status).setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  return res.end(JSON.stringify(payload));
}

function env(name) { return String(process.env[name] || '').trim(); }

function decodeXml(value) {
  return String(value || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&#(x[\da-f]+|\d+);/gi, (_, code) => {
      const n = code[0].toLowerCase() === 'x' ? parseInt(code.slice(1), 16) : Number(code);
      return Number.isFinite(n) && n >= 0 && n <= 0x10ffff ? String.fromCodePoint(n) : ' ';
    })
    .replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"').replace(/&apos;|&#39;/gi, "'")
    .replace(/&nbsp;/gi, ' ').replace(/\s+/g, ' ').trim();
}

function tag(block, name) {
  const match = block.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${name}\\s*>`, 'i'));
  return match ? decodeXml(match[1]) : '';
}

function parseItems(xml) {
  return [...String(xml).matchAll(/<item\b[^>]*>([\s\S]*?)<\/item\s*>/gi)].slice(0, 120).map((match) => {
    const block = match[1];
    const title = tag(block, 'title').slice(0, 300);
    const rawUrl = tag(block, 'link') || tag(block, 'guid');
    let url = '';
    try {
      const parsed = new URL(rawUrl);
      if (parsed.protocol === 'https:' && ['pib.gov.in', 'www.pib.gov.in'].includes(parsed.hostname.toLowerCase())) url = parsed.toString();
    } catch {}
    if (!title || !url) return null;
    const description = tag(block, 'description') || tag(block, 'content:encoded');
    const publishedRaw = tag(block, 'pubDate') || tag(block, 'dc:date');
    const date = publishedRaw ? new Date(publishedRaw) : null;
    const publishedAt = date && Number.isFinite(date.getTime()) ? date.toISOString() : null;
    const text = `${title} ${description}`;
    const topic = TOPIC_RULES.find(([, rule]) => rule.test(text))?.[0];
    if (!topic) return null;
    const sourceId = url.replace(/#.*$/, '').slice(0, 700);
    return {
      source_id: sourceId,
      source_name: FEED_SOURCE,
      title,
      summary: description.slice(0, 480),
      url,
      topic,
      headline_flag: NOTICE_WORDS.test(text),
      published_at: publishedAt,
      detected_at: new Date().toISOString()
    };
  }).filter(Boolean).slice(0, MAX_ITEMS);
}

async function fetchFeed() {
  const response = await fetch(PIB_FEED, {
    headers: { Accept: 'application/rss+xml, application/xml, text/xml;q=0.9', 'User-Agent': 'INFRAIQ-EnvironmentMonitor/1.0 (+official headline screening)' },
    signal: AbortSignal.timeout(12000)
  });
  if (!response.ok) throw new Error(`Official feed returned HTTP ${response.status}.`);
  const declaredLength = Number(response.headers.get('content-length') || 0);
  if (declaredLength > MAX_FEED_BYTES) throw new Error('Official feed response exceeded its size limit.');
  const xml = await response.text();
  if (Buffer.byteLength(xml, 'utf8') > MAX_FEED_BYTES) throw new Error('Official feed response exceeded its size limit.');
  return parseItems(xml);
}

async function supabaseRequest(path, method, body) {
  const base = env('SUPABASE_URL').replace(/\/+$/, '');
  const key = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!base || !key) throw new Error('Environment monitoring needs SUPABASE_URL and the server-only SUPABASE_SERVICE_ROLE_KEY.');
  const response = await fetch(`${base}/rest/v1/${path}`, {
    method,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      'Content-Type': 'application/json',
      Prefer: 'resolution=ignore-duplicates,return=representation'
    },
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 400);
    throw new Error(`Environment alert storage returned HTTP ${response.status}: ${detail}`);
  }
  const text = await response.text();
  return text ? JSON.parse(text) : [];
}

async function isActiveMember(req) {
  const authorization = String(req.headers.authorization || '');
  const token = authorization.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token || token.length > 6000) return false;
  const base = env('SUPABASE_URL').replace(/\/+$/, '');
  const publicKey = env('SUPABASE_PUBLISHABLE_KEY') || env('SUPABASE_ANON_KEY');
  const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY');
  if (!base || !publicKey || !serviceKey) return false;
  const userResponse = await fetch(`${base}/auth/v1/user`, {
    headers: { apikey: publicKey, Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(8000)
  });
  if (!userResponse.ok) return false;
  const user = await userResponse.json();
  if (!user?.id) return false;
  const query = new URLSearchParams({ select: 'user_id', user_id: `eq.${user.id}`, is_active: 'eq.true', limit: '1' });
  const membershipResponse = await fetch(`${base}/rest/v1/institution_members?${query}`, {
    headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` },
    signal: AbortSignal.timeout(8000)
  });
  if (!membershipResponse.ok) return false;
  const memberships = await membershipResponse.json();
  return Array.isArray(memberships) && memberships.length > 0;
}

module.exports = async function environmentMonitor(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return reply(res, 405, { error: 'Use GET.' });
  }
  const cronSecret = env('CRON_SECRET');
  const cronAuthorized = !!cronSecret && req.headers.authorization === `Bearer ${cronSecret}`;
  try {
    if (!cronAuthorized && !(await isActiveMember(req))) return reply(res, 401, { error: 'Sign in to an active campus workspace to refresh the shared environment feed.' });
    const items = await fetchFeed();
    const inserted = items.length ? await supabaseRequest('environment_alerts?on_conflict=source_id', 'POST', items) : [];
    // Retain two months of headline metadata only; the linked articles remain on their publisher sites.
    const cutoff = new Date(Date.now() - 60 * 86400000).toISOString();
    await supabaseRequest(`environment_alerts?detected_at=lt.${encodeURIComponent(cutoff)}`, 'DELETE');
    return reply(res, 200, {
      source: FEED_SOURCE,
      scanned: items.length,
      newAlerts: Array.isArray(inserted) ? inserted.length : 0,
      checkedAt: new Date().toISOString(),
      schedule: 'The production deployment schedules this route every 15 minutes. Updates depend on the publisher feed and hosting scheduler.'
    });
  } catch (error) {
    console.error('INFRAIQ environment monitor failed:', error.message);
    return reply(res, 503, { error: 'The official environment feed is temporarily unavailable. Check the server configuration and retry shortly.' });
  }
};
