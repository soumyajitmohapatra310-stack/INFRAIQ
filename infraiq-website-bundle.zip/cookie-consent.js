(() => {
  'use strict';
  const id=String(window.INFRAIQ_GA4_ID||'').trim(),enabled=/^G-[A-Z0-9]+$/.test(id),consentKey='infraiq-analytics-consent-v1';
  const loadAnalytics=()=>{
    if(!enabled)return;
    if(window.__infraiqAnalyticsLoaded){window.gtag?.('consent','update',{analytics_storage:'granted'});return;}
    window.__infraiqAnalyticsLoaded=true;window.dataLayer=window.dataLayer||[];
    window.gtag=function(){window.dataLayer.push(arguments);};
    window.gtag('consent','default',{analytics_storage:'denied',ad_storage:'denied',ad_user_data:'denied',ad_personalization:'denied'});
    window.gtag('consent','update',{analytics_storage:'granted'});window.gtag('js',new Date());window.gtag('config',id,{anonymize_ip:true});
    const script=document.createElement('script');script.async=true;script.src='https://www.googletagmanager.com/gtag/js?id='+encodeURIComponent(id);document.head.append(script);
  };
  const show=()=>{
    if(!enabled||document.getElementById('infraiq-cookie-consent'))return;
    const banner=document.createElement('aside');banner.id='infraiq-cookie-consent';banner.className='site-consent';banner.setAttribute('role','dialog');banner.setAttribute('aria-label','Optional analytics consent');
    banner.innerHTML='<p><b>Optional analytics</b><br>INFRAIQ can use Google Analytics to understand visits. It stays off unless you choose “Accept analytics.” You can reject it and continue using the site. <a href="privacy.html">Read the privacy draft</a>.</p><div class="site-consent-actions"><button type="button" data-consent="reject">Reject</button><button class="accept" type="button" data-consent="accept">Accept analytics</button></div>';
    banner.addEventListener('click',event=>{const choice=event.target.closest('[data-consent]')?.dataset.consent;if(!choice)return;try{localStorage.setItem(consentKey,choice==='accept'?'accepted':'rejected');}catch{}banner.remove();if(choice==='accept')loadAnalytics();});document.body.append(banner);
  };
  if(!enabled)return;
  document.querySelectorAll('[data-consent-settings]').forEach(button=>button.hidden=false);
  document.addEventListener('click',event=>{if(!event.target.closest('[data-consent-settings]'))return;event.preventDefault();window.gtag?.('consent','update',{analytics_storage:'denied'});try{localStorage.removeItem(consentKey);}catch{}show();});
  let saved='';try{saved=localStorage.getItem(consentKey)||'';}catch{}
  if(saved==='accepted'){loadAnalytics();return;}if(saved==='rejected')return;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',show,{once:true});else show();
})();
