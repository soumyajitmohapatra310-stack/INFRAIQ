/*
 * Add the project URL and publishable (or legacy anon) key from Supabase.
 * These values are public in a browser app. Never add a service_role key here.
 * Keep the empty values until a Supabase project has been created.
 */
window.INFRAIQ_SUPABASE_CONFIG = {
  url: '',
  publishableKey: '',
  copilotFunction: 'campus-copilot',
  aiApiRoute: '/api/assistant'
};
